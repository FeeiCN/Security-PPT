Please note that you can always find the most updated version of this code, more detailed documentation/installation instructions, and binary packages at: 

http://jmmcatee.github.io/cracklord/
https://github.com/jmmcatee/cracklord
