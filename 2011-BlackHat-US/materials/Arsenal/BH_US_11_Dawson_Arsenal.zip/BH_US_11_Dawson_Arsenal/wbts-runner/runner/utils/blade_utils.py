#!/usr/bin/env python
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.

import os
import sys
import glob
from importlib import import_module

try:
    import win32gui, win32con, win32api
except ImportError:
    if (os.name == 'nt'):
        print "You do not appear to have pywin32 installed."
        print "You can download it from:"
        print "http://sourceforge.net/projects/pywin32/"
        exit(-1)
    pass

try:
    import ldtp
except ImportError:
    if (os.name == 'posix'):
        print "ldtp must be installed to access window information"
        print "for posix machines. Please see:"
        print "http://ldtp.freedesktop.org for more information."
        exit(-1)
    pass

STARTUP_DELAY = 3 # time, in seconds to wait for the brower proc to startup.

def get_browser_class(cfg):
    try:
        package_path = 'runner.browsers.'+cfg.os_type+'.'
        target_browser = import_module(package_path+cfg.browser_type)
        return target_browser.browser_class
    except ImportError, msg:
        print "Can't Import: runner.browsers."+cfg.os_type+"."+cfg.browser_type
        print msg
        pass
    return None

def list_supported():
    browser_path = 'runner'+os.sep+'browsers'+os.sep+os.name+os.sep
    browsers = glob.glob(browser_path + '*.py')
    browsers.remove(browser_path + '__init__.py')
    for browser in browsers:
        print "\t%s"%(browser[browser.rindex(os.sep)+1:-3])
    return 

def get_urls_from_file(fp):
    try:
        f = open(fp, 'r')
        urls = f.readlines()
        f.close()
        return urls
    except IOError, msg:
        print "Unable to open file (%s) to get urls: %s"%((fp,),(msg,))
        exit(-1)
        
def pixels_match(hwnd, pixel_list, color_match):
    """
    takes a handle to a window, a list of pixels in a tuple form (x,y)
    and then a color to match on.
    returns True on success (pixels tested all matched)
    returns False on failure (at least 1 pixel did not match) or exceptio
    occurred.
    """
    hdc = win32gui.GetWindowDC(hwnd)
    for i in xrange(0, len(pixel_list)):
        try:
            color = win32gui.GetPixel(hdc,
                                      pixel_list[i][0],
                                      pixel_list[i][1])
            #print "matching against color_match: %06x"%color
            #print "%06x at (%d,%d)"%(color, pixel_list[i][0], pixel_list[i][1])
            if (color != color_match):
                #print "Exception did not occur. pixel color is not black"
                #print "%06x"%color
                return False
        except Exception, msg:
            print "An exception occurred trying to read pixels."
            print msg
            return False
    win32gui.ReleaseDC(hwnd, hdc)
    return True

def scan_axis_for_color(hwnd, def_x, def_y, color, axis, max):
    """
    takes a handle to a window, a starting (x,y) coord, the color to match
    on, the axis to scan (as a str) can be either "x" or "y" and finally,
    the maximum (or minimum) value to scan until. If the "max" value is less
    than the starting value of the chosen axis, it will decrement, otherwise
    increment until that value is reached.
    
    returns True on color matched
    returns False otherwise.
    """
    ret = False
    hdc = win32gui.GetWindowDC(hwnd)
    try:
        if (axis == "x" and (max > def_x)):
            for inc_x in xrange(def_x, max):
                if (win32gui.GetPixel(hdc, inc_x, def_y) == color):
                    ret = True
        elif (axis == "x" and (max < def_x)):
            for dec_x in xrange(def_x, max, -1):
                if (win32gui.GetPixel(hdc, dec_x, def_y) == color):
                    ret = True
        elif (axis == "y" and (max > def_y)):
            for inc_y in xrange(def_y, max):
                if (win32gui.GetPixel(hdc, def_x, inc_y) == color):
                    ret = True
        elif (axis == "y" and (max < def_y)):
            for dec_y in xrange(def_y, max, -1):
                if (win32gui.GetPixel(hdc, def_x, dec_y) == color):
                    ret = True
    except Exception, msg:
        print "An exception occurred trying to read pixels:"
        print msg
    win32gui.ReleaseDC(hwnd, hdc)
    return ret
    
# START POSIX RELATED HELPER FUNCS
def find_window_by_unique_menu(menu_name):
    window_list = ldtp.getwindowlist()
    # we go backwards because our browser should be the latest process.
    # which should be the last element in the array (hopefully).
    for i in xrange(len(window_list)-1, 0, -1):
        window = window_list[i] # 
        if menu_name in ldtp.getobjectlist(window):
            print "FOUND: %s "%menu_name
            return window
            
    print "Unable to find menu in all windows! Did our process crash?"
    return ""