#!/usr/bin/env python
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.

import getopt 
import sys

try:
    import ldtp
except ImportError, msg:
    print "ldtp not found! You must install this package"
    print "if you wish to run wbts_runner in *nix"
    print "ldtp's Website: http://ldtp.freedesktop.org"
    print msg
    exit()

def print_windows():
    option = -1
    while(1):
        window_list = ldtp.getwindowlist()
        win_len = len(window_list)
        for i in xrange(0, win_len):
            print "%d. %s"%(i, window_list[i])
        x = raw_input("Enter a number to get more details ('q' to quit'): ")
        if (x == 'q'):
            exit()
        try:
            print x
            option = int(x)
            if (option > win_len or option < 0):
                print "Invalid option, must be between 0 and %d"%(win_len-1)
                continue
            else:
                break
        except TypeError:
            print "Invalid option, must be between 0 and %d"%(win_len-1)
            continue
    
    
    for obj in ldtp.getobjectlist(window_list[option]):
        print "Object: ",obj
        
    print "Frm only:"
    for obj in ldtp.getobjectlist(window_list[option]):
        if (obj.startswith('frm')):
            print "Obj: %s"%obj
        
    return

def usage():
    print "WBTS Runner POSIX Browser Script Creation Helper"
    print "-e {--exec} A path to the browser executable"
    print "-p {--print} Print windows and that windows objects if available"
    print "(For use by itself)"
    print "-w {--winre} A regex for the window name ex: \"*MozillaFirefox\""
    print "-h {--help} This..."
    exit(-1)

def main():
    try:
        opts, args = getopt.getopt(sys.argv[1:], "e:hpmr:w:",
                                   ["exec=", "help", "print=",
                                    "winre=", "max", "reloc="])
    except getopt.GetoptError, err:
        # print help information and exit:
        print str(err)
        usage()
        sys.exit(2)
    
    window_title = ''
    move_win = False
    max = False
    x = y = -1
    for o, a in opts:
        if o in ("-p" "--print"):
            print_windows()
            exit()
        elif o in ("-w", "--winre"):
            window_title = a
        elif o in ("-h", "--help"):
            usage()
        elif o in ("-r", "--reloc"):
            m_x,m_y = split_coords(a)
            move_win = True
        elif o in ("-m"):
            max = True
        elif o in ("-i", "--input"):
            x,y = split_coords(a)

    if (window_title == ''):
        usage()
    """
    if (move_win == True):
        move_window(window_title, m_x, m_y)
    if (max == True):
        maximize_window(window_title)
        
    get_pixel_details(window_title, x, y)
    """
    return

if __name__ == '__main__':
    main()
