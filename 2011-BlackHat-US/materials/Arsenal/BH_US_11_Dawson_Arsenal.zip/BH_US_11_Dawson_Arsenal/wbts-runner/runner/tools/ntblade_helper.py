#!/usr/bin/env python
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.

import getopt
import sys

import os

try:
    import win32gui
except ImportError:
    if (os.name == 'nt'):
        print "I'm sorry this is requires pywin32"
        print "You can download it from:\nhttp://sourceforge.net/projects/pywin32/"
        exit(-1)
    pass

#add path so we can import runner.
sys.path.append(os.curdir+os.sep+'..'+os.sep+'..'+os.sep)

from runner.utils import blade_utils
from runner.automation.auto import MultipleWindowsException, WindowNotFoundException
from runner.automation.winauto import WinAutomate

def usage():
    print "WBTS Runner NT Browser Script Creation Helper"
    print "Make sure you have the window you are testing up/in front."
    print "Put your cursor over the location you wish to get the color from."
    print "-w {--winre=} A regex for the window name ex: \".*Chrome.*\""
    print "-i {--input=} Use hardcoded x,y coords, seperated by a ,"
    print "-h {--help} This..."
    exit(-1)
    
def split_coords(xy_vals):
    if (',' not in xy_vals):
        print "please seperate x and y by a , character."
        usage()
    else:
        x,y = xy_vals.split(',')
        try:
            x = int(x)
            y = int(y)
        except TypeError, msg:
            print msg
    return (x,y) 

def get_hwnd_multiple_windows(windows):
    print "Please choose a more specific window title name"
    print "The following windows were found:"
    for i in xrange(0, len(windows)):
        print "%d. %s"%(i,win32gui.GetWindowText(windows[i][0]))
    
    while (1):
        win_idx = raw_input('\nChose a window (q to quit): ')
        try:
            win_idx = int(win_idx)
        except ValueError:
            print "That option is not valid, we need an int, try again."
            continue
        if (win_idx == 'q'):
            exit(-2)
        if (win_idx > len(windows) or win_idx < 0):
            print "win_idx is %d but len is %d"%(win_idx, len(windows))
            print "Sorry that option is invalid."
            continue
        break
    return windows[win_idx][0]
    
def get_hwnd(win_title):
    try:
        auto = WinAutomate(debug=True)
        windows = auto.find_window(title_re = win_title)
        win_idx = 0
        print windows
        print len(windows)
        
        if (len(windows) > 1):
            hwnd = get_hwnd_multiple_windows(windows)
        else:
            hwnd = windows[0][0]
        if (windows == []):
            print "Window not found with that title, please change the title "\
            "and try again."
            exit(-3)
        hwnd = windows[win_idx][0]
        print hwnd
        print "Window Found: %s"%(win32gui.GetWindowText(hwnd))
        
        
    except MultipleWindowsException:
        print "Could not find the %s window! Are multiple "%win_title
        print "Instances running? Please only have a single instance open."
        exit(-1)
    return hwnd

    
def get_pixel_details(win_title,x,y):
    hwnd = get_hwnd(win_title)
    print "Window Title: %s"%win32gui.GetWindowText(hwnd)
    print "hwnd found: 0x%08x"%hwnd
    
    hdc = win32gui.GetWindowDC(hwnd)
    print "Window DC: 0x%08x"%hdc
    rect = win32gui.GetWindowRect(hwnd)
    left,top,right,bottom = rect
    #client_rect = win32gui.GetClientRect(hwnd)
    print "Window Dimensions:"
    print "left: %d right: %d top: %d bottom: %d"%rect
    print "Client Dimensions:"
    #print "left: %d right: %d top: %d bottom: %d"%client_rect
    print "Difference between Window & Client (x,y):"
    print ("(i.e. the size of the border x is left,bottom, right, y is top)")
    print "x: %d y: %d"%(win32gui.ClientToScreen(hwnd, (0,0)))   
    
    if (x == -1 and y == -1):
        x,y = win32gui.GetCursorPos()
    
    print "Cursor position: (%d,%d)"%(x,y)
    try:
        color = win32gui.GetPixel(hdc, x,y)
        print "Color at cursor position (%d,%d): 0x%06x"%(x,y,color)
        xc,yc = win32gui.ScreenToClient(hwnd, (x,y))
        print "Color at cursor (client) (%d,%d): 0x%06x"%(xc,yc, color)
    except Exception, msg:
        print "\nError:"
        print "Unable to get pixel color, is the window on top?"
       
    win32gui.ReleaseDC(hwnd, hdc)
  
def main():
    try:
        opts, args = getopt.getopt(sys.argv[1:], "w:hi:d",
                                   ["winre=", "help", "input="])
    except getopt.GetoptError, err:
        # print help information and exit:
        print str(err) 
        usage()
        sys.exit(2)
    
    window_title = ''
    print_details = False
    x = y = -1
    for o, a in opts:
        if o in ("-w", "--winre"):
            window_title = a
        elif o in ("-h", "--help"):
            usage()
        elif o in ("-m"):
            max = True
        elif o in ("-i", "--input"):
            x,y = split_coords(a)

    if (window_title == ''):
        usage()
       
    get_pixel_details(window_title, x, y)
    return

if __name__ == '__main__':
    main()
