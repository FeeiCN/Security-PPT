import utils
from debug import Debugger


class error(Exception):
    pass

class DebuggerException(error):
    pass
