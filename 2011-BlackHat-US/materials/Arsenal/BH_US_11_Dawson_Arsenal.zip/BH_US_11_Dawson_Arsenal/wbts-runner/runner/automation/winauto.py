#!/usr/bin/env python
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.

import re
import os

try:
    import win32gui, win32api, win32con, win32com, win32com.client
except ImportError, msg:
    if (os.name == 'nt'):
        print "Error you must have pywin32 installed for windows automation!"
        exit(-1)
    pass

from auto import Automate, MultipleWindowsException, WindowNotFoundException

class WinAutomate(Automate):
    def __init__(self, debug=False):
        self.debug = debug
   
    def find_multi_windows(self, title_text=None, title_re=None):
        return
    
    def find_class(self, hwnd, class_name):
        handle = {}
        def _find_class(hwnd, handle):
            handle[win32gui.GetClassName(hwnd)] = hwnd
            win32gui.EnumChildWindows(hwnd, _find_class, handle)
        win32gui.EnumChildWindows(hwnd, _find_class, handle)
        if (handle.has_key(class_name)):
            return handle[class_name]
        return -1
    
    def get_class_name(self, hwnd):
        return win32gui.GetClassName(hwnd)
        
    def find_windows(self):
        """find_windows, searches through all of the systems windows and gathers
        their handle and window text.
        @return: A dictionary object with key as the hwnd and value as the
        windows text if any.
        """
        windows = {}
        def _build_hwnds(windows, hwnd):
            windows[hwnd] = win32gui.GetWindowText(hwnd)
            
        win32gui.EnumWindows(lambda hwnd, windows: _build_hwnds(windows,hwnd),
                             windows)
        #if (self.debug):
        #    vals = [x for x in windows.values() if x != '']
        #    print "\r\n".join(vals)
        return windows 
        
    def click_window(self, window):
        return
    
    def click_dialog(self, dlg, txt_to_click):
        return
    
    def click_coords(self, x, y):
        """click_coords, moves the cursor to the provided x,y coordinates and
        clicks.
        @param x: the x coordinate
        @param y: the y coordinate
        """
        win32api.SetCursorPos((x,y))
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP,0,0)
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN,0,0)

    def move_window(self, hwnd, x, y):
        """Moves the window to the specified x,y coordinates.
        @param hwnd: The handle to the window
        @param x: The X coordinate
        @param y: The Y coordinate
        """
        win32gui.MoveWindow(hwnd, x, y)
        
    def find_window(self, title=None, title_re=None, win_class=None,
                    re_flags=re.IGNORECASE):
        """Checks to see if title_text or title_re exist in the list of
        available windows. Returns hwnd if found.
        
        @param title: The exact title text to match against the list of
        system windows.
        @param title_re: A regex used to find the window.
        @param win_class: An optional window class to further identify what
        window we need to work with. IE9 has two exact same names for their
        window and the subtab (ugh). So you may need to pass a window class
        along with titles.
        @param re_flags: The regex flags used in the comparison.
        
        @throws MultipleWindowsException: if more than one is found.
        @throws WindowsNotFoundException: if even a single window is not found.
        
        @return: the window matching title_text or title_re's window handle.
        """
        
        windows = self.find_windows().items()
        window = None
        if title is not None:
            window = [w for w in windows if w[1] == title]
        elif title_re is not None:
            p = re.compile(title_re, re_flags)
            window = [w for w in windows if (re.match(p, w[1]))]

        if (win_class is not None):
            for hwnd in window:
                # assume if found we only have one...
                if (self.get_class_name(hwnd[0]) == win_class):
                    return hwnd[0]

        # for debug we return all windows.
        if (self.debug == True):
            return window 

        # sanity checks
        if (len(window) > 1):
            raise MultipleWindowsException
        if (len(window) == 0):
            raise WindowNotFoundException
        return window[0][0]
    
    def type_keys(self, hwnd, keys):
        """type_keys uses Wscript.Shell to SendKeys after focusing on hwnd.
        @param hwnd: The window handle that we need to set focus to
        @param keys: The keys to send, for a listing of 'special' keys
        see: U{http://msdn.microsoft.com/en-us/library/8c6yea83(VS.85).aspx}
        """
        win32gui.SetForegroundWindow(hwnd)
        win32gui.BringWindowToTop(hwnd)
        win32gui.SendMessage(hwnd, win32con.WM_SETFOCUS, 0, 0)
        shell = win32com.client.Dispatch("Wscript.Shell")
        shell.SendKeys(keys)
        
if __name__ == '__main__':
    x = WinAutomate(debug=True)
    #hwnd = x.find_window(title_re='.*- Mozilla Firefox')
    hwnd = x.find_window(title_re='.*- Windows Internet Explorer', win_class="IEFrame")
    print hwnd
    #print x.find_class(hwnd, 'Chrome_OmniboxView')
    #x.type_keys(hwnd, '^lhttp://sh0dan.org/alerty.html{ENTER}')
    #hwnd = x.find_window(title_text="Mozilla Firefox")
    #x.type_keys(hwnd, '{ENTER}')
    