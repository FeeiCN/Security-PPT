#!/usr/bin/env python
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.

import re

try:
    import ldtp
except ImportError, msg:
    print "Error you must install ldtp for linux automation to work!"
    print "See: http://ldtp.freedesktop.org"
    print msg
    exit(-1)

from auto import Automate, MultipleWindowsException, WindowNotFoundException

class LinuxAutomate(Automate):
    def __init__(self, debug=False):
        self.debug = debug

    def find_windows(self):
        return ldtp.getwindowlist()

    def find_window(self, title_re=None, re_flags=re.IGNORECASE):
        """Checks to see if title_text or title_re exist in the list of
        available windows. Returns hwnd if found.
        
        @param title_re: A regex used to find the window.
        @param re_flags: The regex flags used in the comparison.
        
        @throws MultipleWindowsException: if more than one is found.
        @throws WindowsNotFoundException: if no window is not found.
        
        @return: the window matching title_re's window, or an empty string.
        """
        p = re.compile(title_re, re_flags)
        #window = [w for w in self.find_windows() if re.match(p, title_re)]
        window = [w for w in self.find_windows() if (re.match(p, w))]

        # sanity checks
        if (len(window) > 1):
            raise MultipleWindowsException
        if (len(window) == 0):
            raise WindowNotFoundException
        if window == []:
            return ""
        return window[0]

    def type_keys(self, window_name, inputfield_name, keys):
        """Types keys in to the input of the specified window name.
        See http://ldtp.freedesktop.org/user-doc/d1/d72/a00204.html for a list
        of control characters and their string representations."""
        if (ldtp.guiexist(window_name)):
            ldtp.activatewindow(window_name)
            return ldtp.enterstring(window_name, inputfield_name, keys)
        else:
            print "Unable to type keys to %s as it does not "\
            "exist!"%(window_name,)

    def list_children(self, window_name):
        return ldtp.getobjectlist(window_name)

    def find_child(self, window_name, object_name):
        children = self.list_children(window_name)
        child = [c for c in children if c == object_name]
         # sanity checks
        if (len(child) > 1):
            raise MultipleWindowsException
        if (len(child) == 0):
            raise WindowNotFoundException
        if child == []:
            return ""
        return child[0]
        
    
    def click_object(self, window_name, object_name):
        return ldtp.click(window_name, object_name)
        
if __name__ == '__main__':
    x = LinuxAutomate(debug=True)
    print x.find_windows()
    #win = x.find_window('dlgPrint')
    #print x.find_child(win,'btnCancel')
    #x.click_object(win, 'btnCancel')
    #if win != None:
    #    print x.type_keys(win, 'txt0', '<ctrl>l<bksp>http://sh0dan.org/<enter>')

