#!/usr/bin/env python

from comtypes.gen import DbgEng

from runner.third_party import buggery
from runner.debug.debugger import Debugger

class BuggeryDebugger(Debugger):
    def __init__(self, pid):
        Debugger.__init__(self, pid, buggery.Debugger())

    def attach(self):
        print "attaching debugger to pid: %d"%self.pid
        self.debugger.set_event_handler("EXCEPTION", self.onException)
        self.debugger.add_interest(buggery.idebug.DbgEng.DEBUG_EVENT_EXCEPTION)
        self.debugger.attach(self.pid, DbgEng.DEBUG_PROCESS)
        #x = self.debugger.execute('')
        #print x
    
    def onException(self, exception):
        print "___________________________EXCEPTION___________________________"
        print exception
        #print self.debugger.execute('!exploitable')
        
        