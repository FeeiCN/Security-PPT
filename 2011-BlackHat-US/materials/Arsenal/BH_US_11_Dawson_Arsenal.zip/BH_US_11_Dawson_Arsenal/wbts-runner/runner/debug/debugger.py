#!/usr/bin/env python

class Debugger(object):
    def __init__(self, pid, debugger):
        self.pid = pid
        self.debugger = debugger
        return
    
    
    def onException(self, exception_type):
        return
    