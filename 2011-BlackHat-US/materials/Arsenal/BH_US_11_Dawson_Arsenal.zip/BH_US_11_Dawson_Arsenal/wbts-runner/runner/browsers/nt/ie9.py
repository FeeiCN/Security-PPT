#!/usr/bin/env python
from twisted.internet import reactor

from runner.browsers.winbrowse import WinBrowser

class IE9(WinBrowser):
    def __init__(self, options, _reactor=reactor):
        WinBrowser.__init__(self, options, _reactor)
        self.exe_name = 'iexplore.exe'
        self.args = [self.exe_name]
        self.exe_path = r'C:\Program Files (x86)\Internet Explorer\iexplore.exe'
        return
    
    def _enter_address(self, address):
        return '^l{BS}'+address+'{ENTER}'

    def strings_en(self):
        """strings_<lang> loads the language specific values for the browser.
        For the browser window we need a title or title_re with optional class.
        If you don't supply the class, things like java applets will steal
        focus and we won't be able to get it back."""
        
        self.controls['browser_window'] = {'class':'IEFrame',
                                           'title_re': '.*- Windows Internet Explorer',
                                           'addrbar_class':'ToolbarWindow32'} 
        self.controls['dialogs'] = [
            # for closing alerts
            {'title_re': 'Message from webpage',
             'type': 'closeable',
             'closer': self.simple_closer},
            # for closing print preview
            {'title': 'Print',
             'type': 'closeable',
             'closer': self.simple_closer},
            # for prompt
            {'title_re':'.* needs some information',
             'type': 'closeable',
             'closer': self.simple_closer}
        ]
        return
    
browser_class = IE9