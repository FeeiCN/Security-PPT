from twisted.internet import reactor

from runner.browsers.winbrowse import WinBrowser

class Chrome13(WinBrowser):
    def __init__(self, options, _reactor=reactor):
        WinBrowser.__init__(self, options, _reactor)
        self.exe_name = 'chrome.exe'
        self.args = [self.exe_name]
        self.exe_path = r'C:\Users\eff.bee.eye\AppData\Local\Google\Chrome\Application\chrome.exe'
        return
    
    def _enter_address(self, address):
        return '^l{BS}'+address+'{ENTER}'

    def strings_en(self):
        """strings_<lang> loads the language specific values for the browser.
        For the browser window we need a title or title_re with optional class.
        If you don't supply the class, things like java applets will steal
        focus and we won't be able to get it back."""
        
        self.controls['browser_window'] = {'addrbar_class':'Chrome_OmniboxView',
                                           'title_re': '.*Google Chrome'} 
        self.controls['dialogs'] = [
            # for closing alerts
            {'title_re': 'the page at .* says',
             'type': 'closeable',
             'closer': self.simple_closer},
            # for closing print preview
            {'title_re': 'Print preview .* - Google Chrome',
             'type': 'closeable',
             'closer': self.simple_closer,
             'closer_keys': '^w'}            
        ]
        return
    
browser_class = Chrome13
