#!/usr/bin/env python
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.
import uuid
import Queue
import xmlrpclib
import os

from twisted.internet import task, reactor

from runner.protocols import process
from runner.utils import blade_utils

class Browser(object):
    """
    Our browser interface. 
    """
    def __init__(self, options, _reactor=reactor):
        self.options = options
        self._reactor = _reactor
        self.testcase_delay = float(self.options.testcase_delay)
        # process related properties
        self.process_proto = process.BrowserProcess(self)
        self.exe_name = ''
        self.exe_path = ''
        self.args = []
        self.env = os.environ
        self.is_debugged = bool(options.attach_debugger)
        self.is_fuzzing = bool(options.is_fuzzing)
        # browser specific properties
        self.browser_type = self.options.browser_type
        self.controls = {}
        # wbts/testcase properties
        self.client_id = str(uuid.uuid4())
        self.queue = Queue.Queue()
        self.attempt = 0
        self.wbts = None
    
    def set_strings(self, lang):
        """set_strings sets the various strings we need for finding dialogs
        and window titles. Calls strings_<lang>
        @param lang: The language type that we want to load strings for.
        """
        try:
            get_strings = getattr(self, 'strings_'+lang.strip())
            get_strings()
        except AttributeError, msg:
            print "Unable to get strings for language: %s"%(lang,)
            print msg
            self._reactor.stop()
        return
    
    def add_tests(self, server=None, case_type='all'):
        """add_tests, adds our tests to our queue. If we're just reading a local
        file we simply add the urls (one per line) to the queue. If from wbts
        we call the wbts xml-rpc interface to get the list of tests for the
        selected test_type.
        @param case_type: The test cases to run, usually taken from the xml-rpc
        interface from WBTS.
        """
        if self.options.input_file is not None:
            urls = blade_utils.get_urls_from_file(self.options.input_file)
            for url in urls:
                self.queue.put_nowait(url.strip())
            #self.queue.put(urls)
        else:
            if (server == None):
                print "[*] Error we need to have a valid WBTS server set!"
                exit(-1)
            self.wbts = xmlrpclib.Server(server)
            print "[*] Getting all test cases for type %s"%(case_type,)
            cases = self.wbts.getTestsOfType(case_type)
            for case in cases:
                self.queue.put_nowait(case)
        return
    
    def run_tests(self):
        """run_tests, quick sanity check to make sure we have test cases prior
        to starting our run, if no tests kill the browser and quit. If we do
        have tests, setup our dialog killer looping call.
        TODO: implement fuzzing logic."""
        
        if ( not self.queue.empty() ):
            dialog_killer = task.LoopingCall(self.close_dialogs)
            dialog_killer.start(0.5, False)
            self.run_test()
        else:
            print "[*] No tests to run!"
            self.process_proto.killProcess()
    
    def run_test(self):
        """run_test, makes sure our queue isn't empty, grabs the next
        test case off of the queue and appends the client id. Finally calls
        the browser specific "enter_address" method to type the address into
        the url bar and schedules a task to check the results of the test.
        """
        if (self.queue.empty()):
            print "[*] No more tests to run, exiting."
            self.process_proto.killProcess()
            return

        case = self.queue.get_nowait()
        if (self.options.input_file is not None):
            test_case = case
        else:
            test_case = self.options.target + case + "?client_id="+self.client_id
        self.enter_address(test_case)
        # case id is filename only
        case_id = case[case.rindex('/')+1:]
        # remove the handler part, it is not what is used in the test case
        # this is only necessary when scripts are run "out of origin"
        case_id = case_id.replace('-handler.', '.')
        self._reactor.callLater(self.testcase_delay, self.check_results,
                                case_id)
        
    
    def check_results(self, case_id):
        """check_results, checks the WBTS test case server to see if it
        has results for the test_case. If only browsing urls from a local file
        we only print that we went to the site then schedule the next url. If
        we are using WBTS, we check to see if the server has results for our
        testcase 4 times. If no results after 4 checks, we fail the test and
        move on.
        
        @param case_id: the test case to see if we have a result for server
        side.
        
        """
        if self.options.input_file is not None:
            print "[*] Went to %s"%(case_id,)
            self._reactor.callLater(999, self.run_test)
            return
        if (self.is_fuzzing):
            # TODO: Implement fuzzing logic.
            return
        print "[*] Confirming result for %s"%(case_id,)
        result = self.wbts.getTestProgress(self.client_id, case_id)
        print "[*] Get Progress Returned: %s"%(result)
        if (result == 0):
            if (self.attempt == 0):
                self.attempt = 1
                print "[*] No result, retrying in 1 second"
                reactor.callLater(1, self.check_results, case_id)
            elif(self.attempt == 1):
                self.attempt = 2
                print "[*] No result, retrying in 4 seconds"
                reactor.callLater(4, self.check_results, case_id)
            elif(self.attempt == 2):
                self.attempt = 3
                print "[*] No result, retrying in 8 seconds"
                reactor.callLater(8, self.check_results, case_id)
            else:
                print "[*] No results found, giving up on: %s"%case_id
                self.fail_test(case_id)
                self.attempt = 0
                self.run_test()
        else:
            self.attempt = 0
            self.run_test()
        return
        
    def fail_test(self, case_id):
        """fail_test, forces WBTS to fail the test (we never got results).
        @param case_id: The test case to force failure for.
        """
        ret = self.wbts.failTest(self.client_id, case_id)
        if (ret == -1):
            print "[*] Unable to find testcase of %s to fail!"%((case_id,))
            print "    Or a general error occurred."
        return ret
    
    def close_dialogs(self):
        """close_dialogs, loops through the browsers dialogs and if it finds
        dialogs with the closeable type, it calls its dialog closer func and
        passes in a reference to itself."""
        for dialog in self.controls['dialogs']:
            if dialog['type'] == 'closeable':
                dialog['closer'](dialog)
  
        
    def startup(self):
        """startup, calls our reactor to spawn the process."""
        self._reactor.spawnProcess(self.process_proto, self.exe_path, self.args,
                                   env=self.env)
    
    def process_started(self):
        """called when our ProcessProtocol has launched the browser. If we
        are to debug the process, call attach_debugger."""
        self.pid = self.process_proto.pid
        if (self.is_debugged):
            self.attach_debugger(self.pid)
        

    def process_finished(self):
        """called when the browser process has been stopped/killed."""
        self._reactor.stop()