#!/usr/bin/env python

from twisted.internet import reactor

from runner.browsers.linuxbrowse import LinuxBrowser

class Chrome12(LinuxBrowser):
    def __init__(self, options, _reactor=reactor):
        LinuxBrowser.__init__(self, options, _reactor)
        self.exe_name = 'chrome'
        self.args = [self.exe_name]
        self.exe_path = '/opt/google/chrome/chrome'
        return

    def _enter_address(self, address):
        return '<ctrl>l<bksp>'+address+'<enter>'

    def strings_en(self):
        """strings_<lang> loads the language specific values for the browser.
        For the browser window we need a title or title_re with optional class.
        If you don't supply the class, things like java applets will steal
        focus and we won't be able to get it back."""

        self.controls['browser_window'] = {'field':'txt0',
                                           'title_re': '.*-GoogleChrome'}
        self.controls['dialogs'] = [
            # for closing alerts
            {'title_re': 'dlgWarning',
             'type': 'closeable',
             'closer': self.simple_clicker,
             'object_title': 'btnOK'},
            # for closing confirm()
            {'title_re': 'dlgQuestion',
             'type': 'closeable',
             'closer': self.simple_clicker,
             'object_title': 'btnOK'},
            # for closing page unresponsive titles
            {'title_re': 'dlgPage(s)Unresponsive',
             'type': 'closeable',
             'closer': self.simple_clicker,
             'object_title': 'btnKillpages'},
            # for closing print preview
            {'title_re': 'dlgPrint',
             'type': 'closeable',
             'closer': self.simple_clicker,
             'object_title': 'btnCancel'}
        ]
        return

browser_class = Chrome12
