#!/usr/bin/env python
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.

from twisted.internet import reactor

from runner.browsers.browser import Browser
from runner.automation import winauto

from runner.automation.auto import MultipleWindowsException
from runner.automation.auto import WindowNotFoundException

class WinBrowser(Browser):
    def __init__(self, options, _reactor=reactor):
        Browser.__init__(self, options, _reactor)
        self.automation = winauto.WinAutomate()
        self.set_strings(options.lang)
        
    def enter_address(self, address):
        """enter_address, enters the address in to the main browser window.
        
        @param address: The URL to enter.
        """
        try:
            hwnd = -1
            win_class = None
            if (self.controls['browser_window'].has_key('class')):
                win_class = self.controls['browser_window']['class']
            
            print win_class
            if (self.controls['browser_window'].has_key('title')):
                hwnd = self.automation.find_window(
                    title=self.controls['browser_window']['title'],
                    win_class=win_class)
            elif (self.controls['browser_window'].has_key('title_re')):
                hwnd = self.automation.find_window(
                    title_re=self.controls['browser_window']['title_re'],
                    win_class=win_class)
            
            if (hwnd == -1):
                print "[*] We don't have a window to work with."
                self._reactor.stop()
                
            # see if we can be more specific and get the address control class.
            if (self.controls['browser_window'].has_key('addrbar_class')):
                hwnd = self.automation.find_class(hwnd,
                    self.controls['browser_window']['addrbar_class'])
              
            keys = self._enter_address(address)
            if (isinstance(keys, str)):
                self.automation.type_keys(hwnd, keys)
        except MultipleWindowsException:
            print "Error we have too many windows matching %s "%(
                (self.controls['browser_window'],)
            )
            self._reactor.stop()
        except WindowNotFoundException:
            print "Error we could not find the main browser window %s"%(
                (self.controls['browser_window'])
            )
            self._reactor.stop()
        print "[*] Went to address: %s"%(address,)
        return
    
    def simple_closer(self, dialog):
        """simple_closer for closing dialogs, takes the dialog dict object and
        pulls out the title (or regex based title) to find the window. Once the
        window is found we check to see if we need to send a custom series of
        key strokes or just hit {ESCAPE}.
        @param dialog: The dialog dict object which contains a title or title_re
        as well as the dialog_closer_keys if custom key sequences are needed."""
        hwnd = -1
        try:
            if (dialog.has_key('title_re') ):
                hwnd = self.automation.find_window(
                    title_re=dialog['title_re'])
            else:
                hwnd = self.automation.find_window(title=dialog['title'])

            if (hwnd == -1):
                raise WindowNotFoundException()
            if (dialog.has_key('closer_keys')):
                self.automation.type_keys(hwnd, dialog['closer_keys'])
            else:
                self.automation.type_keys(hwnd, '{ESCAPE}')
        except WindowNotFoundException:
            #print "Window not found"
            pass
        
        return
    
    def attach_debugger(self, pid):
        try:
            from runner.debug.buggery import BuggeryDebugger
        except ImportError, msg:
            print "Unable to attach debugger: "
            print msg
            return
        self.debugger = BuggeryDebugger(pid) 
        self.debugger.attach()
        print "Attaching!"
        
    def finished(self):
        print "all donez"
        return