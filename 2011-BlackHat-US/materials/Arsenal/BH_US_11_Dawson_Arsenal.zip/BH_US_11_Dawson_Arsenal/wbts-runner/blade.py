#!/usr/bin/env python
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.
import sys, os
import xmlrpclib
import socket

from getopt import getopt, GetoptError

from twisted.internet import reactor

from runner.utils import settings, blade_utils

sys.path.append(os.curdir)

def usage():
    print "WBTS Runner Help for %s"%(os.name)
    print "Examples:"
    print "1. Just get the testcase types available."
    print "%s -w http://127.0.0.1/testcases/cases -s"%sys.argv[0]
    print "2. Run only a specific type of cases against the browser."
    print "%s -r headertests -t http://www.attacker.com -b chrome"%sys.argv[0]
    print "-"*79
    print "-h {--help} - this."
    print "-a {--attach} - Attach a debugger (windows only for now)"
    print "-t {--target} [url] - The target hostname+port to use for testcases."
    print "-w {--wbtsurl} [url] - The URL of the WBTS server:\n " \
    "\t\t\t(default: http://127.0.0.1/cases)"
    print "-l {--lang=} [language] - The language type of the windows "\
                      "(default: en)"
    print "-d {--delay=} [seconds] - The time in seconds to wait between tests."
    print "-i {--inputfile=} [file with uris] - Just use a local list of urls."
    print "-b {--browser=} [browser_type] - The browser type: "
    blade_utils.list_supported()
    print "-s {--showtypes} - List all test types"
    print "-r {--runcasetype=} [type_name] - Tests only the cases of a"\
                                " specific type\n\t\t\t\t (default: all)"
    
    return

def main():
    try:
        opts, args = getopt(sys.argv[1:], "hi:w:l:b:asd:t:r:",
                                   ["help", "inputfile=", "wbtsurl=",
                                    "lang=","browser=", "attach", "delay="
                                    "showtypes", "runcasetype="])
    except GetoptError, err:
        # print help information and exit:
        print str(err) # will print something like "option -a not recognized"
        usage()
        sys.exit(2)
    
    cfg = settings.RunnerSettings('runner.cfg')
    # set our timers/defaults
    cfg.testcase_delay = float(cfg.testcase_delay)
    cfg.dialog_timer = float(cfg.dialog_timer)
    cfg.startup_delay = float(cfg.startup_delay)
    cfg.os_type = os.name


    for o, a in opts:
        if o == "-v":
            cfg.verbose = True
        elif o in ("-a", "--attach"):
            cfg.attach_debugger = True
        elif o in ("-t", "--target"):
            cfg.target = a
        elif o in ("-w", "--wbtsurl"):
            cfg.cases_server = a
        elif o in ("-h", "--help"):
            usage()
            sys.exit()
        elif o in ("-l", "--lang"):
            cfg.lang = a
        elif o in ("-b", "--browser"):
            cfg.browser_type = a
        elif o in ("-s", "--showtypes"):
            cfg.show_types = True
        elif o in ("-i", "--inputfile"):
            cfg.input_file = a
        elif o in ("-d", "--delay"):
            cfg.testcase_delay = a
        elif o in ("-r", "--runcasetype"):
            cfg.case_type = a
        else:
            assert False, "unknown option"
    
    if (cfg.show_types == True):
        try:
            ws = xmlrpclib.Server(cfg.cases_server)
            types = ws.getTestTypes()
            for i in xrange(0, len(types)):
                print "- %s"%(types[i])
        except socket.error, msg:
            print "Unable to connect to our cases server"
            print "[%s]"%(cfg.cases_server,)
            print "Error Msg: ",msg
            exit(-3)
        return

    if (cfg.browser_type is None):
        print "We must have a browser type!"
        usage()
        exit(-2)
    
    browser_class = blade_utils.get_browser_class(cfg)
    
    if (browser_class is None):
        print "ERROR: "
        usage()
        print ""
        print "[*] Invalid browser selected, please select a valid browser:"
        blade_utils.list_supported()
        exit(-4)
    
    browser = browser_class(cfg, reactor)
    if (cfg.input_file is None):
        browser.add_tests(server=cfg.cases_server, case_type=cfg.case_type)
    else:
        browser.add_tests()
    browser.startup()
    reactor.callLater(int(cfg.startup_delay), browser.run_tests)
    reactor.run()

if __name__ == '__main__':
    main()
