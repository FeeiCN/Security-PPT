#!/usr/bin/env python
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.
from os import sep
from wbts.web import testing_resources

def testing_support_resources(vhost, mgmt_service):
    """
    This function adds all of the resources (defined in this module) to our
    vhost. If you wish to add more testing support resources, you should do it
    here.
    """
    shared_path = mgmt_service.mVhostService.mVhosts.mSharedPath

    # path to our extra resources (templates etc.)
    resource_path = shared_path+sep+'resources'+sep
    # For header testing, we need to see our requests.
    # Map showRequest for header tests and cookies directories
    vhost.putChild('showRequest', testing_resources.ShowRequest())
          
    # Also for header testing (with forms)
    vhost.putChild('formSubmit',
                   testing_resources.SubmitTestForm(resource_path))

    # Also add our rebind ability
    vhost.putChild('rebind',
                   testing_resources.RebindRequest(mgmt_service.mDnsService))

    # Add a redirect helper resource
    vhost.putChild('redirect', testing_resources.RedirectRequest())

    # for accessing various information.
    vhost.putChild('resourceInfo',
                   testing_resources.GetResourceInfo(mgmt_service))
    
    # Add the Query Getter
    vhost.putChild('getOutput',
                   testing_resources.GetQueryOutput(resource_path))
    # For Saving/Retrieving requests
    vhost.putChild('saveRequest',
                   testing_resources.SaveRequest(mgmt_service))
    vhost.putChild('getRequest',
                   testing_resources.GetRequest(mgmt_service))