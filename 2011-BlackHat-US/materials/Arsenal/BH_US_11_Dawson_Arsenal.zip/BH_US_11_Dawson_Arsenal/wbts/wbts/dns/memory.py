#!/usr/bin/env python
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.

from twisted.names import authority, common, dns

class MemoryAuthority(authority.FileAuthority):
    
    def __init__(self):
        """
        Very simple representation of an authority. This just allows us to
        create authorities on the fly without needing to read/parse a file.
        """
        
        self.soa = None
        self.records = {}
        common.ResolverBase.__init__(self)

        self._cache = {}


### TEST ONLY ###
if __name__ == "__main__":
    x = MemoryAuthority()
    soa_record = dns.Record_SOA(mname="ns1.test.com",
                                rname="root.test.com",
                                serial=2010030701,
                                refresh = '3600',
                                retry = '3600',
                                expire = '3600',
                                minimum = '3600')
    x.soa = ('test.com', soa_record)
    x.records = {}
    x.records[x.soa[0]] = [x.soa[1]]
    newA = dns.Record_A("127.0.0.1", "1H")
    try:
        x.records["xxx.test.com"].append(newA)
    except KeyError:
        x.records["xxx.test.com"] = [newA]
    print x.soa
    print x.records
    print MemoryAuthority().records
    y = MemoryAuthority()
    soa_record2 = dns.Record_SOA(mname="ns1.test2.com",
                                rname="root.test2.com",
                                serial=2010030701,
                                refresh = '3600',
                                retry = '3600',
                                expire = '3600',
                                minimum = '3600')
    y.soa = ('test2.com', soa_record2)
    print " START Y "
    print y.soa
    print y.records
