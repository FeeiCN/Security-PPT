#!/usr/bin/env python
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.

from twisted.application import internet, service
from twisted.web import resource, server, static
from twisted.names import dns
from mgmt_server import WBTSMgmtService, WBTSStorageXR
from vhost_server import WBTSVirtualHostService, WBTSVirtualHostFactoryFromService, WBTSVirtualHostXR
from ssl_factory import ServerContextFactory
from dns_server import WBTSResolverService, WBTSDNSServerFactoryFromService, WBTSResolverXR



def makeService(config):
    static.loadMimeTypes(['mime.types'])
    mgmt_port = config.getCfgValue('ManagementSettings', 'mgmt_port')
    # get our multi service going....
    multiService = service.MultiService()
    
    # Management, this will actually start/setup all other services
    mgmtService = WBTSMgmtService(config, multiService)
    mgmtService.setName('mgmt')
    mgmtService.setServiceParent(multiService)

    mgmtFactory = server.Site(resource.IResource(mgmtService))
    mgmtSiteService = internet.TCPServer(mgmt_port, mgmtFactory)
    mgmtSiteService.setName('mgmtInetService')
    mgmtSiteService.setServiceParent(multiService)
    # End Management
    
    # HTTP
    http_port = config.getCfgValue('WebSettings', 'http_port')
    wbts_vhost_service = WBTSVirtualHostService(config, mgmtService)
    wbts_vhost_service.setName('vhosts')
    wbts_vhost_service.setServiceParent(multiService)
    vhost_site = WBTSVirtualHostFactoryFromService(wbts_vhost_service)
    vhost_inet_service = internet.TCPServer(http_port, vhost_site)
    vhost_inet_service.setName('vhostInetService')
    vhost_inet_service.setServiceParent(multiService)
    
    # Start HTTPS
    ssl_cert = config.getCfgValue('SSLSettings','ssl_cert')
    ssl_port = config.getCfgValue('SSLSettings','ssl_port')
    if (ssl_cert != None and ssl_port != None):
        ssl_site = ServerContextFactory(ssl_cert)
        ssl_inet_service = internet.SSLServer(ssl_port, vhost_site,
                                              ssl_site)
        ssl_inet_service.setName('sslInetService')
        ssl_inet_service.setServiceParent(multiService)
    # End HTTPS
    
    # Start DNS
    dns_resolver_service = WBTSResolverService(mgmtService)
    dns_resolver_service.setName('dns')
    dns_resolver_service.setServiceParent(multiService)
    # End Resolver Service
    
    # TCP DNS
    tcp_dns_factory = WBTSDNSServerFactoryFromService(dns_resolver_service)
    dns_tcp_inet_service = internet.TCPServer(53, tcp_dns_factory)
    dns_tcp_inet_service.setName('dnsTcpInetService')
    dns_tcp_inet_service.setServiceParent(multiService)
    # End TCP DNS

    # UDP DNS
    tcp_udp_factory = dns.DNSDatagramProtocol(tcp_dns_factory)
    dns_udp_inet_service = internet.UDPServer(53, tcp_udp_factory)
    dns_udp_inet_service.setName('dnsUdpInetService')
    dns_udp_inet_service.setServiceParent(multiService)
    # End UDP DNS
    
    
    # Add the XMLRPC Services.
    mgmtService.addServiceXRResources(mgmtService,
                                      WBTSStorageXR,
                                      'dbrpc')
    mgmtService.addServiceXRResources(wbts_vhost_service,
                                      WBTSVirtualHostXR,
                                      'vhostrpc')
    mgmtService.addServiceXRResources(dns_resolver_service,
                                      WBTSResolverXR,
                                      'dnsrpc')
    
    return multiService