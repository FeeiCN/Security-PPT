zone = [
        SOA('victim.com',
            mname = 'ns1.victim.com',
            rname = 'root.victim.com',
            serial = 2003010601,
            refresh = '360',
            retry = '360',
            expire = '500',
            minimum = '360'
        ),
        CNAME('www.victim.com','victim.com', 500),
CNAME('ftp.victim.com','victim.com', 500),
NS('victim.com','ns1.victim.com', 500),
MX('victim.com', 0, 'mail.victim.com', 500),
A('victim.com', '127.0.0.1', 500),
CNAME('sub.victim.com','victim.com', 500),
A('zuh.victim.com', '127.0.0.1', 500),
A('attacker.victim.com', '127.0.0.1', 500),
A('mail.victim.com', '127.0.0.1', 500)
]