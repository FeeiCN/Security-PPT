zone = [
        SOA('attacker.com',
            mname = 'ns1.attacker.com',
            rname = 'root.attacker.com',
            serial = 2003010601,
            refresh = '0',
            retry = '0',
            expire = '0',
            minimum = '0'
        ),
        NS('attacker.com','ns1.attacker.com', 3600),
A('attacker.com', '127.0.0.1', 0),
A('mail.attacker.com', '127.0.0.1', 3600),
MX('mail.attacker.com', 0, 'attacker.com', 3600),
CNAME('ftp.attacker.com','attacker.com', 3600),
CNAME('www.attacker.com','attacker.com', 0),
A('test.attacker.com', '127.0.0.1', 0)
]