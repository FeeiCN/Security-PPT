#!/usr/bin/env python
# -*- test-case-name: wbts.dns_server -*-
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.
from twisted.trial import unittest
import xmlrpclib
#from wbts import storage
#base.DelayedCall.debug = True

def print_msg(msg):
    print msg
    
class WBTSDNSRPCTest(unittest.TestCase):
    def setUp(self):
        """
        THE FOLLOWING TESTS REQUIRE A WBTS INSTANCE TO BE STARTED.
        """
        self.default_authority = 'donkifiedtest.com'
        self.xr = xmlrpclib.Server("http://localhost:9999/dnsrpc")
        self.xr.createAuthority(self.default_authority,
                                "ns1."+self.default_authority,
                                "root."+self.default_authority,
                                 2011010101, '0', '0', '0','0')
        return
    
    def tearDown(self):
        try:
            self.xr.removeAuthority(self.default_authority)
            self.xr.removeAuthority(self.default_authority+".uk")
        except Exception:
            pass
        
        return
    
    def test_removeAuthorityDoesntExist(self):
        ret = self.xr.removeAuthority(self.default_authority+".uk")
        self.assertEqual(ret, False, 'assert non-existent authority returned False')
    
    def test_createAuthority(self):
        ret = self.xr.createAuthority(self.default_authority+".uk")
        self.assertEqual(ret, True, 'assert create authority returned True')
        return
    
    def test_createARecordForAuthority(self):
        ret = self.xr.createRecordForAuthority('A', self.default_authority,
                                               self.default_authority,
                                               '127.0.0.1',
                                               0)
        self.assertEqual(ret, True, 'assert create A record returned True')
    
    def test_createNSRecordForAuthority(self):
        ret = self.xr.createRecordForAuthority('NS', self.default_authority,
                                               self.default_authority,
                                               "ns1."+self.default_authority,
                                               0)
        self.assertEqual(ret, True, 'assert create NS record returned True')
        
    def test_createCNAMERecordForAuthority(self):
        ret = self.xr.createRecordForAuthority('CNAME', self.default_authority,
                                               self.default_authority,
                                               "www."+self.default_authority,
                                               0)
        self.assertEqual(ret, True, 'assert create CNAME record returned True')
    
    def test_createAAAARecordForAuthority(self):
        ret = self.xr.createRecordForAuthority('AAAA', self.default_authority,
                                               self.default_authority,
                                               "0:0:0:0:0:0:0:1",
                                               0)
        self.assertEqual(ret, True, 'assert create AAAA record returned True')
        
    def test_createMXRecordForAuthority(self):
        ret = self.xr.createRecordForAuthority('MX', self.default_authority,
                                               self.default_authority,
                                               0,
                                               "mx."+self.default_authority,
                                               0)
        self.assertEqual(ret, True, 'assert create MX record returned True')
    
    def test_getAllAuthoritiesAsDict(self):
        ret = self.xr.getAllAuthoritiesAsDict()
        self.assertIsInstance(ret, list)

    def test_getAuthorityRecordsAsDict(self):
        ret = self.xr.getAuthorityRecordsAsDict(self.default_authority)
        self.assertIsInstance(ret, dict)
        
        