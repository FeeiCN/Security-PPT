#!/usr/bin/env python
# -*- test-case-name: wbts.config.wbts_config -*-
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.

import os
import ConfigParser

from twisted.trial import unittest

from wbts.config import wbts_config

class WBTSConfigCreateTest(unittest.TestCase):
    def setUp(self):
        self.empty_cfg = os.getcwd()+os.sep+'..'+os.sep+'test'+os.sep+'empty.cfg'
        self.conf = wbts_config.WBTSConfig()
        self.cfgpath = os.getcwd()+os.sep+'..'+os.sep+'test'+os.sep+'wbts.cfg'
        self.conf.mFilename = self.cfgpath
        
    def testNewCfg(self):
        """Tests that we can create a new WBTSConfig"""
        self.failIfEqual(self.conf, None)

    # these tests require a valid configuration file...
    def testOpenCfg(self):
        self.conf.loadCfg()

    def testCfgIsParser(self):
        self.assertIsInstance(self.conf.mConfig, ConfigParser.ConfigParser)

    def testConfigFPisFP(self):
        self.conf.loadCfg()
        self.failIfEqual(self.conf.mConfigFP, None)
    
    def testGetCfgInts(self):
        self.conf.loadCfg()
        
        value = self.conf.getCfgValue('ManagementSettings','mgmt_port')
        self.failIfEqual(value, None)
        self.assertIsInstance(value, int)
        
        value = self.conf.getCfgValue('WebSettings','http_port')
        self.failIfEqual(value, None)
        self.assertIsInstance(value, int)
        
        # we may not have these sections in our config...
        value = self.conf.getCfgValue('DNSSettings','alt_port')
        if (value != None):
            self.assertIsInstance(value, int)
        value = self.conf.getCfgValue('SSLSettings','ssl_port')
        if (value != None):
            self.assertIsInstance(value, int)
        
    def testGetCfgSection(self):
        self.conf.loadCfg()
        value = self.conf.getCfgSectionValues('ManagementSettings')
        self.failIfEqual(value, None)
        self.assertIsInstance(value, dict)
        
        
    # These tests do not require a valid configuration file, an empty config
    # will do.
    def testPortRangeValid(self):
        self.conf.mFilename = self.empty_cfg
        self.conf.openCfg()
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badport', 0,'port'), True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badport', -65535, 'port'), True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badport', 9235802, 'port'),True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badport', 65536, 'port'), True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badport','a', 'port'), True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badport',None, 'port'), True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badport',(), 'port'), True)
        
    def testClassValid(self):
        self.conf.mFilename = self.empty_cfg
        self.conf.openCfg()
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badclass', None, 'class'), True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badclass', 'x', 'class'), True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badclass', 1234, 'class'), True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badclass', "x.x", 'class'), True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badclass', '', 'class'), True)
    
    def testPathValid(self):
        self.conf.mFilename = self.empty_cfg
        test_path = '/'
        if (os.name == 'nt'):
            test_path = "C:\\"
        self.conf.openCfg()
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badpath', test_path, 'path'), False)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badpath', '9v02', 'path'), True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badpath', 1234, 'path'), True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badpath', None, 'path'), True)
        self.failIfEqual(self.conf.addCfgValue('x',
                                               'badpath', '', 'path'), True)
        
    
    def testCallableValidator(self):
        self.conf.mFilename = self.empty_cfg
        def true_func(x):
            return True
        
        def false_func(x):
            return False
        
        self.conf.openCfg()
        true_func_ret = self.conf.addCfgValue('x','x','x','myfunc',true_func)
        false_func_ret = self.conf.addCfgValue('x','x','x','myfunc',false_func)
        self.failIfEqual(false_func_ret, True)
        self.failIfEqual(true_func_ret, False)
        
    def testGetCfgSharedDir(self):
        self.conf.loadCfg()
        shared_root = self.conf.getCfgValue('WebSettings','shared_root')
        self.failIfEqual(shared_root, None)