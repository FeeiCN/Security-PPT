#!/usr/bin/env python
# -*- test-case-name: wbts.storage.pydictdb -*-
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.
from twisted.trial import unittest
from test import helpers
from wbts.storage.pydictdb import WBTSPydictDB
from wbts.storage import storage

def print_msg(msg):
    print msg
    
class WBTSPydictDBTest(unittest.TestCase, helpers.StorageTest):
    def setUp(self):
        self.default_tbl = 'test_tbl'       
        self.path = self.mktemp()
        self.db = WBTSPydictDB(self.path)
        return
    
    def getSaveResult(self, result):
        print result
        return
    
    def tearDown(self):
        self.db.dropTable(self.default_tbl)

       
    def testConnection(self):
        d = self.db.connect()
        d.addCallback(lambda res: self.failIfEqual(res, None,
                                                   "connect returned None."))
        return
    
    def testBadFilePath(self):
        self.db.mFilePath = 1234
        d = self.db.connect()
        d.addCallback(lambda res: self.failIfEqual(res, 0,
                                                   "connect returned from an int."))
        self.assertFailure(d, Exception)
        
        self.db.mFilePath = ""
        d = self.db.connect()
        d.addCallback(lambda res: self.failIfEqual(res, 0,
                                                   "connect returned from an empty str."))
        self.assertFailure(d, Exception)
        return d
    
    def testSave(self):
        self.db.mFilePath = "C:\\\\Research\\\\wbts\\\\release-1.0\\\\wbts.rel-1.2.2011\\\\data\\\\wbts.dat"
        
        def save_this(result):
            d = self.db._save()
            d.addCallback(self.getSaveResult)
            d.addErrback(lambda res: res)
        d = self.db.connect()
        d.addCallback(save_this)
        return d
    