#!/usr/bin/env python
# -*- test-case-name: wbts.storage.mongodb -*-
#Copyright (c) 2011 Isaac Dawson (WBTS Project)
#Permission is hereby granted, free of charge, to any person obtaining a copy 
#of this software and associated documentation files (the "Software"), to deal 
#in the Software without restriction, including without limitation the rights 
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
#copies of the Software, and to permit persons to whom the Software is furnished
#to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
#THE SOFTWARE.
from twisted.trial import unittest
from test import helpers
from wbts.storage.mongodb import WBTSMongoDB
#from wbts import storage
#base.DelayedCall.debug = True

def print_msg(msg):
    print msg
    
class WBTSMongoDBTest(unittest.TestCase, helpers.StorageTest):
    def setUp(self):
        self.default_tbl = 'test_tbl'
        self.db = WBTSMongoDB("127.0.0.1:27017:test_db")
        return
    
    def tearDown(self):
        d = None
        try:
            d = self.db.dropTable(self.default_tbl)
            d.addCallback(lambda res: self.db.disconnect())
        except:
            pass
        
        return d
       
    def testConnection(self):
        def check_dbconn(result):
            self.assertEqual(result, 0, 'connect should return 0 for OK.')
            return
        d = self.db.connect()
        d.addCallback(check_dbconn)
        return d
    
    
