/*
Copyright (c) 2011 Isaac Dawson (WBTS Project)
Permission is hereby granted, free of charge, to any person obtaining a copy 
of this software and associated documentation files (the �gSoftware�h), to deal 
in the Software without restriction, including without limitation the rights 
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED �gAS IS�h, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
THE SOFTWARE.
*/

/*****************************************************************************/
/* WBTSTable - Our custom pagination table. After trying multiple open source
/* versions. I gave up and rolled my own. Here's the process for using:
/* 1. Create the table, passing in the element id for where the table will be
/*    displayed, the JQuery namespace and the data store name.
/* 2. Init the table with your column headings mapped to the object property
/*    name that actually contains the data.
/* 3. Call .getTotal so we can get the total record count for the data store.
/* 3.a. This is async so it will get the totals, then call _cbBuildPagerBar for
/*      building out our bottom pagination bar.	  
/* 4. .getData is called to grab initial results.
/* 5. This is also async and will call either a callback, or _cbBuildTable for
/*    our generic javascript results. buildTable will parse out the js 
/*    results and then call setData to insert the data into the real table.
/* 6. The rest of the code basically handles users changing pages / updating 
/*    how many records to display at one time etc.
/*****************************************************************************/

function WBTSTable(main_table, namespace, db_name) {
	this.table_id = main_table;
	this.namespace = namespace;
	this.db_name = db_name;
	this.table_ele = document.getElementById(main_table); // get the element name.
	this.thead_ele = null;
	this.tbody_ele = null;
	this.data = null;
	this.total_records = 0;
	this.show_count = 20;
}
/************************************************/
/* For building the initial table/initialization*/
/************************************************/
WBTSTable.prototype.init = function(col_mappings) {
	this.col_mappings = col_mappings;
	// build & append head and body elements
	this.thead_ele = document.createElement('thead');
	this.thead_ele.setAttribute('id', this.table_id+"_head");
	this.table_ele.appendChild(this.thead_ele);
	this.tbody_ele = document.createElement('tbody');
	this.tbody_ele.setAttribute('id', this.table_id+"_body");
	this.table_ele.appendChild(this.tbody_ele);
	// add our headers
	this._buildHeaders();
}


WBTSTable.prototype.setColumnWidth = function(col_widths) {
	for (var col in col_widths) {
		var th = $('#'+this.table_id+'_'+col);
		th.css('width',col_widths[col]);
	}
}


/************************************************/
/* Our refresh/export/drop/save results buttons */
/************************************************/

WBTSTable.prototype.refreshResults = function() {
	this.removeStaleRecords();
	$('#'+this.table_id+'_pager').remove(); // remove table

	this.getTotal(); // get total

	// get the data (records to skip, record limit) and build it out.
	this.getData(0, this.show_count);
}

WBTSTable.prototype.exportResults = function(format) {
	document.location = '/download?dbname='+this.db_name+'&type='+format;
}

WBTSTable.prototype.clearResults = function() {
	if (!confirm("Are you sure you want to remove all data from " + this.db_name + "?")) {
		return;
	}
	var xmlrpc = new XmlRpcRequest('/dbrpc','remove');
	xmlrpc.addParam(this.db_name);
	
	function cb(result) {
		var res = result.parseXML();
		if (res == 0) {
			alert("All data has been removed.");
			this.refreshResults();
		} else {
			alert("There was an error removing the data.");
		}
	}
	xmlrpc.send_async(this, cb);
	
}

WBTSTable.prototype.getDbType = function() {
	var xmlrpc = new XmlRpcRequest('/dbrpc', 'get_type');
	function cb(result) {
		// you need to force the save to disk for pydictdb
		var res = result.parseXML();
		if (res == 'pydict') {
			$('#jsresults_save_btn').css('visibility', 'visible');
		}
	}
	xmlrpc.send_async(this, cb);
}

WBTSTable.prototype.saveResults = function() {
	var xmlrpc = new XmlRpcRequest('/dbrpc', 'save');
	function cb(result) {
		var res = result.parseXML();
		if (res == 0) {
			alert("Results saved to disk.");
		} else {
			alert("Failed to save results to disk, please check server logs.");
		}
	}
	xmlrpc.send_async(this, cb);
}

/************************************************/
/* For building the initial table headers       */
/************************************************/

WBTSTable.prototype._buildHeaders = function() {
	var row = document.createElement('tr');
	for (var col in this.col_mappings) {
		//var item = this.col_mappings[i];
		var th = document.createElement('th');
		th.setAttribute("class","result_header ui-state-default");
		th.setAttribute("id", this.table_id+"_"+col);
		th.innerHTML = this.col_mappings[col]; // use column header not mapping value.
		row.appendChild(th);
	}
	$(this.thead_ele).append(row);
	
	
}
/************************************************/
/*  removes old data from our table             */
/************************************************/
WBTSTable.prototype.removeStaleRecords = function() {
	$(this.tbody_ele).empty();
}

/************************************************/
/* Injects the data into our table for display  */
/************************************************/
WBTSTable.prototype.setData = function(data, dialog) {
	var self = this;
	this.data = data
	if (dialog == undefined) {
		dialog = this.showJsDialog;
	}
	if (this.data == undefined) {
		alert("must set data.");
		return;
	}
	// remove old data.
	this.removeStaleRecords();
	
	// loop over each one of our data results (test case results).
	for (var i = 0; i < this.data.length; ++i ) {
		var item = this.data[i];
		var row = document.createElement('tr');
		if (i % 2) {
			row.setAttribute('class','result_row');
		} else {
			row.setAttribute('class', 'result_row_off');
		}
		$(row).bind('click', (function() {
			dialog(self, this.rowIndex);
		}));
		$(row).hover(function() {
				$(this).addClass('result_row_alt');
			},
			function() {
				$(this).removeClass('result_row_alt');
			}
		);
		// loop over each column until we find a property that is in our test result
		// if found, insert the value into our table by creating a new cell and appending it.
		for (var col in this.col_mappings) {
			var td = document.createElement('td');
			td.setAttribute('class', 'result_cell');
			if (item[col] != undefined) {
				td.innerHTML = item[col];
			}
			// if it's empty we'll just append an empty td.
			row.appendChild(td);
		}
		$(this.tbody_ele).append(row);
	}
	//$(this.tbody_ele).append(row);
}


WBTSTable.prototype.showJsDialog = function(self, rowIndex) {
	var jsdialog = $('#'+self.table_id+'_dialog');
	var curr_page = parseInt($('#'+self.table_id+'_curr_page').val());
	var rec_count = parseInt($('#'+self.table_id+'_rec_count').val());
	var idx = rowIndex-1;// + 1;
	
	var result = self.data[idx];
	jsdialog.dialog({ 
		title: 'Results: ' + result.testcase, 
		width: 800,
		modal: false,
		position: 'center',
		hide: 'fadeOut',
		show: 'fadeIn',
		autoOpen: false });
	
	var html_data = '<div class="jsresults_outdata">'+'<b>Result Received Time:</b> ' + result.time;
	html_data += '<br><b>Testcase:</b> ' + result.testcase;
	html_data += '<br><b>Testcase URL:</b> ' + result.testcase_url;
	html_data += '<br><b>Client ID:</b> ' + result.client_id;
	html_data += '<br><b>Test Passed:</b> ' + result.test_passed;
	html_data += '<br><b>Description:</b> ' + result.description;
	html_data += '<br><b>User-Agent:</b> ' + result.user_agent;
	var expected_data = result.expected_result.replace(/\r\n/g, '<br>');
	expected_data = expected_data.replace(/\n/g, '<br>');
	expected_data = expected_data.replace(/\r/g, '<br>');
	html_data += '<br><b>Expected Result:</b> ' + expected_data;
	var result_data = result.result.replace(/\r\n/g, '<br>');
	result_data = result_data.replace(/\n/g, '<br>');
	result_data = result_data.replace(/\r/g, '<br>');
	html_data += '<br><b>Result:</b> ' + result_data;
	html_data += '<br><b>Target Host:</b> ' + result.target_host;
	html_data += '<br><b>Actual Host:</b> ' + result.host;
	var input = result.input.replace(/\r\n/g, '<br>');
	input = input.replace(/\n/g, '<br>');
	input = input.replace(/\r/g, '<br>');
	html_data += '<br><b>Input Data: </b><br>' + input;
	var output = result.output.replace(/\r\n/g, '<br>');
	output = output.replace(/\n/g, '<br>');
	output = output.replace(/\r/g, '<br>');
	html_data += '<br><b>Output Data: </b><br>' + output;
	html_data += '</div>';
	jsdialog.html(html_data);
	jsdialog.dialog('open');
	
}
/************************************************/
/* The bottom pager bar (for pagination...)     */
/* creates 3 columns                            */
/* 1. Show <x> records                          */
/* 2. << < Page X of X > >>                     */
/* 3. total records: X                          */
/************************************************/
WBTSTable.prototype._cbBuildPagerBar = function(total_records) {
	
	if(total_records.xmlData != undefined) {
		this.total_records = total_records.parseXML();
		if (total_records.isFault()) {
			this.total_records = 0;
		}
	} else {
		this.total_records = 0;
	}
	var pager_table = document.createElement('table');
	pager_table.setAttribute('width', '100%');
	pager_table.setAttribute('spacing',0);
	pager_table.setAttribute('id', this.table_id+'_pager');
	var pager_body = document.createElement('tbody');
	var pager_row = document.createElement('tr');
	pager_row.setAttribute('class', 'ui-state-default');
	
	// select records cell...
	var pager_rec_col = document.createElement('td');
	pager_rec_col.setAttribute('width', '33%');
	pager_rec_col.setAttribute('id', this.table_id+'_pagercount');
	pager_rec_col.innerHTML = "Show: ";
	var record_input = this.buildShowRecords(10, 100, 10);
	pager_rec_col.appendChild(record_input);
	
	// show pages << < x of x pages > >>
	var pager_page_col = this._buildPagerLinks(this.total_records);
	
	// total records
	var pager_total_col = document.createElement('td');
	pager_total_col.setAttribute('width', '33%');
	pager_total_col.setAttribute('id', this.table_id+'_pagertotal');
	pager_total_col.setAttribute('align', 'right');
	pager_total_col.innerHTML = "total records: " + this.total_records;
	
	pager_row.appendChild(pager_rec_col);
	pager_row.appendChild(pager_page_col);	
	pager_row.appendChild(pager_total_col);
	
	pager_body.appendChild(pager_row);
	pager_table.appendChild(pager_body);
	$(this.table_ele).after(pager_table);
}


/************************************************/
/* Builds out show pages << < x of x pages > >> */
/* the input text field (curr_page) has an      */
/* onchange event mapped to it, which will      */
/* recalculate and grab the new data            */ 
/************************************************/
WBTSTable.prototype._buildPagerLinks = function(total_records, curr_page_no) {
	if (curr_page_no == undefined) {
		curr_page_no = 1;
	}
	var gotoPage = this.gotoPage;
	var self = this;
	
	var page_col = document.createElement('td');
	page_col.setAttribute('width', '33%');
	page_col.setAttribute('id', this.table_id+'_pagerpage');
	page_col.setAttribute('align','center');
	
	var first_page = this._buildPageLink('&lt;&lt;', (function () { 
		gotoPage.call(self, 'first');})
	);
	var back_page = this._buildPageLink('&nbsp;&lt;&nbsp;', (function () { 
		gotoPage.call(self, 'back');})
	);
	
	// builds out the Page X of X elements.
	var page_txt = document.createTextNode('Page ');
	var curr_page = document.createElement('input');
	curr_page.setAttribute('id', this.table_id+'_curr_page');
	curr_page.setAttribute('value', curr_page_no);
	curr_page.setAttribute('align', 'center');
	curr_page.setAttribute('size', 1);
	$(curr_page).change((function() { 
			var page = parseInt($('#'+self.table_id+'_curr_page').val());
			var limit = parseInt($('#'+self.table_id+'_rec_count').val());
			var total_pages = self.calculateTotalPages(self.total_records);
			if (page > total_pages) {
				return;
			}
			if (page == 0 || page == 1) {
				self.getData(0, limit);
				return;
			} else {
				self.getData((page-1)*limit, limit);//limit*page);
			}
		})
	);
	var total_page_span = document.createElement('span');
	total_page_span.setAttribute('id', this.table_id+'_totalpages');
	this.updateTotalPagesText(total_page_span);

	
	var next_page = this._buildPageLink('&nbsp;&gt;', (function () { 
		gotoPage.call(self, 'next');})
	);
	
	var last_page = this._buildPageLink('&nbsp;&gt;&gt;', (function () { 
		gotoPage.call(self, 'last');})
	);
	
	// append them all together now...
	page_col.appendChild(first_page);
	page_col.appendChild(back_page);
	page_col.appendChild(page_txt);
	page_col.appendChild(curr_page);
	page_col.appendChild(total_page_span);
	page_col.appendChild(next_page);
	page_col.appendChild(last_page);

	return page_col;
	
}

/* This builds the << < > >> links */
WBTSTable.prototype._buildPageLink = function(text, event) {
	var link = document.createElement('a');
	link.innerHTML = text
	link.setAttribute('href', '#');
	link.setAttribute('id', this.table_id+'_link_'+text);

	$(link).bind('click', event);
	return link;
}

/* handles going to the next page. Forces the event to be */
/* called via the trigger method in jquery.               */
WBTSTable.prototype.gotoPage = function(goto_page) {
	var curr_page_ele = $('#'+this.table_id+'_curr_page');
	var curr_page = curr_page_ele.val();
	try {
		curr_page = parseInt(curr_page);
	} catch(e) {
		alert("Error converting our page to a valid number!");
		return;
	}
	var total_pages = this.calculateTotalPages(this.total_records);
	switch (goto_page) {
		case 'first':
			curr_page = 1;
			break;
		case 'back':
			if (curr_page == 1) {
				curr_page = 1;
			} else {
				curr_page -= 1;
			}
			break;
		case 'next':
			if (curr_page+1 > total_pages) {
				break;
			}
			curr_page += 1;
			break;
		case 'last':
			curr_page = total_pages;
			break;
		case 'default':
			curr_page = 1;
			break;
	}
	curr_page_ele.val(curr_page);
	// force the onchange event to be called as it won't otherwise!
	$(curr_page_ele).trigger( $.Event('change') );
}

// calculateTotalPages = takes the total records (int) and calculates how many pages we have
WBTSTable.prototype.calculateTotalPages = function(total_records) {
	var show_count = $('#'+this.table_id+'_rec_count').val();
	// we might not have the element attached yet, so use the default show count.
	if (show_count == undefined) {
		show_count = this.show_count;
	} else {
		show_count = parseInt(show_count);
	}
	var total_pages = Math.floor(total_records / show_count);
	// any remainder means we have an additional page to show
	total_pages += (total_records % show_count) ? 1 : 0;
	return total_pages;
}

// updateTotalPagesText = takes the actual element that contains our 'of <int>' text.
WBTSTable.prototype.updateTotalPagesText = function(total_page_span) {
	// calculate and set total page count.
	total_page_span.innerHTML = ' of ' + this.calculateTotalPages(this.total_records);
}

/*******************************************************/
/* builds select element and options.                  */
/*******************************************************/
WBTSTable.prototype.buildShowRecords = function(min, max, step, callback) {
	var select = document.createElement('select');
	select.setAttribute('id', this.table_id+"_rec_count");
	if (callback == undefined) {
		callback = this._cbChangePageCount;
	}
	var self = this;
	$(select).bind('change', (function () {callback.call(self);}));
	for (var i = min; i <= max; i+=step) {
		var option = document.createElement('option');
		option.setAttribute('value', i);
		option.innerHTML = i;
		if (i == this.show_count) {
			option.setAttribute('selected', 'selected');
		}
		select.appendChild(option);
	}
	return select;
}

// When we change how many records to show, we need to regrab data. 
WBTSTable.prototype._cbChangePageCount = function() {
	try {
		var limit = parseInt($('#'+this.table_id+'_rec_count').val());
		this.updateTotalPagesText($('#'+this.table_id+'_totalpages').get(0));
		// update the current page value to the first page.
		$('#'+this.table_id+'_curr_page').val(1);
		this.show_count = limit; // updates the show_count incase they hit our refresh button.
		this.getData(0, limit);
		// update our total page count.	
	} catch(e) {
		alert("Error converting the record count to an integer! (This should never happen.)");
	}
}

/*******************************************************/
/* For displaying additional details from the table.   */
/*******************************************************/
WBTSTable.prototype.displayRowDetails = function(row_id) {
	if (row_id == undefined) {
		return;
	}
	
}

/*******************************************************/
/* For actually getting the data from our store.       */
/*******************************************************/
// get the total record count and build out our pager bar.
// pass in a callback if you don't want it to build the pager
// bar.
WBTSTable.prototype.getTotal = function(callback) {
    if (callback == undefined) {
		callback = this._cbBuildPagerBar;
	}
	var xmlrpc = new XmlRpcRequest('/dbrpc', 'count');
	xmlrpc.addParam(this.db_name);
	xmlrpc.send_async(this, callback);
}

/* Gets the table data use a callback if you are not passing in the */
/* js results as custom decoding will occur. */
WBTSTable.prototype.getData = function(skip_value, limit_value, callback) {
	if (callback == undefined) {
		callback = this._cbBuildTable;
	}
	var xmlrpc = new XmlRpcRequest('/dbrpc', 'find', skip_value, limit_value);
	xmlrpc.addParam(this.db_name);
	xmlrpc.addParam(parseInt(skip_value));
	xmlrpc.addParam(parseInt(limit_value));
	xmlrpc.send_async(this, callback);
}

// parses the raw results from our xml-rpc response and sets it into our 
// html table.
WBTSTable.prototype._cbBuildTable = function(data) {
	var wbts_ds = this._parseJsResults(data.parseXML());
	this.setData(wbts_ds);
}

// goes through each js result and base64 decodes the properties that 
// require it. This is only really used for our js test results store.
WBTSTable.prototype._parseJsResults = function(data) {
	if (data == null) {
		return null; // return empty if we have no info (most likely because error).
	}
	
	for (var i = 0; i < data.length; ++i) {
		data[i].host = this.decode(data[i].host);
		data[i].target_host = this.decode(data[i].target_host);
		data[i].result = this.decode(data[i].result);
		data[i].expected_result = this.decode(data[i].expected_result);
		data[i].input = this.decode(data[i].input);
		data[i].output = this.decode(data[i].output);
	}	
	return data;
}

// base64 decode data or returns an empty string if we have no data.
WBTSTable.prototype.decode = function(data) {
	if (data == undefined) {
		data = "";
	} else {
		data = b64decode(data.replace(/\n/g,''));
	}
	return data;
}