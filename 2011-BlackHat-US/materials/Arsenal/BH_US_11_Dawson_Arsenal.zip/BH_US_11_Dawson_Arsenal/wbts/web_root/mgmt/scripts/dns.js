/*
Copyright (c) 2011 Isaac Dawson (WBTS Project)
Permission is hereby granted, free of charge, to any person obtaining a copy 
of this software and associated documentation files (the �gSoftware�h), to deal 
in the Software without restriction, including without limitation the rights 
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED �gAS IS�h, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
THE SOFTWARE.
*/

/*********************************************************************************/
/* WBTSDNSService calls our dnsrpc service.                                      */
/* We have a total of 10 possible requests:                                      */
/* 1. loadDomains - gets the authority for the choose authority drop down.       */
/* 2. showRecords - An authority was selected, so fill out the record table.     */
/* 3. createAuthority - prompts a user for the new authority name and creates    */
/*    one with some default values.                                              */ 
/* 4. updateAuthority - Takes in the authority info and updates the authority    */
/*    record.                                                                    */ 
/* 5. removeAuthority - Yehp.                                                    */ 
/* 6. saveAuthority - Saves all changes to disk.                                 */
/* 6. createRecord - prompts the user to choose type/values.                     */
/* 7. updateRecord - updates said record.                                        */
/* 8. removeRecord - Yehp.                                                       */
/*********************************************************************************/
function WBTSDNSService() {
	this.soa_fields = [ "#dns_soa_rname", "#dns_soa_mname", 
						"#dns_soa_serial", "#dns_soa_refresh", 
						"#dns_soa_retry", "#dns_soa_expire", 
						"#dns_soa_minimum"];

	this.valid_records = [ "A", "AAAA", "CNAME", "MX", "NS" ];
	this.current_authority = '';
	this.records = null;
	this.current_record = null;	
}
WBTSDNSService.prototype.init = function() {
	this.getAltServer();
	this.loadDomains();
	var self = this;
	// bind to the onchange event if the value is empty
	// we clear this.current_authority and clear out the
	// input value fields and disable various buttons
	// if we have a valid authority, do the opposite :)
	$("#dns_authority_select").bind('change', (function () {
		// always clear out the authority as we are choosing a new one.
		self.clearAuthority();
		if ($(this).val() == 'Select...') {
			return;
		}
		self.enableAuthorityBtns();
		self.current_authority = $(this).val();
		self.showRecords(self.current_authority);
	}));
}


/*******************************************************/
/* Gets and displays/hides Authorities/Records         */
/*******************************************************/

/* Loads an array of all the authorities via getAuthorities */
WBTSDNSService.prototype.loadDomains = function(callback) {
	if (callback == undefined) {
		callback = this._cbBuildAuthorityList;
	}
	var xmlrpc = new XmlRpcRequest('/dnsrpc', 'getAuthorities');
	xmlrpc.send_async(this, callback);
}

/* takes the xml output and creates a select drop down list of our
/* authorities */
WBTSDNSService.prototype._cbBuildAuthorityList = function(data) {
	var authorities = data.parseXML();
	var select = $("#dns_authority_select");
	// clear out anything that is in it.
	$(select).html("");
	// create a default 'empty' option.
	var option = document.createElement('option');
	option.innerHTML = 'Select...';
	$(select).append(option);

	// create a option for each authority.
	for (var auth in authorities) {
		var option = document.createElement('option');
		option.setAttribute('value', authorities[auth]);
		option.innerHTML = authorities[auth];
		$(select).append(option);
	}
}

/*
sets up our async request to get the data to build our record list.
*/
WBTSDNSService.prototype.showRecords = function(selected, callback) {
	if (callback == undefined) {
		callback = this._cbFillOutRecords;
	}
	var xmlrpc = new XmlRpcRequest('/dnsrpc', 'getAuthorityRecordsAsDict');
	xmlrpc.addParam(selected);
	xmlrpc.send_async(this, callback);
}

/* 
We got our authority, now create the option list of all of the records.
*/
WBTSDNSService.prototype._cbFillOutRecords = function(record_data) {
	var output = "";
	var self = this;
	var record_list = document.createElement('select');
	record_data = record_data.parseXML();
	this.records = record_data;

	$('#dns_authority_legend').html("Records for "+this.current_authority);
	// create the select element for the individual records.
	record_list.setAttribute('id','dns_record_list');
	record_list.setAttribute('name', 'dns_record_list');
	
	// When a record is selected we need to pull out the record
	// id then create a table with the specific details of it.
	$(record_list).bind('change', function () {
		if ($(this).val() == 'Select record...') {
			self.current_record = null; // clear the record.
			self.clearRecords();
			return;
		}
		// display record details.
		self.displayRecord($(this).val());
	});
	// create our empty record selection.
	var select_option = document.createElement('option');
	select_option.setAttribute('value', 'Select record...');
	select_option.setAttribute('selected', 'true');
	$(select_option).html('Select record...');
	record_list.appendChild(select_option);
	
	// create the options/record list.
	this._buildRecordList(record_list, record_data);
	
	
	$('#dns_record').html("Choose a record:");
	$('#dns_record').append(record_list);
	// we can create new records now enable the button.
	this.setButton("#dns_new_rec_btn", false);
		
}

// loops over all of the records and creates the option elements and appends
// it to our select element.
WBTSDNSService.prototype._buildRecordList = function(record_list, record_data) {
	// loop over the names of our records
	for (var name in record_data) {
		// loop over the individual records for the authority
		for (var i = 0; i < record_data[name].length; ++i) {
			var record = record_data[name][i];
			
			/* fill out the option list for our records. Provided it's not an SOA record. */
			var option = document.createElement('option');
			if (record.record_type != 'SOA') {
				// create the drop down list of each record (value is the record id)
				var record_value = name+"|"+record.record_type;
				option.setAttribute('value', record.rec_id);//record_value);
				$(option).html(record_value);
				record_list.appendChild(option);
			} else {
				// fill out the soa table.
				$("#dns_soa_rname").val(record.rname);
				$("#dns_soa_mname").val(record.mname);
				$("#dns_soa_serial").val(record.serial);
				$("#dns_soa_refresh").val(record.refresh);
				$("#dns_soa_retry").val(record.retry);
				$("#dns_soa_expire").val(record.expire);
				$("#dns_soa_minimum").val(record.minimum);
			}
		}
	}
}

// user selected a record, lets build the table and display it
WBTSDNSService.prototype.displayRecord = function(record_id) {
	// loop over the individual record types.
	// keep in mind this also sets the hostname.
	var record = this.getRecordById(record_id);
	if (record == null) {
		alert("Record not found by record id: " + record_id);
		return;
	}
	var record_table = null;
	// clear out anything if it exists.
	this.clearRecords();
	// set our current record.
	this.current_record = record;
	// and create it.
	var record_table = this.buildRecordTable(record);
	if (record_table == null) {
		alert("Unable to get record details!");
		return null;
	}
	// we actually have a table...
	// enable update/remove buttons
	this.enableRecordBtns();
	$('#dns_record_table').append(record_table); 
}

// builds our record for the current authority. Could be A/AAAA/MX/CNAME/NS...
// i know this is terrible, i should really build out the elements by hand
// but i'd much rather write a fuzzer.
WBTSDNSService.prototype.buildRecordTable = function(record) {
	var record_table = '<tbody>';
	// a rec_id of -1 means we have a new record.
	if (record.rec_id == -1) {
		record_table += '<tr><td>hostname: </td><td>';
		record_table += '<input id="dns_record_hostname" value="' + record.hostname + '" name="dns_record_hostname" size="20"></input>';
		record_table += '</td></tr>';
	}

	switch(record.record_type.toString()) {
		case 'SOA':
			break;
		case 'CNAME':
			// fall through
		case 'NS':
			record_table += '<tr><td>name: </td><td>';
			record_table += '<input id="dns_record_name" value="' + record.name + '" name="dns_record_name" size="20"></input>';
			record_table += '</td></tr>';
			break;
		case 'AAAA':
			// fall through
		case 'A':
			record_table += '<tr><td>address: </td><td>';
			record_table += '<input id="dns_record_addr" value="' + record.address + '" name="dns_record_addr" size="20"></input>';
			record_table += '</td></tr>';
			break;
		case 'MX':
			record_table += '<tr><td>name: </td><td>';
			record_table += '<input id="dns_record_name" value="' + record.name + '" name="dns_record_name" size="20"></input>';
			record_table += '</td></tr>';
			record_table += '<tr><td>preference: </td><td>';
			record_table += '<input id="dns_record_pref" value="' + record.preference + '" name="dns_record_pref" size="20"></input>';
			//record_table += '</td></tr></table>';
			break;
		default:
			return null;
	}
	record_table += '<tr><td>ttl: </td><td>';
	record_table += '<input id="dns_record_ttl" value="' + record.ttl + '" name="dns_record_ttl" size="20"></input>';
	record_table += '</td></tr>';
	// add a create button if we are a new record.
	if (record.rec_id == -1) {
		record_table += '</td></tr><tr><td><button onclick="$.wbts.dns._createRecord();">Create</button>';
	}
	record_table += '</td></tr></tbody>';
	
	return record_table;
}



/*******************************************************/
/* Code for our Authorities                            */
/*******************************************************/

WBTSDNSService.prototype.updateAuthority = function() {
	var xmlrpc = new XmlRpcRequest('/dnsrpc', 'updateAuthority');
	var refresh = 0;
	var minimum = 0;
	var expire = 0;
	try {
		refresh = parseInt($('#dns_soa_refresh').val());
		if (isNaN(refresh)) {
			throw ("refresh field is invalid.");
		}
		minimum = parseInt($('#dns_soa_minimum').val());
		if (isNaN(minimum)) {
			throw ("minimum field is invalid.");
		}		
		expire = parseInt($('#dns_soa_expire').val());
		if (isNaN(expire)) {
			throw ("expire field is invalid.");
		}
		retry = parseInt($('#dns_soa_retry').val());
		if (isNaN(retry)) {
			throw ("retry field is invalid.");
		}
	} catch(e) {
		alert("Error updating authority: " + e);
		return;
	}
	
	// check if update succeeded.
	function cb(result) {
		var res = result.parseXML();
		if (res == true) {
			alert("Authority Updated.");
		} else {
			alert("Authority Update Failed, check the server logs.");
		}
	}
	
	this._sendAuthorityRequest(xmlrpc, this.current_authority,
		$('#dns_soa_mname').val(), $('#dns_soa_rname').val(),
		$('#dns_soa_serial').val(), refresh, retry, expire, minimum, cb);
}
/* sends the request to update or create a new authority */
WBTSDNSService.prototype._sendAuthorityRequest = function (xmlrpc, authority_name,
		mname, rname, serial, refresh, retry, expire, minimum, cb) {
	
	xmlrpc.addParam(authority_name);
	xmlrpc.addParam(mname);
	xmlrpc.addParam(rname);
	xmlrpc.addParam(serial);
	xmlrpc.addParam(refresh);
	xmlrpc.addParam(retry);
	xmlrpc.addParam(expire);
	xmlrpc.addParam(minimum);
	xmlrpc.send_async(this, cb);
}

WBTSDNSService.prototype.removeAuthority = function() {
	if (!confirm("Do you really want to delete " + this.current_authority + "?")) {
		return;
	}
	var xmlrpc = new XmlRpcRequest('/dnsrpc', 'removeAuthority');
	xmlrpc.addParam(this.current_authority);
	
	function cb(result) {
		var res = result.parseXML();
		if (res == true) {
			alert("Authority Removed.");
			// remove all the tables/input fields.
			this.clearAuthority();
			// blow away the old domain selection list.
			//$('#dns_authority_select').remove();
			// reload the domain list
			this.loadDomains();
		} else {
			alert("Authority remove request failed, check the server logs");
		}
	}
	xmlrpc.send_async(this, cb);
}

WBTSDNSService.prototype.createAuthority = function() {
	var dnsdialog = $('#dns_dialog');	
	dnsdialog.dialog({ 
		title: 'Add Authority',
		width: 350,
		height: 200,
		modal: true,
		position: 'center',
		hide: 'fadeOut',
		show: 'fadeIn',
		autoOpen: false
	});
	var input_txt = '<table><tbody><tr><td>Authority Name:</td><td><input type="text" id="dns_new_authority" size="20"></input></td>';
	input_txt += '</tr><tr><td><button onclick="$.wbts.dns._createAuthority();">Create</button></tr></td>';
	dnsdialog.html(input_txt);
	dnsdialog.dialog('open');
}

WBTSDNSService.prototype._createAuthority = function() {
	var xmlrpc = new XmlRpcRequest('/dnsrpc', 'createAuthority');
	var name = $('#dns_new_authority').val();
	function cb(result) {
		var res = result.parseXML();
		if (res == true) {
			this.current_authority = null;
			alert("Authority Created.");
			this.clearAuthority();
			this.loadDomains();
		} else {
			alert("Authority Creation Failed, check the server logs.");
		}
	}
	//rname, mname, serial, refresh, retry, minimum, expire, and call back to handle result.
	this._sendAuthorityRequest(xmlrpc, name,'root.'+name, 'ns1.'+name, '2003010601', 3600, 900, 
		3600, 3600, cb);
	$('#dns_dialog').html("");
	$('#dns_dialog').dialog('close');
}

/* saves the authority to disk */
WBTSDNSService.prototype.saveToDisk = function() {
	var xmlrpc = new XmlRpcRequest('/dnsrpc', 'writeRecords');
	function cb(result) {
		var res = result.parseXML();
		if (res == true) {
			alert("All Records Saved.");
		} else {
			alert("Save Authority Failed, check the server logs.");
		}
	}
	xmlrpc.send_async(this, cb);
}


/*******************************************************/
/* Code for our Records                                */
/*******************************************************/


/* Updates the record information for the current selected authority */
WBTSDNSService.prototype.updateRecord = function(new_flag, callback) {
	
	/* 
	xmlrpc args for updateRecordForAuthority:
		rec_id, record_type, authority_name, hostname, *args...)
	*/
	var xmlrpc = null;
	// making a new record
	if (new_flag) {
		xmlrpc = new XmlRpcRequest('/dnsrpc','createRecordForAuthority');
	} else {
		xmlrpc = new XmlRpcRequest('/dnsrpc', 'updateRecordForAuthority');
	}
	var record = this.current_record;
	// make sure we have a record id.
	if (record == null || record.rec_id == undefined) {
		alert("Current record does not have a record id! (This shouldn't happen!)");
		return;
	} 
	if (callback == undefined) {
		callback = this._cbUpdatedRecord;
	}
	var ttl = 0;
	var preference = 0;
	var host = '';
		
	try {
		// add record id
		if (!new_flag) {
			xmlrpc.addParam(parseInt(record.rec_id));
		}
		
		// add record type
		xmlrpc.addParam(record.record_type.toString());
		// add authority name
		xmlrpc.addParam(this.current_authority);
		// add the hostname
		if (new_flag) {
			xmlrpc.addParam($('#dns_record_hostname').val());
		} else {
			xmlrpc.addParam(record.hostname);
		}
		// figure out our type.
		if (record.record_type == 'A' || record.record_type == 'AAAA') {
			host = $('#dns_record_addr').val();
		} else {
			host = $('#dns_record_name').val();	
		}
		// everyone has a ttl field (* but mx's order is different...)
		ttl = parseInt($('#dns_record_ttl').val());
		if (isNaN(ttl)) {
			throw ("ttl field is invalid.");
		}
		// only mx has preference field (args: pref -> name -> ttl )
		if (record.record_type == 'MX') {
			preference = parseInt($('#dns_record_pref').val());
			if (isNaN(preference)) {
				throw ("preference field is invalid.");
			}
			xmlrpc.addParam(preference);
			xmlrpc.addParam(host);
		} else {
			// add the host.
			xmlrpc.addParam(host);
		}
		xmlrpc.addParam(ttl);	
		xmlrpc.send_async(this, callback);
	
	} catch(e) {
		if (new_flag) {
			alert("Error creating record: " + e);
		} else {
			alert("Error updating record: " + e);
		}
		return;
	}
}

WBTSDNSService.prototype._cbUpdatedRecord = function(result) {
	var res = result.parseXML();
	if (res == true) {
		alert("Record Updated.");
	} else {
		alert("Record Update Failed, check the server logs.");
	}
	// just incase update the record with server side data.
	var xmlrpc = new XmlRpcRequest('/dnsrpc', 'getRecordByIdAsDict');
	xmlrpc.addParam(this.current_authority);
	xmlrpc.addParam(this.current_record.rec_id);

	function cb(result) {
		var record = result.parseXML();
		// see if we have a valid record:
		if ('ttl' in record ) {
			var record_table = this.buildRecordTable(record);
			if (record_table == null) {
				alert("There was an error updating the record from the server.");
			}
			this.current_record = record;
			var record_search = this.records[record.hostname.toString()]
			for (var i = 0; i < record_search.length; ++i) {
				if ('rec_id' in record_search[i]) {
					// this is possible because the record id should never change during an update.
					if (parseInt(record_search[i].rec_id) == parseInt(record.rec_id)) {
						// update the record with the one from the server.
						this.records[record.hostname.toString()][i] = record;
						break;
					}
				}
			}
			$('#dns_record_table').html(record_table);
			return;
		}
		alert("Retrieving record information failed, check the server logs.");
		return;
	}
	xmlrpc.send_async(this, cb);
}

WBTSDNSService.prototype.removeRecord = function() {
	var xmlrpc = new XmlRpcRequest('/dnsrpc', 'removeRecordById');
	var warning_prompt = "Do you really want to delete " + this.current_record.hostname;
	warning_prompt += "'s " + this.current_record.record_type + " record from "; 
	warning_prompt += this.current_authority + "?";
	if (!confirm(warning_prompt)) {
		return;
	}
	xmlrpc.addParam(this.current_authority);
	xmlrpc.addParam(this.current_record.rec_id);
	function cb(result) {
		var res = result.parseXML();
		if (res == true) {
			alert("Record Removed.");
		} else {
			alert("Error removing record, please see the server logs.");
			return;
		}
		// Reload the domain.
		this.clearRecords();		
		this.showRecords(this.current_authority);		
	}
	xmlrpc.send_async(this, cb);
}

WBTSDNSService.prototype.createRecord = function() {
	var self = this;
	var xmlrpc = new XmlRpcRequest('/dnsrpc', 'createRecordForAuthority');
	var dnsdialog = $('#dns_dialog');
	dnsdialog.dialog({ 
		title: 'Add Record For: ' + this.current_authority,
		width: 350,
		height: 240,
		modal: true,
		position: 'center',
		hide: 'fadeOut',
		show: 'fadeIn',
		autoOpen: false
	});
	var select_div = document.createElement("div");
	select_div.innerHTML = "Select type: ";
	var select = document.createElement('select');
	select.setAttribute('name','dns_new_record');
	select.setAttribute('id','dns_new_record');
	$(select).bind('change', function() {
		if ($('#dns_new_record_table') != undefined) {
			$('#dns_new_record_table').remove();
		}
		var val = $(this).val();
		if (val == 'Select record...') {
			return;
		}
		var new_record = {
			ttl: 3600,
			hostname: "",
			record_type: val,
			rec_id: -1
		};
		
		if (val == 'A' || val == 'AAAA') {
			new_record.address = "";
		} else {
			new_record.name = "";
		}
		
		if (val == 'MX') {
			new_record.preference = 1;
		}
		var dns_new_table = document.createElement('table');
		dns_new_table.setAttribute('id','dns_new_record_table');
		
		var record_table = self.buildRecordTable(new_record);
		if (record_table == null) {
			alert("Unable to get record details!");
			return null;
		}
		// set the current record to our newly created one.
		self.current_record = new_record;
		// we actually have a table...
		// enable update/remove buttons
		$(dns_new_table).append(record_table);
		$('#dns_dialog').append(dns_new_table); 
	});
	
	var option = document.createElement('option');
	option.setAttribute('value', 'Select...');
	option.innerHTML = 'Select...';
	option.setAttribute('selected', true);
	
	
	select.appendChild(option);
	select_div.appendChild(select);

	
	for (var i = 0; i < this.valid_records.length; ++i) {
		var option = document.createElement('option');
		option.setAttribute('value',this.valid_records[i]);
		option.innerHTML = this.valid_records[i];
		select.appendChild(option);
	}
	
	dnsdialog.html(select_div);
	dnsdialog.dialog('open');
}

WBTSDNSService.prototype._createRecord = function() {
	this.updateRecord(true, this._cbCreateRecord);
}

WBTSDNSService.prototype._cbCreateRecord = function(result) {
	var res = result.parseXML();
	if (res == true) {
		var dnsdialog = $('#dns_dialog');
		dnsdialog.html("");
		dnsdialog.dialog('close');
		alert("Record Created.");
		this.current_record = null; // clear the record.
		
		// Reload the domain.
		this.clearRecords();
		this.showRecords(this.current_authority);
	} else {
		alert("Error creating record, check the server logs.");
	}
	
}


/*******************************************************/
/* Get/Set Alternate DNS Methods                       */
/*******************************************************/

/* Loads the alternate DNS Server fields (server/port) */
WBTSDNSService.prototype.getAltServer = function(callback) {
	if (callback == undefined) {
		callback = this._setAltServerField;
	}
	var xmlrpc = new XmlRpcRequest('/dnsrpc', 'getAlternateDNS');
	xmlrpc.send_async(this, callback);
	
}
/* sets the alternate DNS server input field. */
WBTSDNSService.prototype._setAltServerField = function(result) {
	result = result.parseXML();
	$('#dns_alt_port').val(result.alt_port);
	$('#dns_alt_server').val(result.alt_server);
}

/* updates the alternate dns server with new host/ip and port. */
WBTSDNSService.prototype.updateAltServer = function() {
	var alt_port = -1;
	try {
		alt_port = parseInt($('#dns_alt_port').val());
		var alt_server = $('#dns_alt_server').val();
		if (alt_port > 65535 || alt_port < 1 || isNaN(alt_port)) {
			throw "port > 65535 or < 1 or is not a valid number.";
		} else {
			var xmlrpc = new XmlRpcRequest('/dnsrpc', 'setAlternateDNS');
			xmlrpc.addParam(alt_server);
			xmlrpc.addParam(alt_port);
			function cb(result) {
				var res = result.parseXML();
				if (res == true) {
					alert('Alt Server Updated.');
				} else {
					alert('Alt Server Update Failed.');
				}
			}
			xmlrpc.send_async(this, cb);
			
		}
	} catch(e) {
		alert('Arguments not valid: ' + e);
		return;
	}
}

WBTSDNSService.prototype.reloadFromDisk = function() {
	var xmlrpc = new XmlRpcRequest('/dnsrpc','reloadAuthoritiesFromDisk');
	function cb(result) {
		var res = result.parseXML();
		if (res == true) {
			alert("All authorities have been reloaded.");
		} else {
			alert("There was an error reloading authorities, check the server logs.");
		}
		this.current_record = null; // clear the record.
		this.records = null;
		this.clearAuthority();
		this.loadDomains();
		//this.showRecords(this.current_authority); // re-request our records.
	}
	xmlrpc.send_async(this, cb);
	
}
/*******************************************************/
/* Utility Methods                                     */
/*******************************************************/
// gets the record by it's rec_id
WBTSDNSService.prototype.getRecordById = function(record_id) {
	for (var name in this.records) {
		// loop over the individual records for the authority
		for (var i = 0; i < this.records[name].length; ++i) {
			var record = this.records[name][i];
			if (record.rec_id == record_id) {
				return record;
			}
		}
	}
	return null;
}

/* clears out everything */
WBTSDNSService.prototype.clearAuthority = function() {
	var empty = '...';
	this.current_authority = '';
	this.current_record = null;
	this.disableAuthorityBtns();
	this.clearRecords();
	
	for (var i = 0; i < this.soa_fields.length; ++i) {
		$(this.soa_fields[i]).val(empty);
	}
	this.disableAllRecordBtns();
	$('#dns_authority_legend').html("Authority Records");
	$('#dns_record').html("[Please select an authority...]");
}
// disables buttons and clears the record table //
WBTSDNSService.prototype.clearRecords = function() {
	this.disableRecordBtns();
	$('#dns_record_table').html("");
}

// disables the 'create new record button' as well.
WBTSDNSService.prototype.disableAllRecordBtns = function() {
	this.setButton("#dns_new_rec_btn", true);
	this.disableRecordBtns();
}

WBTSDNSService.prototype.enableAllRecordBtns = function() {
	this.setButton("#dns_new_rec_btn", false);
	this.enableRecordBtns();
}

// for when we have no record selected, but we can still have an authority selected.
WBTSDNSService.prototype.disableRecordBtns = function() {
	this.setButton("#dns_record_btn", true);
	this.setButton("#dns_remove_rec_btn", true);
}

WBTSDNSService.prototype.enableRecordBtns = function() {
	this.setButton("#dns_record_btn", false);
	this.setButton("#dns_remove_rec_btn", false);
}

WBTSDNSService.prototype.disableAuthorityBtns = function() {
	this.setButton("#dns_authority_btn", true);
	this.setButton("#dns_remove_auth_btn", true);
}

WBTSDNSService.prototype.enableAuthorityBtns = function() {
	this.setButton("#dns_authority_btn", false);
	this.setButton("#dns_remove_auth_btn", false);
}



WBTSDNSService.prototype.setButton = function(ele, enable_disable) {
	$(ele).attr("disabled", enable_disable);
}


