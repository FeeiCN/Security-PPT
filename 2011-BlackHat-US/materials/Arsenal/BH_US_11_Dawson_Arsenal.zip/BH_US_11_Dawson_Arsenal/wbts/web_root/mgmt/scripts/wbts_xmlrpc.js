/*
Copyright (c) 2011 Isaac Dawson (WBTS Project)
Permission is hereby granted, free of charge, to any person obtaining a copy 
of this software and associated documentation files (the �gSoftware�h), to deal 
in the Software without restriction, including without limitation the rights 
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED �gAS IS�h, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
THE SOFTWARE.
*/

function WBTSXmlRpc() {
}

WBTSXmlRpc.prototype.getRpcServices = function() {
	var xmlrpc = new XmlRpcRequest('/mgmtrpc', 'listRpcServices')
	function cb(result) {
		var res = result.parseXML();
		if (res.length != undefined) {
			var service = $('#rpc_service');
			service.html("");
			var option = document.createElement('option');
			option.setAttribute('value','Select...');
			option.innerHTML = 'Select...';
			service.append(option);
			for (var i = 0; i < res.length; ++i) {
				var option = document.createElement('option');
				option.setAttribute('value', res[i].toString());
				option.innerHTML = res[i].toString();
				service.append(option);
			}
		} else {
			// wacky, this prolly shouldn't happen but if it does
			// turn the select into an input field...
			this._forceInputField();
		}
	}
	xmlrpc.send_async(this, cb);
}

WBTSXmlRpc.prototype.setService = function() {
	if ($('#rpc_service').val() == 'Select...') {
		return;
	}
	var xmlrpc = new XmlRpcRequest('/'+$('#rpc_service').val(), 'system.listMethods');
	function cb(result) {
		var res = result.parseXML();
		if (res.length != undefined) {
			var method = $('#rpc_method');
			method.html("");
			$('#rpc_method_txt').css('display','none');
			method.css('visibility','visible');
			var option = document.createElement('option');
			option.setAttribute('value','Select...');
			option.innerHTML = 'Select...';
			method.append(option);
			for (var i = 0; i < res.length; ++i) {
				var option = document.createElement('option');
				option.setAttribute('value', res[i].toString());
				option.innerHTML = res[i].toString();
				method.append(option);
			}
		} else {
			this._forceInputField();
		}
	}
	xmlrpc.send_async(this, cb);
}

WBTSXmlRpc.prototype._forceInputField = function() {
	var service = $('#rpc_service_container');
	var method = $('#rpc_method_container');
	service.html('<input type="text" id="rpc_service" value=""></input>');
	method.html('<input type="text" id="rpc_method" value=""></input>');
}

WBTSXmlRpc.prototype.send = function() {
	var service = $('#rpc_service').val();
	var method = $('#rpc_method').val();
	if (service == "" || method == "") {
		alert("We require a service and a method to do anything!");
		return;
	}
	if (service.charAt(0) != '/') {
		service = '/' + service;
	}
	var params = new Array();
	for (var i = 1; i <= 8; ++i) {
		if ($('#rpc_param'+i).val() != "") {
			if ($('#rpc_param_type'+i).val() == 'int') {
				params.push(parseInt($('#rpc_param'+i).val()));
			} else {
				params.push($('#rpc_param'+i).val());
			}
		}
	}
	var xmlrpc = new XmlRpcRequest(service, method);
	
	for (var i = 0; i < params.length; ++i) {
		xmlrpc.addParam(params[i]);
	}
	xmlrpc.send_async(this, this._cb_send);
}

WBTSXmlRpc.prototype._cb_send = function(response_data) {
	var output = $('#rpc_output');
	if (response_data.xmlData == null) {
		alert("Error incorrect service supplied!");
		return;
	}
	var pretty_table = prettyPrint(response_data.parseXML(), {});
	output.html(pretty_table);
}