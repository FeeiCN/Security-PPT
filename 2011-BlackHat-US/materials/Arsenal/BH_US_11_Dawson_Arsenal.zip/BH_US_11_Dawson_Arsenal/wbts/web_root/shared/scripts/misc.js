/*   This file is a part of the WBTS Project. WBTS is a system for helping 
 *	 researchers, and browser implementers to find security related bugs.
 *   Copyright (C) 2010 Isaac Dawson
 *
 *    WBTS is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

var tElement = function(ele_type, dom_id) {
	this.dom_id = dom_id;
	this.dom_loc = null;
	this.orig_loc = '';
	this.name = ele_type;
	this.attribs = '';
	this.loc_attrib = '';
	this.ele = document.createElement(ele_type);
}

tElement.prototype.insertToDom = function() {
	this.dom_loc.appendChild(this.ele);
}

tElement.prototype.insertAttributes = function(attribs) {
	this.attribs = attribs;
	if ( this.attribs.length % 2) {
		return -1;
	}
	for (var i = 0; i < attribs.length; i+=2) {
		this.ele.setAttribute(attribs[i], attribs[i+1]);	
	}
	return 0;
}

tElement.prototype.insertToDOM = function() {
	this.dom_loc.appendChild(this.ele);
	
}

function get_loc_results_cb(tc, objs) {
	tc.output += 'original location values: \n';
	for (var i = 0; i < objs.length; ++i) {
		tc.output += objs[i].name + ': ' + objs[i].dom_id + ' loc: ' + objs[i].orig_loc + '\n';
	}
	tc.output += 'after redirect values: \n';
	for (var i = 0; i < objs.length; ++i) {
		try {
			var ele_t = document.getElementById(objs[i].dom_id);
			var loc = ele_t.getAttribute(objs[i].loc_attrib);
			tc.output += objs[i].name + ': ' + objs[i].dom_id + ' loc: ' + loc + '\n';
			// see if our new href is http://v...
			if (loc.charAt(0) != '/' && loc.charAt(7) == 'v') {
				tc.result = 'updated';
				tc.test_passed = 'false';
			}
		} catch(e) {
			tc.output += 'object: ' + objs[i].name + ' caused an exception: ' + e + '\n';
		}
	}
	
	if (tc.result == '') {
		tc.result = 'not updated';
	}
	tc.saveTest();	
}