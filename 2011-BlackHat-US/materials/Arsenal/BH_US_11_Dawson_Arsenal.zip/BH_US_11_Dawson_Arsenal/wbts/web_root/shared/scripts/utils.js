/*   This file is a part of the WBTS Project. WBTS is a system for helping 
 *	 researchers, and browser implementers to find security related bugs.
 *   Copyright (C) 2010 Isaac Dawson
 *
 *    WBTS is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

var INFO = 0;
var WARNING = 1;
var ALERT = 2;
var ERROR = 3;

/*
 attach_event will attach a callback to an object for a particular event.
 This is/should be browser independent.
*/
function attach_event(obj, event, cb) {
    
    if (obj.addEventListener) {
        // for addEventListener, we remove the 'on' part.
        if (event.indexOf('on') == 0) {
            event = event.substr(2, event.length);
            obj.addEventListener(event, cb, false);
        }
    } else if (obj.attachEvent) {
        obj.attachEvent(event, cb);
    } else {
        obj[event] = cb;
    }
}

function get_local_path() {
	var xhr = get_xhr();
	xhr.open("GET", "/resourceInfo?info=path", false);
	xhr.send()
	if (xhr.readyState == 4) {
		var data = xhr.responseText;
	}
	if (data == "ERROR") {
		return "";
	} else {
		return "file:///" + data;
	} 
}

function object_props(the_object, the_output) {
	for (props in the_object) {
		try {
			the_output.innerHTML += '<font color="blue">' + props + '</font>: ' + the_object[props];
		} catch(e) {
			the_output.innerHTML += '<font color="red">Error with props: ' + props + " " + e + '</font>';
		}
		the_output.innerHTML += '<br>';
	}
}
function str_object_props(the_object) {
	var output = '';
	for (props in the_object) {
		try {
			output += '<font color="blue">' + props + '</font>: ' + the_object[props];
		} catch(e) {
			output += '<font color="red">Error with props: ' + props + " " + e + '</font>';
		}
		output += '<br>';
	}
	return output;
}

function printout(the_element) {
   var output = document.getElementById('output');
   if (output == null) {
       output = document.body;
   }
   output.appendChild(the_element);
}

function get_client_id() {
	var client_id = document.location.search.split("?client_id=");
	if (client_id.length == 2) {
		return client_id[1];
	}
	return "";
	
}

function debugLog(level, log_msg) {
   var msg = document.createElement("font");
   var newline = document.createElement("br");
   var msgText;
   switch(level) {
		case INFO:
			msgText = "INFO: ";
			msg.color = "black";
			break;
		case WARNING:
			msgText = "WARNING: ";
			msg.color = "green";
			break;
		case ALERT:
			msgText = "ALERT: ";
			msg.color = "orange";
			break;
		case ERROR:		
			msgText = "ERROR: ";
			msg.color = "red";
			break;
		default:
			break;
	}
	msgText += log_msg;
	msg.appendChild(document.createTextNode(msgText));
	printout(msg);
	printout(newline);
}

function getTotal(k, setlen) {
	var ret = 1;
	for (var i = 0; i < k; i++) {
		ret *= setlen;
	}
	return ret;
}
// fake guid generator 
// mainly for consistency sake...
// taken from: http://note19.com/2007/05/27/javascript-guid-generator/
function S4() {
   return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
}
function fake_guid() {
   return (S4()+S4()+"-"+S4()+"-"+S4()+"-"+S4()+"-"+S4()+S4()+S4());
}