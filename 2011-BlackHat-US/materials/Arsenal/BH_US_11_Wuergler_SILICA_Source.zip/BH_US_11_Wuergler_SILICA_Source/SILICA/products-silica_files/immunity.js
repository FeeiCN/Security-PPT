var preloadFlag = false;

//function preloadImages() {
//if (document.images) {


img1 = new Image();
img1.src = "images/nav-company-01.gif";

img2 = new Image();
img2.src = "images/nav-news-01.gif";


img3 = new Image();
img3.src = "images/nav-products-01.gif";

img4 = new Image();
img4.src = "images/nav-services-01.gif";


img5 = new Image();
img5.src = "images/nav-education-01.gif";

img6 = new Image();
img6.src = "images/nav-downloads-01.gif";


img7 = new Image();
img7.src = "images/nav-resources-01.gif";

img8 = new Image();
img8.src = "images/nav-partners-01.gif";

img9 = new Image();
img9.src = "images/nav-resellers-01.gif";

img10 = new Image();
img10.src = "images/nav-clientlogin-01.gif";

preloadFlag = true;

//	}
//}

function changeImages(whichImage, whichFile) {
	if(preloadFlag) {
	if (document.images) {
		whichImage.src = "images/" + whichFile + ".gif";
	}
}}


function changeImages(whichImage, whichFile, whichDiv) {
	if(preloadFlag) {
	if (document.images) {
		if( document[whichDiv] )
			document[whichDiv].document[whichImage].src = "images/" + whichFile + ".gif";
		else
			document[whichImage].src = "images/" + whichFile + ".gif";
	}
}}


function popUp(URL) {
day = new Date();
id = day.getTime();
eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=1,scrollbars=0,location=0,statusbar=1,menubar=1,resizable=0,width=800,height=400,left = 112,top = 84');");
}
