#!/usr/bin/perl
# 
# Payload Module
# by nitr0us (nitrousenador@gmail.com)
# http://chatsubo-labs.blogspot.com
#
# This module takes the text file passed as a parameter (-p filename),
# replaces the 'TRAVERSAL' token within the file by the traversal
# fuzz patterns and sends the payload (file content + fuzz patterns)
# to the target (-h switch) in the specified port (-x switch).
# (e.g. a file that contains an HTTP request including cookies, 
# session ids, variables, etc. and the 'TRAVERSAL' tokens within the
# request that will be fuzzed)
#

package DotDotPwn::Payload;
use Exporter 'import';
@EXPORT = qw(FuzzPayload);

use IO::Socket;
use Time::HiRes qw(usleep);

sub FuzzPayload{
	my ($host, $port, $payload) = @_;
	my $sock, $response;
	our $n_travs = 0;
	my $foo = 0; # Used as an auxiliary variable in quiet mode (see below)

	open(REPORT , ">>$main::report");

	foreach $traversal (@main::traversals){
		$tmp_payload = $payload;
		$tmp_payload =~ s/TRAVERSAL/$traversal/g;

		if(!($sock = IO::Socket::INET->new(	PeerAddr => $host,
							PeerPort => $port,
							Proto => 'tcp'))){ # You can replace 'tcp' by 'udp' in case of ...
			my $runtime = time - $main::start_time;
			for my $fh (STDOUT, REPORT) {
				printf $fh "\n[+] Fuzz testing finished after %.2f minutes ($runtime seconds)\n", ($runtime / 60);
				print  $fh "[+] Total Traversals found (so far): $n_travs\n";
			}
			die "[-] Host $host didn't respond on port $port!\n";			
		}

		print $sock $tmp_payload;

		$sock->read($response, 8192);

		if($response =~ /$main::pattern/s ){
			for my $fh (STDOUT, REPORT) { print $fh "\n[*] VULNERABLE PAYLOAD:\n$tmp_payload\n"; }
			$n_travs++;

			return $n_travs if $main::break;

			usleep($main::time);
			next;
		}

		$sock->close();

		if($main::quiet){
			print ". " unless $foo++ % $main::dot_quiet_mode;
		} else{
			print "[*] Payload with: $traversal\n";
		}

		usleep($main::time);
	}

	return $n_travs;
}
