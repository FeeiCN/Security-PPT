The authoritative documentation is maintained at:
http://code.google.com/p/capirca/wiki/

The documentation in this directory is intended to provide text copies of the
wiki documentation, but may be updates less frequently and as a result may not
be as current as the wiki.

--
Paul (Tony) Watson
