int net_l2_register(int* a1, int a2, int* a3, int* a4, int a5, int a6){
	return 1;
}

int net_l2_send(int a1, int* a2, int* a3, int* a4, int a5, int* a6){
	return 1;
}
