int zc_init(void){
    return 1;
}
