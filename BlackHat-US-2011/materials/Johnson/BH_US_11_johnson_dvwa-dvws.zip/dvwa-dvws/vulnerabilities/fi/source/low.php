<?php

	$file = $_GET['page']; //The page we wish to display 

?>