<?php

// Remove any of the charactars in the array (blacklist).
	$substitutions = array(
		'&&' => '',
		';' => '',
	);

	$sani_command = str_replace( array_keys( $substitutions ), $substitutions, $command );

exec($sani_command, $output);
	$results = "";
	while (list($key, $val) = each($output)): 
		$results = $results . $val;
	endwhile;
        return $results;
    
?>