<?php

exec($command, $output);
	$results = "";
	while (list($key, $val) = each($output)): 
		$results = $results . $val;
	endwhile;
        return $results;

?>