<?php

define( 'DVWA_WEB_PAGE_TO_ROOT', '../../../' );
require_once DVWA_WEB_PAGE_TO_ROOT.'dvwa/includes/dvwaPage.inc.php';

dvwaPageStartup( array( 'authenticated', 'phpids' ) );

dvwaDatabaseConnect();

// Pull in the NuSOAP code
require_once DVWA_WEB_PAGE_TO_ROOT.'vulnerabilities/webservices/lib/nusoap.php';

// Create the server instance
$server = new soap_server();
// Initialize WSDL support
$server->configureWSDL('xss_pwsdl', 'urn:xss_pwsdl');
// Register the method to expose
$server->register('xss_p',                // method name
    array('name' => 'xsd:string'),        // input parameters
    array('return' => 'xsd:string'),      // output parameters
    'urn:xss_pwsdl',                      // namespace
    'urn:xss_pwsdl#xss_p',                // soapaction
    'rpc',                                // style
    'encoded',                            // use
    'Injects content to display via the web application'            // documentation
);
// Define the method as a PHP function
function xss_p($id) {

	// Retrieve all the data from the "example" table
	$result = mysql_query("SELECT first_name, last_name FROM users WHERE user_id = '$id'") or die(mysql_error());
	
	while($row = mysql_fetch_array( $result )) {
	// Print out the contents of the entry 

	$results = "First Name: ".$row['first_name'];
	$results = $results . " Last Name: ".$row['last_name'];

	}
        return $results;
}
// Use the request to (try to) invoke the service
$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($HTTP_RAW_POST_DATA);

?>
