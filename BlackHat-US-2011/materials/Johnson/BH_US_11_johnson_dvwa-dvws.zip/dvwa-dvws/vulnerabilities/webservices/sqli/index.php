<?php

define( 'DVWA_WEB_PAGE_TO_ROOT', '../../../' );
require_once DVWA_WEB_PAGE_TO_ROOT.'dvwa/includes/dvwaPage.inc.php';

dvwaPageStartup( array( 'authenticated', 'phpids' ) );

dvwaDatabaseConnect();

// Pull in the NuSOAP code
require_once DVWA_WEB_PAGE_TO_ROOT.'vulnerabilities/webservices/lib/nusoap.php';

// Create the server instance
$server = new soap_server();
// Initialize WSDL support
$server->configureWSDL('sqliwsdl', 'urn:sqliwsdl');
// Register the method to expose
$server->register('sqli',                // method name
    array('name' => 'xsd:string'),        // input parameters
    array('return' => 'xsd:string'),      // output parameters
    'urn:sqliwsdl',                      // namespace
    'urn:sqliwsdl#sqli',                // soapaction
    'rpc',                                // style
    'encoded',                            // use
    'Queries the database of contacts'            // documentation
);
// Define the method as a PHP function
function sqli($id) {

	$vulnerabilityFile = '';
	switch( $_COOKIE[ 'security' ] ) {
		case 'low':
			$vulnerabilityFile = 'low.php';
			break;
	
		case 'medium':
			$vulnerabilityFile = 'medium.php';
			break;
	
		case 'high':
		default:
			$vulnerabilityFile = 'high.php';
			break;
	}
	
	require_once DVWA_WEB_PAGE_TO_ROOT."vulnerabilities/sqli/source/{$vulnerabilityFile}";
	
}
// Use the request to (try to) invoke the service
$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($HTTP_RAW_POST_DATA);

?>
