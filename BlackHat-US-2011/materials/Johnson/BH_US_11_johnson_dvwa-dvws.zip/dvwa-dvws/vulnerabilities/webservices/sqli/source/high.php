<?php	

$id = stripslashes($id);
$id = mysql_real_escape_string($id);

// Retrieve all the data from the "example" table
$result = mysql_query("SELECT first_name, last_name FROM users WHERE user_id = '$id'") or die(mysql_error());

while($row = mysql_fetch_array( $result )) {
// Print out the contents of the entry 

$results = "First Name: ".$row['first_name'];
$results = $results . " Last Name: ".$row['last_name'];

}
return $results;

?>
