MANDIANT Heap Inspector
Version 1.1
July 26, 2011
------------------------------

Manifest:
* HeapInspector32.exe - 32-bit application
* HeapInspector64.exe - 64-bit application
* Be.Windows.Forms.HexBox.dll - BE HexBox editor control
* Heap Inspector User Manual.pdf - user manual
* spray_calc.html - harmless HTML/javascript page that uses a basic heap spray to fill a portion of heap memory with shellcode to launch calc.exe.  No vulnerability is exploited, so there is no code execution.  It simply allocates a large amount of heap space for instructional/demonstration purposes.
* LICENSE.txt - license for this tool, HexBox hex editor control, and Stephen Fewer's reflective DLL injector technique
* README.txt - this readme file

------------------------------
aaron.lemasters@mandiant.com
@lilhoser