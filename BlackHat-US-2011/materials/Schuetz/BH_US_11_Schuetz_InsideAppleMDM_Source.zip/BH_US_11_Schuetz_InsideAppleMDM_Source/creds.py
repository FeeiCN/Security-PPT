
# these will be filled in by the server when a device enrolls

my_PushMagic = ''
my_DeviceToken = ''
my_UnlockToken = ''
