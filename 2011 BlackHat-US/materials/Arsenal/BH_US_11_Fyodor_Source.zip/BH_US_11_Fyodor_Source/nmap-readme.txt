==Nmap at the Black Hat Arsenal==
Wednesday, August 3, 4:45PM - 6:00PM

Fyodor will be answering questions and showing off Nmap at the Black
Hat Arsenal on Wednesday.  Windows and Mac OS X installers for the
latest version are on this conference CD, as is the source code for
Linux/UNIX systems.  Detailed installation instructions (in case you
need them) are available at:

http://nmap.org/book/install.html

You can also find these and other packages (including Linux 32 and 64
bit binaries and Windows executable zip files) at the Nmap download
page:

http://nmap.org/download.html

Sincerely,
Fyodor
