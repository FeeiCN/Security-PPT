#!/usr/bin/env python
#Taint visualization in 2d
# this is a very rudimentry tool, meant to show the potential to visualize taint flow in a program
# every line represents an "ERA" meaning a cycle of accesses to tainted data with no repeats
# every box represents tainted data
# BLACK = was tainted then untainted
# the color shade represents the current address and address of taint source

BOX_SIZE = 5	#size of box representing a tainted address

#init GFX
import Tkinter as tkinter

root = tkinter.Tk()


def pixel(image, pos, color):
    """Place pixel at pos=(x,y) on image, with color=(r,g,b)."""
    r,g,b = color
    x,y = pos
    image.put("#%02x%02x%02x" % (r,g,b), (y, x))

def box(image, pos, color, a):
    """Place box at pos=(x,y) on image, with color=(r,g,b)."""
    xb, yb = pos
    for x_o in range(a):
       for y_o in range(a):
          pixel(image, (xb+x_o, yb+y_o), color)

#init drwaing area 
photo = tkinter.PhotoImage(width=1024, height=300)

#open our log file for processing
f = open('taint.out','r')
lines = f.readlines()
f.close()

#what sources of taint have we seen lately - ERA
ERA = []	
#we move to the next line we are drawing only if we run
#into a source we already drew in this line

Y = 0  #line to draw in
for l in lines:
   if l.split()[0] == 'T':
      if (int(l.split()[3], 16) in ERA):
         #new "ERA"
         ERA = []
         Y += BOX_SIZE
      else:
         #still same "ERA"
         ERA.append(int(l.split()[3], 16))
      R = 255
      G = int(l.split()[1][0:2], 16)
      B = 255 - (int(l.split()[3], 16) * 20) # the * 20 is to make it easier to see
   else:
      #something was "UnTainted"
      R = 0
      G = 0
      B = 0
   X = int(l.split()[1][6:8], 16) * BOX_SIZE
   
   box(photo, (Y,X), (B,G,R), BOX_SIZE)

label = tkinter.Label(root, image=photo)
label.grid()
root.mainloop()

