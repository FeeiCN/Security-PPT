/*BEGIN_LEGAL 
Intel Open Source License 

Copyright (c) 2002-2011 Intel Corporation. All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.  Redistributions
in binary form must reproduce the above copyright notice, this list of
conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.  Neither the name of
the Intel Corporation nor the names of its contributors may be used to
endorse or promote products derived from this software without
specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE INTEL OR
ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
END_LEGAL */

/*! @file
 *  Basic taint analyzer
 *  This taint analyzer only supports the propogation of taint through
 *  MOV family of instructions and does not retain the taint source
 */

#include "pin.H"
#include <iostream>
#include <fstream>
#include <set>
#include <string.h>
#include "xed-iclass-enum.h"

/* ================================================================== */
// Global variables 
/* ================================================================== */

set<ADDRINT> TaintedAddrs;   // tainted memory addresses
bool TaintedRegs[REG_LAST];  // tainted registers
std::ofstream out;           // output file

/* ===================================================================== */
// Command line switches
/* ===================================================================== */
KNOB<string> KnobOutputFile(KNOB_MODE_WRITEONCE,  "pintool",
    "o", "taint.out", "specify file name for the output file");


/* ===================================================================== */
// Utilities
/* ===================================================================== */

/*!
 *  Print out help message.
 */
INT32 Usage()
{
    cerr << "This tool follows the taint defined by the first argument to " << endl <<
            "the instumented program command line and outputs details to a file" << endl << endl;

    cerr << KNOB_BASE::StringKnobSummary() << endl;

    return -1;
}

/* ===================================================================== */
// Analysis routines
/* ===================================================================== */

//dump taint information to the log file
VOID DumpTaint()
{
    out <<  "===============================================" << endl;
    
    out <<  "Tainted Memory: " << endl;
    set<ADDRINT>::iterator it;
    for ( it=TaintedAddrs.begin() ; it != TaintedAddrs.end(); it++ )
    {
        out << " " << *it;
    }
    out << endl << "***" << endl << "Tainted Regs:" << endl;

    for (int i=0; i < REG_LAST; i++)
    {
        if (TaintedRegs[i])
        {
            out << REG_StringShort((REG)i);
        }
    }

    out <<  "===============================================" << endl;
}

// This function marks the contents of argv[1] param to "main" as tainted
VOID MainAddTaint(unsigned int argc, char *argv[])
{
    if (argc != 2)
    {
        return;
    }

    int n = strlen(argv[1]);
    ADDRINT taint = (ADDRINT)argv[1];
    for (int i = 0; i < n; i++)
    {
        TaintedAddrs.insert(taint + i);
    }

    DumpTaint();
}

// This function represents the case of a register copied to memory
void RegTaintMem(ADDRINT reg_r, ADDRINT mem_w)
{
    out << REG_StringShort((REG)reg_r) << " --> " << mem_w << endl;

    if (TaintedRegs[reg_r]) 
    {
        TaintedAddrs.insert(mem_w);
    }
    else //reg not tainted --> mem not tainted
    {
        if (TaintedAddrs.count(mem_w)) // if mem is already not tainted nothing to do
        {
            TaintedAddrs.erase(TaintedAddrs.find(mem_w));
        }
    }
}

// this function represents the case of a memory copied to register
void MemTaintReg(ADDRINT mem_r, ADDRINT reg_w, ADDRINT inst_addr)
{
    out << mem_r << " --> " << REG_StringShort((REG)reg_w) << endl;

    if (TaintedAddrs.count(mem_r)) //count is either 0 or 1 for set
    {
        TaintedRegs[reg_w] = true;
    }
    else //mem is clean -> reg is cleaned
    {
        TaintedRegs[reg_w] = false;
    }
}

// this function represents the case of a reg copied to another reg
void RegTaintReg(ADDRINT reg_r, ADDRINT reg_w)
{
    out << REG_StringShort((REG)reg_r) << " --> " << REG_StringShort((REG)reg_w) << endl;

    TaintedRegs[reg_w] = TaintedRegs[reg_r];
}

// this function represents the case of an immediate copied to a register
void ImmedCleanReg(ADDRINT reg_w)
{
    out << "const --> " << REG_StringShort((REG)reg_w) << endl;

    TaintedRegs[reg_w] = false;
}

// this function represents the case of an immediate copied to memory
void ImmedCleanMem(ADDRINT mem_w)
{
    out << "const --> " << mem_w << endl;

    if (TaintedAddrs.count(mem_w)) // if mem is already not tainted nothing to do
    {
        TaintedAddrs.erase(TaintedAddrs.find(mem_w));
    }
}


/* ===================================================================== */
// Instrumentation callbacks & Helpers
/* ===================================================================== */

// True if the instruction has an immediate operand
// meant to be called only from instrumentation routines
bool INS_has_immed(INS ins)
{
    for (unsigned int i = 0; i < INS_OperandCount(ins); i++)
    {
        if (INS_OperandIsImmediate(ins, i))
        {
            return true;
        }
    }
    return false;
}

// returns the full name of the first register operand written
REG INS_get_write_reg(INS ins)
{
    for (unsigned int i = 0; i < INS_OperandCount(ins); i++)
    {
        if (INS_OperandIsReg(ins, i) && INS_OperandWritten(ins, i))
        {
            return REG_FullRegName(INS_OperandReg(ins, i));
        }
    }
    
    return REG_INVALID();
}

// returns the full name of the first register operand read
REG INS_get_read_reg(INS ins)
{
    for (unsigned int i = 0; i < INS_OperandCount(ins); i++)
    {
        if (INS_OperandIsReg(ins, i) && INS_OperandRead(ins, i))
        {
            return REG_FullRegName(INS_OperandReg(ins, i));
        }
    }
    
    return REG_INVALID();
}

/*!
 * This function checks for each instruction if it does a mov that can potentially
 * transfer taint and if true adds the approriate analysis routine to check 
 * and propogate taint at run-time if needed
 * This function is called every time a new trace is encountered.
 */
VOID Trace(TRACE trace, VOID *v)
{
  for (BBL bbl = TRACE_BblHead(trace); BBL_Valid(bbl); bbl = BBL_Next(bbl))
  {
    for (INS ins = BBL_InsHead(bbl); INS_Valid(ins); ins = INS_Next(ins))
    {
        if ( (INS_Opcode(ins) >= XED_ICLASS_MOV) && (INS_Opcode(ins) <= XED_ICLASS_MOVZX) )
        {
            if (INS_has_immed(ins))
            {
                if (INS_IsMemoryWrite(ins)) //immed -> mem
                {
                    INS_InsertCall(ins, IPOINT_BEFORE, (AFUNPTR)ImmedCleanMem,
                                            IARG_MEMORYOP_EA, 0,
                                            IARG_END);
                }
                else						//immed -> reg
                {
                    REG insreg = INS_get_write_reg(ins);
                    INS_InsertCall(ins, IPOINT_BEFORE, (AFUNPTR)ImmedCleanReg,
                                            IARG_ADDRINT, (ADDRINT)insreg,
                                            IARG_END);
                }
            }
            else if (INS_IsMemoryRead(ins)) //mem -> reg 
            {
                //in this case we call MemTaintReg to copy the taint if relevant
                REG insreg = INS_get_write_reg(ins);
                INS_InsertCall(ins, IPOINT_BEFORE, (AFUNPTR)MemTaintReg,
                                        IARG_MEMORYOP_EA, 0,
                                        IARG_ADDRINT, (ADDRINT)insreg, IARG_INST_PTR,
                                        IARG_END);

            }
            else if (INS_IsMemoryWrite(ins)) //reg -> mem 
            {
                //in this case we call RegTaintMem to copy the taint if relevant
                REG insreg = INS_get_read_reg(ins); 
                INS_InsertCall(ins, IPOINT_BEFORE, (AFUNPTR)RegTaintMem,
                                        IARG_ADDRINT, (ADDRINT)insreg,
                                        IARG_MEMORYOP_EA, 0,
                                        IARG_END);
            }
            else if (INS_RegR(ins, 0) != REG_INVALID()) //reg -> reg
            {
                //in this case we call RegTaintReg
                REG Rreg = INS_get_read_reg(ins); 
                REG Wreg = INS_get_write_reg(ins); 
                INS_InsertCall(ins, IPOINT_BEFORE, (AFUNPTR)RegTaintReg,
                                        IARG_ADDRINT, (ADDRINT)Rreg,
                                        IARG_ADDRINT, (ADDRINT)Wreg,
                                        IARG_END);
            }
            else	//should never happen
            {
                out << "serious error?!\n" << endl;
            }
        } // IF opcode is a MOV
    }  // For INS
  }  // For BBL
} // VOID Trace


/*!
 * Routine instrumentaiton, called for every routine loaded
 * this function adds a call to MainAddTaint on the main function 
 */
VOID Routine(RTN rtn, VOID *v)
{
    RTN_Open(rtn);
    
    if (RTN_Name(rtn) == "main") //if this is the main function
    {
        RTN_InsertCall(rtn, IPOINT_BEFORE, (AFUNPTR)MainAddTaint,
                       IARG_FUNCARG_ENTRYPOINT_VALUE, 0,
                       IARG_FUNCARG_ENTRYPOINT_VALUE, 1,
                       IARG_END);
    }

    RTN_Close(rtn);	
}


/*!
 * Print out the taint analysis results.
 * This function is called when the application exits.
 */
VOID Fini(INT32 code, VOID *v)
{
    DumpTaint();
    out.close();
}



/*!
 * The main procedure of the tool.
 * This function is called when the application image is loaded but not yet started.
 * @param[in]   argc            total number of elements in the argv array
 * @param[in]   argv            array of command line arguments, 
 *                              including pin -t <toolname> -- ...
 */
int main(int argc, char *argv[])
{
    // Initialize PIN library. Print help message if -h(elp) is specified
    // in the command line or the command line is invalid 
    PIN_InitSymbols();

    if( PIN_Init(argc,argv) )
    {
        return Usage();
    }
    
    // Register function to be called to instrument traces
    TRACE_AddInstrumentFunction(Trace, 0);
    RTN_AddInstrumentFunction(Routine, 0);

    // Register function to be called when the application exits
    PIN_AddFiniFunction(Fini, 0);
    
    cerr <<  "===============================================" << endl;
    cerr <<  "This application is instrumented by MyPinTool" << endl;
    if (!KnobOutputFile.Value().empty()) 
    {
        cerr << "See file " << KnobOutputFile.Value() << " for analysis results" << endl;

        string fileName = KnobOutputFile.Value();
        out.open(fileName.c_str());
        out << hex;
    }
    cerr <<  "===============================================" << endl;

    // Start the program, never returns
    PIN_StartProgram();
    
    return 0;
}

/* ===================================================================== */
/* eof */
/* ===================================================================== */
