// Vulnerable example code
// This program does a "double free" twice
//
// In modern Linux systems you need to do
// export MALLOC_CHECK_=0 to disable malloc
// consistency checks before executing this 
// program as a test

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    char *c = (char *)malloc(10);
    printf("%p\n", c);
    c[0] = 5;
    free(c);
    free(c);
    c[1] = 1;

    c = (char *)malloc(10);
    printf("%p\n", c);
    c[2] = 2;
    free(c);
    free(c);
    c[3] = 3;

    return 0;
}
