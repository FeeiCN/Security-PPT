/*BEGIN_LEGAL 
Intel Open Source License 

Copyright (c) 2002-2011 Intel Corporation. All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.  Redistributions
in binary form must reproduce the above copyright notice, this list of
conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.  Neither the name of
the Intel Corporation nor the names of its contributors may be used to
endorse or promote products derived from this software without
specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE INTEL OR
ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
END_LEGAL */

/*
 * DoubleFree.cpp - a tool to detect double free instances in a program
 * this tool is especially useful for Double Free instances that are
 * caused by asynchronous events like the OpenSSH vulnerability caused
 * by double free due to race condition between regular code and signal
 * handler code.
 * this tool is meant to be used on Linux systems
 */

#include "pin.H"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <list>
#include <string.h>
#include <stdio.h>

list<ADDRINT> MallocAddrs;


VOID FreeBefore(ADDRINT target, ADDRINT inst)
{
   list<ADDRINT>::iterator p;
   p = find(MallocAddrs.begin(), MallocAddrs.end(), target);
   if ( (!(MallocAddrs.empty())) && (MallocAddrs.end() != p) )
   {
       p = MallocAddrs.erase(p); // Delete this from the allocated address list
   }
   else 
   {   // We caught a Free of an un-allocated address
       cerr << hex << target << " " << inst << endl;
   }   // Using cerr is not a good practice, I do it oly for the sake of the example
}


VOID MallocAfter(ADDRINT ret, ADDRINT inst)
{
   // Save the address returned by malloc in our list
   if (ret != 0)
   {
      list<ADDRINT>::iterator p;
      p = find(MallocAddrs.begin(), MallocAddrs.end(), ret);
 
      if (MallocAddrs.end() == p) //not found
      {
         MallocAddrs.push_back(ret);
      }
      else
      {
         LOG("Malloc address already saved?!\n");
         cerr << "already saved" << hex << inst << endl;
      }
   }
   else
   {
     LOG("Malloc fail\n");
   }
}

// Instrument the malloc() and free() functions.   
// note that there are malloc and free in the os loader and in libc
VOID Image(IMG img, VOID *v)
{
    //put the image name in the tool log file
    LOG("img: ");
    LOG(IMG_Name(img));
    LOG("\n");
    
    // Find the malloc() function and add our function after it
    RTN mallocRtn = RTN_FindByName(img, "malloc");
    if (RTN_Valid(mallocRtn)) 
    { 
        LOG(RTN_Name(mallocRtn));
        LOG("\n");
        if (strcmp("__libc_malloc", RTN_Name(mallocRtn).c_str()) == 0)
        {
            RTN_Open(mallocRtn);
            RTN_InsertCall(mallocRtn, IPOINT_AFTER, (AFUNPTR)MallocAfter,
                           IARG_FUNCRET_EXITPOINT_VALUE, IARG_INST_PTR, IARG_END);
            RTN_Close(mallocRtn);
            LOG("Got Malloc: ");
            LOG(RTN_Name(mallocRtn));
            LOG("\n");
        }
    }
    
    // Find the free() function and add our function before it
    RTN freeRtn = RTN_FindByName(img, "free");
    if (RTN_Valid(freeRtn)) 
    { 
        LOG(RTN_Name(freeRtn));
        LOG("\n");
        if (strcmp("cfree", RTN_Name(freeRtn).c_str()) == 0)
        {
            RTN_Open(freeRtn);
            RTN_InsertCall(freeRtn, IPOINT_BEFORE, (AFUNPTR)FreeBefore,
                           IARG_FUNCARG_ENTRYPOINT_VALUE, 0, IARG_INST_PTR,
                           IARG_END);
            RTN_Close(freeRtn);
            LOG("Got Free: ");
            LOG(RTN_Name(freeRtn));
            LOG("\n");
        }
    }

}


/* ===================================================================== */
/* Main                                                                  */
/* ===================================================================== */

int main(int argc, char *argv[])
{
    // Initialize pin & symbol manager
    PIN_InitSymbols();
    PIN_Init(argc,argv);

    // Register Image to be called to instrument functions.
    IMG_AddInstrumentFunction(Image, 0);

    PIN_StartProgram(); // Never returns
    
    return 0;
}
