// this program overwrites the return address of function "vuln"
// with the return address of function "exploited"
//
// Compile with: gcc RetAddrOverwrite.c -o RetAddrOverwrite -g -fno-stack-protector
// the stack protection can be left on, but a different calculation 
// of the address to overwrite will be required

#include <stdio.h>

void exploited()
{
    printf("Exploited!\n");
}


void vuln(void)
{
    unsigned long addr = (unsigned long)exploited;
    unsigned long sp = 0;
    unsigned long *ptr = NULL;

    asm("movl %%esp, %0 " : "=r"  (sp) );

    printf("ESP = %lx\n", sp);
    
    ptr = sp;      // set our pointer to the stack  
    ptr = ptr + 7; // move it to point to the return address
    *ptr = addr;   // overwrite it with our return address
    
    return;
}

int main(void)
{
    vuln();

    return 0;
}

