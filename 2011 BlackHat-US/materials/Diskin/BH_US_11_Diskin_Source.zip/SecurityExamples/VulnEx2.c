// Vulnerable example code
// This program uses strcpy to copy a string of unknown size
// causing a string based buffer overflow
//
// the code does not try to work around stack protection so the 
// program needs to be compiled -fno-stack-protector 

#include <stdio.h>
#include <string.h>

void vuln(char *s)
{
    char my_s[10];

    strcpy(my_s, s);	//the vulnerable strcpy

    printf("%s\n", my_s);
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("wrong no of args\n");
        return;
    }
   
    vuln(argv[1]);

    return 0;
}
