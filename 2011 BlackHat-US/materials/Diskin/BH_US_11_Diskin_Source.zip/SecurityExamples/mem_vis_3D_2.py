#!/usr/bin/env python
# Example data flow visualization tool 2
# Shows the data flow based on analysis of pinatrace tool from source/tools/ManualExamples folder
# uses the vpython library
# this tool is limited to 1000 memory operations
# note the symmetries in the generated output
# RED = Write, BLUE = Read

from visual import *
from time import sleep
MAX  = 1000

f = open('pinatrace.out')
lines = f.readlines()
f.close()

wr = curve(pos=(0,0,0),radius=20, color=color.red)
rd = curve(pos=(0,0,0),radius=20, color=color.blue)


i = 0
for l in lines:
  if l[0:4] == "#eof":
    break
  if i > MAX:
    break
  ip = int( (l.split()[0].split('x')[1].split(':')[0])[6:], 16)*16
  addr = int( (l.split()[2].split('x')[1])[5:], 16)
  tp = (i*20,addr,ip)
  print tp

  if l.split()[1] == 'W':
    wr.append(pos=tp,color=color.red)
  else:
    rd.append(pos=tp,color=color.blue)
  i+=1
  sleep(0.1)

