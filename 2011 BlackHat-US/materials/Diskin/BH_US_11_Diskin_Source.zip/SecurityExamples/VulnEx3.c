//This program does all sort of "games" with tainted memory in order
//to demonstrate how taint propogates
//
//Be sure to build with -O0 (no optimizations) to ensure that the compiler
//doesn't cut out our useless games with values done to demonstrate the
//taint propogation

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void vuln(char *s)
{
    char my_s[10];
    printf("my_s=%p\n", my_s);

    strcpy(my_s, s);

    printf("%s\n", my_s);
}


int main(int argc, char *argv[])
{
    char stack_param;
    char stack_buffer[2];
    char *some_pointer = (char *)malloc(10);

    if (argc != 2)
    {
        printf("wrong no of args\n");
        return;
    }

    //some_pointer should show some address on the heap
	//argv[1] the source of taint
	//the stack param and buffer the stack addresses
	printf("&stack_param=%p stack_buffer=%p some_pointer=%p argv[1]=%p\n", 
		    &stack_param, stack_buffer, some_pointer, argv[1]);
    
	//spread the taint around
	some_pointer[0] = argv[1][1];		//some_pointer[0] tainted
    stack_param = argv[1][1];			//stack_param tainted
    some_pointer = argv[1];				//copy address of argv[1] to some_pointer (it is the address --> not tainted)
    stack_buffer[0] = stack_param;		//stack_buffer[0] tainted due to copy of the taint from stack_param 
    stack_buffer[1] = some_pointer[4];  //stack_buffer[1] tainted due to copy of the taint from some_pointer that equals argv[1]

    vuln(argv[1]);						//strcpy in vuln will spread some more taint
    
    stack_buffer[0] = 1;				//un-taint stack_buffer[0] by setting it to constant value

    return 0;
}
