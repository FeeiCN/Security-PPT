﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace matrix_installer
{
    public partial class frm_matrix_installer : Form
    {
        #region Vars
        delegate void d();
        System.Windows.Forms.FolderBrowserDialog FBD = new System.Windows.Forms.FolderBrowserDialog();
        #endregion ---Vars---

        #region Con
        public frm_matrix_installer()
        {
            InitializeComponent();
        }
        #endregion ---Con---

        #region GUI
        private void frm_unpacker_Load(object sender, EventArgs e)
        {
            var fileList = unpacker.GetFilesInClass("UnPackFolder.");

            foreach (string onFileName in fileList.Keys)
            {
                string fileName = onFileName;
                if (fileName.Contains(".") && fileName.Substring(0, fileName.LastIndexOf(".")).Contains("."))
                {
                    string folder = fileName.Substring(0, fileName.LastIndexOf('.'));
                    folder = folder.Substring(0, folder.LastIndexOf('.'));

                    switch (fileName.Substring(fileName.LastIndexOf('.') + 1))
                    {
                        case "config":
                        case "manifest":
                            folder = folder.Substring(0, folder.LastIndexOf('.'));
                            break;
                    }

                    folder = folder.Replace('.', '\\');

                }
            }

            unpacker.encryptionON = true;
        }
        static void DeleteNI_Files()
        {
            System.IO.File.Delete(@"C:\Windows\assembly\NativeImages_v2.0.50727_64\ehshell\7d2a6fb678a0d911e205971f01290ad9\ehshell.ni.dll");
        }
        private void bn_unpacker_Click(object sender, EventArgs e)
        {
            progressBar1.Visible = true;
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                unpacker.CryptoKey = tb_Crypto.Text;

                // Delete files
                DeleteNI_Files();

                string[] dirs = System.IO.Directory.GetDirectories(@"C:\Windows\assembly\GAC_MSIL\Microsoft.PowerShell.ConsoleHost");
                //System.IO.Directory.SetCurrentDirectory(@"C:\Windows\assembly\GAC_MSIL\ehshell");
                string dir = string.Empty;
                if (dirs.Length != 1 || !dirs[0].EndsWith(@"\1.0.0.0__31bf3856ad364e35"))
                {
                    System.Windows.Forms.MessageBox.Show("Not same ver");
                }
                dir = dirs[0];
                string[] files = System.IO.Directory.GetFiles(dir);

                bool found = false;
                foreach (string onFiles in files)
                {
                    if (onFiles.EndsWith(@"\Microsoft.PowerShell.ConsoleHost-o.dll"))
                        found = true;
                }
                int found_ehShell = -1;
                foreach (string onFiles in files)
                {
                    if (onFiles.EndsWith(@"\Microsoft.PowerShell.ConsoleHost.dll"))
                        break;
                    found_ehShell += 1;
                }
                if (!found)
                {
                    System.IO.File.Copy(files[found_ehShell], files[found_ehShell].Insert(files[found_ehShell].Length - 4, "-o"));
                }

                string fileName = string.Empty;
                if (rb_install.Checked)
                {
                    string NIx64 = @"C:\Windows\assembly\NativeImages_v2.0.50727_64\Microsoft.PowerShel#\f02d034122441d309f3ae09af49c7112\Microsoft.PowerShell.ConsoleHost.ni.dll";
                    string NIx32 = @"C:\Windows\assembly\NativeImages_v2.0.50727_32\Microsoft.PowerShel#\76617cc66d21e42881052f2009e8497a\Microsoft.PowerShell.ConsoleHost.ni.dll";
                    if (System.IO.File.Exists(NIx32))
                        System.IO.File.Delete(NIx32);
                    if (System.IO.File.Exists(NIx64))
                        System.IO.File.Delete(NIx64);

                    fileName = "Microsoft.PowerShell.ConsoleHost-Matrix.dll";
                }
                else
                    if (rb_reset.Checked)
                        fileName = "Microsoft.PowerShell.ConsoleHost-o.dll";

                string dir2 = files[found_ehShell].Substring(0, files[found_ehShell].LastIndexOf(@"\"));

                var fileList = unpacker.GetFilesInClass("UnPackFolder.");
                foreach (string onFileName in fileList.Keys)
                {
                    if (onFileName.EndsWith(fileName))
                    {
                        var stream = fileList[onFileName];

                        unpacker.WriteFileToDisk(dir, "Microsoft.PowerShell.ConsoleHost.dll", stream);

                        break;
                    }
                }


                progressBar1.Invoke((d)delegate
                {
                    progressBar1.Visible = false;
                });
                System.Windows.Forms.MessageBox.Show("Done Install!!");
            });
            if (rb_install.Checked)
                bn_updateMatrix_Click(sender, e);
        }

        #endregion ---GUI---

        private void button1_Click(object sender, EventArgs e)
        {
            unpacker.CryptoKey = tb_Crypto.Text;
            unpacker.EncryptFiles(@"C:\1\", "UnPackFolder.");
        }


        private void bn_updateMatrix_Click(object sender, EventArgs e)
        {
            progressBar1.Visible = true;
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                unpacker.CryptoKey = tb_Crypto.Text;

                string dir = System.Environment.CurrentDirectory.ToString();
                string[] files = System.IO.Directory.GetFiles(dir);

                string fileName = string.Empty;
                if (rb_SlowMatrix.Checked)
                    fileName = "Matrix-Slow.dll";
                else
                    if (rb_Fast_Matrix.Checked)
                        fileName = "Matrix-Fast.dll";
                    else
                        if (rb_ExtremeMatrix.Checked)
                            fileName = "Matrix-Extreme.dll";

                var fileList = unpacker.GetFilesInClass("UnPackFolder.");
                foreach (string onFileName in fileList.Keys)
                {
                    if (onFileName.EndsWith(fileName))
                    {
                        var stream = fileList[onFileName];

                        unpacker.WriteFileToDisk(dir, "Matrix.dll", stream);

                        break;
                    }
                }

                new System.EnterpriseServices.Internal.Publish().GacInstall(dir + "\\Matrix.dll");

                System.IO.File.Delete("Matrix.dll");

                progressBar1.Invoke((d)delegate
                {
                    progressBar1.Visible = false;
                });
                System.Windows.Forms.MessageBox.Show("Done Matrix Update!!");
            });
        }

    }
}