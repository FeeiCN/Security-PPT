﻿namespace matrix_installer
{
    partial class frm_matrix_installer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bn_unpacker = new System.Windows.Forms.Button();
            this.rb_SlowMatrix = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.rb_reset = new System.Windows.Forms.RadioButton();
            this.rb_Fast_Matrix = new System.Windows.Forms.RadioButton();
            this.tb_Crypto = new System.Windows.Forms.TextBox();
            this.rb_install = new System.Windows.Forms.RadioButton();
            this.bn_updateMatrix = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rb_ExtremeMatrix = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bn_unpacker
            // 
            this.bn_unpacker.Location = new System.Drawing.Point(220, 6);
            this.bn_unpacker.Name = "bn_unpacker";
            this.bn_unpacker.Size = new System.Drawing.Size(75, 23);
            this.bn_unpacker.TabIndex = 0;
            this.bn_unpacker.Text = "Unpack";
            this.bn_unpacker.UseVisualStyleBackColor = true;
            this.bn_unpacker.Click += new System.EventHandler(this.bn_unpacker_Click);
            // 
            // rb_SlowMatrix
            // 
            this.rb_SlowMatrix.AutoSize = true;
            this.rb_SlowMatrix.Checked = true;
            this.rb_SlowMatrix.Location = new System.Drawing.Point(12, 11);
            this.rb_SlowMatrix.Name = "rb_SlowMatrix";
            this.rb_SlowMatrix.Size = new System.Drawing.Size(79, 17);
            this.rb_SlowMatrix.TabIndex = 8;
            this.rb_SlowMatrix.TabStop = true;
            this.rb_SlowMatrix.Text = "Slow Matrix";
            this.rb_SlowMatrix.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(229, 105);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "save Crypto";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.progressBar1.Location = new System.Drawing.Point(0, 0);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(316, 185);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar1.TabIndex = 10;
            this.progressBar1.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(123, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "PASSWORD:";
            // 
            // rb_reset
            // 
            this.rb_reset.AutoSize = true;
            this.rb_reset.Location = new System.Drawing.Point(149, 12);
            this.rb_reset.Name = "rb_reset";
            this.rb_reset.Size = new System.Drawing.Size(65, 17);
            this.rb_reset.TabIndex = 12;
            this.rb_reset.Text = "Remove";
            this.rb_reset.UseVisualStyleBackColor = true;
            // 
            // rb_Fast_Matrix
            // 
            this.rb_Fast_Matrix.AutoSize = true;
            this.rb_Fast_Matrix.Location = new System.Drawing.Point(97, 11);
            this.rb_Fast_Matrix.Name = "rb_Fast_Matrix";
            this.rb_Fast_Matrix.Size = new System.Drawing.Size(76, 17);
            this.rb_Fast_Matrix.TabIndex = 13;
            this.rb_Fast_Matrix.Text = "Fast Matrix";
            this.rb_Fast_Matrix.UseVisualStyleBackColor = true;
            // 
            // tb_Crypto
            // 
            this.tb_Crypto.Location = new System.Drawing.Point(17, 134);
            this.tb_Crypto.Name = "tb_Crypto";
            this.tb_Crypto.Size = new System.Drawing.Size(282, 20);
            this.tb_Crypto.TabIndex = 5;
            this.tb_Crypto.Text = "MATRIX";
            this.tb_Crypto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rb_install
            // 
            this.rb_install.AutoSize = true;
            this.rb_install.Checked = true;
            this.rb_install.Location = new System.Drawing.Point(90, 12);
            this.rb_install.Name = "rb_install";
            this.rb_install.Size = new System.Drawing.Size(52, 17);
            this.rb_install.TabIndex = 14;
            this.rb_install.TabStop = true;
            this.rb_install.Text = "Install";
            this.rb_install.UseVisualStyleBackColor = true;
            // 
            // bn_updateMatrix
            // 
            this.bn_updateMatrix.Location = new System.Drawing.Point(179, 7);
            this.bn_updateMatrix.Name = "bn_updateMatrix";
            this.bn_updateMatrix.Size = new System.Drawing.Size(98, 23);
            this.bn_updateMatrix.TabIndex = 15;
            this.bn_updateMatrix.Text = "Update Matrix";
            this.bn_updateMatrix.UseVisualStyleBackColor = true;
            this.bn_updateMatrix.Click += new System.EventHandler(this.bn_updateMatrix_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rb_ExtremeMatrix);
            this.panel1.Controls.Add(this.bn_updateMatrix);
            this.panel1.Controls.Add(this.rb_SlowMatrix);
            this.panel1.Controls.Add(this.rb_Fast_Matrix);
            this.panel1.Location = new System.Drawing.Point(21, 47);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(282, 55);
            this.panel1.TabIndex = 16;
            // 
            // rb_ExtremeMatrix
            // 
            this.rb_ExtremeMatrix.AutoSize = true;
            this.rb_ExtremeMatrix.Location = new System.Drawing.Point(97, 34);
            this.rb_ExtremeMatrix.Name = "rb_ExtremeMatrix";
            this.rb_ExtremeMatrix.Size = new System.Drawing.Size(94, 17);
            this.rb_ExtremeMatrix.TabIndex = 16;
            this.rb_ExtremeMatrix.Text = "Extreme Matrix";
            this.rb_ExtremeMatrix.UseVisualStyleBackColor = true;
            // 
            // frm_matrix_installer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(316, 185);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.rb_install);
            this.Controls.Add(this.rb_reset);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tb_Crypto);
            this.Controls.Add(this.bn_unpacker);
            this.Controls.Add(this.progressBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "frm_matrix_installer";
            this.Text = "Unpacker";
            this.Load += new System.EventHandler(this.frm_unpacker_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bn_unpacker;
        private System.Windows.Forms.RadioButton rb_SlowMatrix;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rb_reset;
        private System.Windows.Forms.RadioButton rb_Fast_Matrix;
        private System.Windows.Forms.TextBox tb_Crypto;
        private System.Windows.Forms.RadioButton rb_install;
        private System.Windows.Forms.Button bn_updateMatrix;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rb_ExtremeMatrix;
    }
}

