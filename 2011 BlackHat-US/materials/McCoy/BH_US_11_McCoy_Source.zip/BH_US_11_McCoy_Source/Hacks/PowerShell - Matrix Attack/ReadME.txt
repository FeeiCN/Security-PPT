Matrix-installer.exe - this will infect your powershell, just run and click install :)
have a nice day