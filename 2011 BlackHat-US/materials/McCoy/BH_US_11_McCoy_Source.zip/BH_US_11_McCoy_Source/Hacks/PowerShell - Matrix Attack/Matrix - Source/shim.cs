﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shim
{
    public class Shim
    {

        delegate void d();
        //static object target=null;
        public static void RunShim(object targetIN)
        {

            System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart((d)delegate
            {
                System.Threading.Thread.Sleep(1000);

         //       System.Windows.Forms.MessageBox.Show("At Shim");

                var UIvar = targetIN.GetType().GetProperty("UI", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
                var pshUI = UIvar.GetValue(targetIN, null) as System.Management.Automation.Host.PSHostUserInterface;

                new PowerShellHack.Matrix(targetIN, pshUI);

            }));
            t.IsBackground = true;
            t.Start();

        }



        //    target = targetIN;

        //    System.Timers.Timer tic = new System.Timers.Timer(3000);
        //    tic.Elapsed += new System.Timers.ElapsedEventHandler(delegate
        //    {

        //        var tt= target.GetType();
        //        Type ObjType = System.Type.GetType(tt.FullName);
        //        System.Windows.Forms.MessageBox.Show(tt.FullName);

        //        //System.Windows.Forms.MessageBox.Show("2");
        //        //System.Reflection.MethodInfo r8 = null;
        //        //foreach (var r in tt.GetMethods(System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public))
        //        //{
        //        //    string mistr = r.Name + "(";
        //        //    foreach (var v in r.GetParameters())
        //        //        mistr += v.ToString();
        //        //    if (r.Name == "SetBufferContents")
        //        //    {
        //        //        r8 = r;
        //        //        break;
        //        //    }
        //        //        //System.Windows.Forms.MessageBox.Show(mistr);
                    
        //        //}
        //        try
        //        {
        //            System.Windows.Forms.MessageBox.Show("2.1");
        //            System.Management.Automation.Host.BufferCell[][] temp = {};
        //            //var v = tt.GetMethod("SetBufferContents", new Type[] { typeof(System.Management.Automation.Host.Coordinates), temp.GetType() });
        //            //var v = r8;
        //            //var v = tt.GetMethod("SetBufferContents", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.DeclaredOnly,
        //            //                        null, new Type[] { typeof(System.Management.Automation.Host.Coordinates), temp.GetType() }, new System.Reflection.ParameterModifier[] {});

        //            //var RawUI = UI.GetType().GetProperty("RawUI", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
       
        //            //var intBGColor = targetIN.GetType().GetMember("defaultBackground");
        //            //var BGColor = intBGColor.GetValue(0);

        //            //var intFGColor = targetIN.GetType().GetMember("defaultForeground");
        //            //var FGColor = intFGColor.GetValue(0);

        //            System.Windows.Forms.MessageBox.Show("3");


        //            var BuffArray = pshUI.RawUI.NewBufferCellArray(new string[] { "w", "e", "e" }, pshUI.RawUI.ForegroundColor, pshUI.RawUI.BackgroundColor);

        //            pshUI.RawUI.SetBufferContents(new System.Management.Automation.Host.Coordinates(5, 5), BuffArray);


        //            //v.Invoke(targetIN, new object[] { "sup" });
        //        }
        //        catch (System.Exception ex){ System.Windows.Forms.MessageBox.Show("Ex: "+ ex.Message); };
        //        System.Windows.Forms.MessageBox.Show("4");
        //    });
        //    // Microsoft.PowerShell.ConsoleHostRawUserInterface.WindowTitle = title
        //    tic.AutoReset = false;
        //    tic.Start();

        //    //            targetIN = v;

        //    // has host
        //    RunShim();
        //}
        //public static void RunShim()
        //{
        //    System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
        //    {
        //        string noteTxt = string.Empty;
        //        if (target != null)
        //            noteTxt = target.ToString();
        //        note(noteTxt);
        //    }));
        //    t.Start();
        //    t.IsBackground = true;
        //}
        //private static void note(string txt)
        //{
        //    System.Windows.Forms.MessageBox.Show("HOT " + txt);
        //}
    }
}
