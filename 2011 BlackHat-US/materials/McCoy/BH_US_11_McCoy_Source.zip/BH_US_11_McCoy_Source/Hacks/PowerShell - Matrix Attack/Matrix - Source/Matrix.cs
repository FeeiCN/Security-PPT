﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Management.Automation.Host;

namespace PowerShellHack
{
    class MatrixLine
    {
        public bool initialized = true;
        public int Xpos = 0;
        public int Ypos = 0;
        public int speed = 0;
        public int LineLength = 0;
        private int maxSpeed = 0;
        static Random randFunc = new Random();
        private BufferCell[,] _buffArray;

        public BufferCell[,] BuffArray
        {
            get { return _buffArray; }
            set { _buffArray = value; }
        }

        public BufferCell[,] BuffArrayOutPut
        {
            get 
            {
                if (Ypos < 0)
                    if (LineLength + Ypos > 0)
                    {
                        BufferCell[,] tempBuffArray = new BufferCell[LineLength + Ypos, 1];
                        for (int i = 0; i < tempBuffArray.Length; i++)
                        {
                            tempBuffArray[tempBuffArray.Length - i - 1, 0] = _buffArray[_buffArray.Length - i - 1, 0];
                        }
                        return tempBuffArray;
                    }
                return _buffArray; 
            }
        }
        static BufferCell[,] emptyArray;
        static BufferCell[,] MakeEmptyArray(PSHostRawUserInterface RawUI)
        {
            System.Collections.Generic.List<string> CellText = new List<string>();

            // set inital two colors
            for (int i = 0; i < 40; i++)
            {
                CellText.Add(" ");
            }
            emptyArray = RawUI.NewBufferCellArray(CellText.ToArray(), RawUI.ForegroundColor, RawUI.BackgroundColor);

            return emptyArray;
        }
        public MatrixLine(int lineLength, Size WindowDem, int speedIN, int bottomOfScreen, PSHostRawUserInterface RawUI)
        {
            if (emptyArray == null)
            {
                emptyArray = MakeEmptyArray(RawUI);
            }

            maxSpeed = speedIN;
            this.LineLength = randFunc.Next(lineLength) + 8 + speed;
            this.Ypos = -LineLength - randFunc.Next(30);

            //if (Ypos < 0)
            //    Ypos = 0;
            this.Xpos = randFunc.Next(WindowDem.Width - 1);

            this.speed = randFunc.Next(maxSpeed) + 1;

            BuildBufferCellArray(lineLength, bottomOfScreen, RawUI);
        }

        public void CheckEnd(int bottomScreen, int Width, PSHostRawUserInterface RawUI)
        {
   //         if (Ypos == bottomScreen)
            {
 //               _buffArray = emptyArray;
            }
            if (Ypos > bottomScreen)
            {
                this.Ypos = -LineLength;
                this.Xpos = randFunc.Next(Width - 1);
            }
        }

        string masterList = "Añ√☻┼?▼▼Ë╧!↨₧=èº♥←Î₧₧ε±&Ä«♥╞¡Θδù‼╞↓↨#$R@&♫☺▐▐││▌╟";
  //      string masterList = "---------------------------";
        private void BuildBufferCellArray(int lineLength, int bottomOfScreen, PSHostRawUserInterface RawUI)
        {
            System.Collections.Generic.List<string> CellText = new List<string>();
            
           // set inital two colors
            for (int i = 0; i < this.LineLength; i++)
            {
                if (i <= speed)
                {
                    CellText.Add(" ");
                }
                else
                {//set cell text to a random char  
                    CellText.Add(masterList[ randFunc.Next(masterList.Length-1)].ToString());
                }
            }
            _buffArray = RawUI.NewBufferCellArray(CellText.ToArray(), RawUI.ForegroundColor, RawUI.BackgroundColor);
        }
    }

    class Matrix
    {
        public int numLines = 40;
        public int lineLength = 45;
        public int stepDelay =200;
        public int spawnDelay = 1;
        public int speed = 6;
        public int bottomOfScreen = 75;

        private System.Collections.Generic.List<MatrixLine> Lines;
        System.Random ranNumber = new Random();
        private PSHostUserInterface PshUI = null;
        private PSHostRawUserInterface RawUI = null;

        public Matrix(object TargetIN, PSHostUserInterface PSHUI)
        {
            if(PSHUI == null || TargetIN == null)
            {
                throw new Exception("Bad input into Matrix constructor.");
            }
            PshUI = PSHUI;
            RawUI = PSHUI.RawUI;

            Lines = new List<MatrixLine>();
            for (int i = 0; i < numLines; i++)
                Lines.Add(new MatrixLine(lineLength, RawUI.MaxWindowSize,speed, bottomOfScreen, RawUI));

            System.Timers.Timer tic = new System.Timers.Timer(stepDelay);
            tic.Elapsed += new System.Timers.ElapsedEventHandler(tic_Elapsed);

            tic.AutoReset = true;
            tic.Start();

        }

        void tic_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            lock (this)
            {
                //cycle through list of lines and advance
                for (int i = 0; i < numLines; i++)
                {
                    if (Lines[i].initialized)
                    {
                        Lines[i] = AdvanceLine(Lines[i]);
                        //check to see if the line has fallen off screen
                        Lines[i].CheckEnd(bottomOfScreen, RawUI.MaxWindowSize.Width, RawUI);
                    }
                }

                Display();
            }
        }

        private void Display()
        {
            try
            {
                for (int i = 0; i < numLines; i++)
                {
                    if (!Lines[i].initialized || Lines[i].LineLength + Lines[i].Ypos <= 0)
                        continue;
                    int offSet = 0;
                    if (RawUI.CursorPosition.Y > bottomOfScreen)
                        offSet = RawUI.CursorPosition.Y - bottomOfScreen;

                    int shitTemp=Lines[i].speed+1;
                    for (int x = Lines[i].speed; x > 0; x--)
                    {
                        var temp = Lines[i].BuffArray[shitTemp, 0];
                        for (int j = shitTemp; j < Lines[i].LineLength - 1; j++)
                        {
                            Lines[i].BuffArray[j, 0] = Lines[i].BuffArray[j+1, 0];
                        }
                        Lines[i].BuffArray[Lines[i].BuffArray.Length - 1, 0] = temp;
                    }

                    for (int j = Lines[i].speed; j < Lines[i].BuffArray.Length; j++)
                    {
                            if (j < Lines[i].LineLength-4)
                                Lines[i].BuffArray[j, 0].ForegroundColor = ConsoleColor.DarkGreen;
                        else
                                Lines[i].BuffArray[j, 0].ForegroundColor = ConsoleColor.Green;
                    }

                    Lines[i].BuffArray[Lines[i].BuffArray.Length - 2, 0].ForegroundColor = ConsoleColor.White;
                    Lines[i].BuffArray[Lines[i].BuffArray.Length - 1, 0].ForegroundColor = ConsoleColor.White;

                    if (Lines[i].Ypos < 0)
                        RawUI.SetBufferContents(new Coordinates(Lines[i].Xpos, 0), Lines[i].BuffArrayOutPut);
                    else
                        RawUI.SetBufferContents(new Coordinates(Lines[i].Xpos, Lines[i].Ypos + offSet), Lines[i].BuffArrayOutPut);
                }
            }
            catch (Exception ex) 
            { throw ex; }
        }

        private bool IsSpotEmpty(Coordinates loc)
        {
            BufferCell[,] charUnderSpot = RawUI.GetBufferContents(new Rectangle(loc, loc));
            return (charUnderSpot[0, 0].Character == ' ');
        }

        private MatrixLine AdvanceLine(MatrixLine inputLine)
        {
            inputLine.Ypos+=inputLine.speed;
            return inputLine;
        }
    }
}
