﻿namespace ehshell_changePassword
{
    partial class frm_MediaCenter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_MediaCenter));
            this.bn_changePassword = new System.Windows.Forms.Button();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.bn_md5 = new System.Windows.Forms.Button();
            this.tb_md5 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // bn_changePassword
            // 
            this.bn_changePassword.Location = new System.Drawing.Point(248, 26);
            this.bn_changePassword.Name = "bn_changePassword";
            this.bn_changePassword.Size = new System.Drawing.Size(75, 23);
            this.bn_changePassword.TabIndex = 0;
            this.bn_changePassword.Text = "Change Password";
            this.bn_changePassword.UseVisualStyleBackColor = true;
            this.bn_changePassword.Click += new System.EventHandler(this.bn_changePassword_Click);
            // 
            // tb_password
            // 
            this.tb_password.Location = new System.Drawing.Point(37, 26);
            this.tb_password.Name = "tb_password";
            this.tb_password.Size = new System.Drawing.Size(75, 20);
            this.tb_password.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(333, 39);
            this.label1.TabIndex = 2;
            this.label1.Text = "                              This Changes The Password\r\nMediaCenter.Options.Pare" +
                "ntalControlPin->StoreNewPin(NewPassord)\r\n                                Inject " +
                "and run on ehshell";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "4 numbers";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(239, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Change Password";
            // 
            // bn_md5
            // 
            this.bn_md5.Location = new System.Drawing.Point(142, 70);
            this.bn_md5.Name = "bn_md5";
            this.bn_md5.Size = new System.Drawing.Size(75, 23);
            this.bn_md5.TabIndex = 5;
            this.bn_md5.Text = "MD5";
            this.bn_md5.UseVisualStyleBackColor = true;
            this.bn_md5.Click += new System.EventHandler(this.bn_md5_Click);
            // 
            // tb_md5
            // 
            this.tb_md5.Location = new System.Drawing.Point(68, 99);
            this.tb_md5.Name = "tb_md5";
            this.tb_md5.Size = new System.Drawing.Size(220, 20);
            this.tb_md5.TabIndex = 6;
            this.tb_md5.Text = "MD5";
            this.tb_md5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // frm_MediaCenter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 219);
            this.Controls.Add(this.tb_md5);
            this.Controls.Add(this.bn_md5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_password);
            this.Controls.Add(this.bn_changePassword);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_MediaCenter";
            this.Text = "MediaCenter - Password Reset";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bn_changePassword;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bn_md5;
        private System.Windows.Forms.TextBox tb_md5;
    }
}

