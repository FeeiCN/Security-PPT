﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ehshell_changePassword
{
    public partial class frm_MediaCenter : Form
    {
        public frm_MediaCenter()
        {
            InitializeComponent();
        }

        private void bn_changePassword_Click(object sender, EventArgs e)
        {
            // get the target Assembly
            Type somethingInTheTarget = typeof(MediaCenter.Options.FavoriteLineupModelComparer);
            var targetAssembly = somethingInTheTarget.Assembly;
           
            // get the target Type
            var targetType = targetAssembly.GetType("MediaCenter.Options.ParentalControlPin");

            // get the target Function
            var targetFunction = targetType.GetMethod("StoreNewPin", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);

            // run the Function
            targetFunction.Invoke(null, new object[] { tb_password.Text });
        }

        private void bn_md5_Click(object sender, EventArgs e)
        {
            // get the target Assembly
            Type somethingInTheTarget = typeof(MediaCenter.Options.FavoriteLineupModelComparer);
            var targetAssembly = somethingInTheTarget.Assembly;

            // get the target Type
            var targetType = targetAssembly.GetType("MediaCenter.Options.ParentalControl");

            // get the target Function
            var targetFunction = targetType.GetField("_settings", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
            
            // run the setting Object
            var t=     targetFunction.GetValue(null);

            // get the PIN
            var PIN = t.GetType().GetField("PIN", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);

            // show the pin
            tb_md5.Text = PIN.GetValue(t).ToString();
        }
    }
}
