﻿namespace ehshell_installer
{
    partial class frm_ehshell_installer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bn_unpacker = new System.Windows.Forms.Button();
            this.tb_Crypto = new System.Windows.Forms.TextBox();
            this.rb_showPassword = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.rb_reset = new System.Windows.Forms.RadioButton();
            this.rb_hack_showPassword = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // bn_unpacker
            // 
            this.bn_unpacker.Location = new System.Drawing.Point(121, 74);
            this.bn_unpacker.Name = "bn_unpacker";
            this.bn_unpacker.Size = new System.Drawing.Size(75, 23);
            this.bn_unpacker.TabIndex = 0;
            this.bn_unpacker.Text = "Unpack";
            this.bn_unpacker.UseVisualStyleBackColor = true;
            this.bn_unpacker.Click += new System.EventHandler(this.bn_unpacker_Click);
            // 
            // tb_Crypto
            // 
            this.tb_Crypto.Location = new System.Drawing.Point(17, 134);
            this.tb_Crypto.Name = "tb_Crypto";
            this.tb_Crypto.Size = new System.Drawing.Size(282, 20);
            this.tb_Crypto.TabIndex = 5;
            this.tb_Crypto.Text = "EHSHELL";
            this.tb_Crypto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rb_showPassword
            // 
            this.rb_showPassword.AutoSize = true;
            this.rb_showPassword.Checked = true;
            this.rb_showPassword.Location = new System.Drawing.Point(17, 12);
            this.rb_showPassword.Name = "rb_showPassword";
            this.rb_showPassword.Size = new System.Drawing.Size(101, 17);
            this.rb_showPassword.TabIndex = 8;
            this.rb_showPassword.TabStop = true;
            this.rb_showPassword.Text = "Show Password";
            this.rb_showPassword.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(214, 76);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.progressBar1.Location = new System.Drawing.Point(0, 0);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(316, 185);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar1.TabIndex = 10;
            this.progressBar1.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(123, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "PASSWORD:";
            // 
            // rb_reset
            // 
            this.rb_reset.AutoSize = true;
            this.rb_reset.Location = new System.Drawing.Point(199, 35);
            this.rb_reset.Name = "rb_reset";
            this.rb_reset.Size = new System.Drawing.Size(53, 17);
            this.rb_reset.TabIndex = 12;
            this.rb_reset.Text = "Reset";
            this.rb_reset.UseVisualStyleBackColor = true;
            // 
            // rb_hack_showPassword
            // 
            this.rb_hack_showPassword.AutoSize = true;
            this.rb_hack_showPassword.Location = new System.Drawing.Point(199, 12);
            this.rb_hack_showPassword.Name = "rb_hack_showPassword";
            this.rb_hack_showPassword.Size = new System.Drawing.Size(100, 17);
            this.rb_hack_showPassword.TabIndex = 13;
            this.rb_hack_showPassword.Text = "Hack Password";
            this.rb_hack_showPassword.UseVisualStyleBackColor = true;
            // 
            // frm_ehshell_installer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(316, 185);
            this.Controls.Add(this.rb_hack_showPassword);
            this.Controls.Add(this.rb_reset);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.rb_showPassword);
            this.Controls.Add(this.tb_Crypto);
            this.Controls.Add(this.bn_unpacker);
            this.Controls.Add(this.progressBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "frm_ehshell_installer";
            this.Text = "Unpacker";
            this.Load += new System.EventHandler(this.frm_unpacker_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bn_unpacker;
        private System.Windows.Forms.TextBox tb_Crypto;
        private System.Windows.Forms.RadioButton rb_showPassword;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rb_reset;
        private System.Windows.Forms.RadioButton rb_hack_showPassword;
    }
}

