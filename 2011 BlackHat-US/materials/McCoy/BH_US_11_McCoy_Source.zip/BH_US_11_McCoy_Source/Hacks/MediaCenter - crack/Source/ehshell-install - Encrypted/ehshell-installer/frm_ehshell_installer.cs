﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ehshell_installer
{
    public partial class frm_ehshell_installer : Form
    {
        #region Vars
        delegate void d();
        System.Windows.Forms.FolderBrowserDialog FBD = new System.Windows.Forms.FolderBrowserDialog();
        #endregion ---Vars---

        #region Con
        public frm_ehshell_installer()
        {
            InitializeComponent();
        }
        #endregion ---Con---

        #region GUI
        private void frm_unpacker_Load(object sender, EventArgs e)
        {
            var fileList = unpacker.GetFilesInClass("UnPackFolder.");

            foreach (string onFileName in fileList.Keys)
            {
                string fileName = onFileName;
                if (fileName.Contains(".") && fileName.Substring(0, fileName.LastIndexOf(".")).Contains("."))
                {
                    string folder = fileName.Substring(0, fileName.LastIndexOf('.'));
                    folder = folder.Substring(0, folder.LastIndexOf('.'));
            
                    switch (fileName.Substring(fileName.LastIndexOf('.') + 1))
                    {
                        case "config":
                        case "manifest":
                            folder = folder.Substring(0, folder.LastIndexOf('.'));
                            break;
                    }

                    folder = folder.Replace('.', '\\');

                }
            }

            unpacker.encryptionON = true;
        }
        static void DeleteNI_Files()
        {
            System.IO.File.Delete(@"C:\Windows\assembly\NativeImages_v2.0.50727_64\ehshell\7d2a6fb678a0d911e205971f01290ad9\ehshell.ni.dll");
        }
        private void bn_unpacker_Click(object sender, EventArgs e)
        {
            progressBar1.Visible = true;
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                unpacker.CryptoKey = tb_Crypto.Text;

                // Delete files
                DeleteNI_Files();


                string[] dir = System.IO.Directory.GetDirectories(@"C:\Windows\assembly\GAC_MSIL\ehshell");
                //System.IO.Directory.SetCurrentDirectory(@"C:\Windows\assembly\GAC_MSIL\ehshell");
                if (dir.Length != 1 || !dir[0].EndsWith(@"\6.1.0.0__31bf3856ad364e35"))
                {
                    System.Windows.Forms.MessageBox.Show("Not same ver");
                }
                string[] files = System.IO.Directory.GetFiles(dir[0]);

                bool found = false;
                foreach (string onFiles in files)
                {
                    if (onFiles.EndsWith(@"\ehshell-o.dll"))
                        found = true;
                }
                int found_ehShell = -1;
                foreach (string onFiles in files)
                {
                    found_ehShell += 1;
                    if (onFiles.EndsWith(@"\ehshell.dll"))
                        break;
                }
                if (!found)
                {
                    System.IO.File.Copy(files[found_ehShell], files[found_ehShell].Insert(files[found_ehShell].Length - 4, "-o"));
                }

                string fileName=string.Empty;
                if (rb_showPassword.Checked)
                    fileName = "ehshell-showPass.dll";
                else
                    if (rb_hack_showPassword.Checked)
                        fileName = "ehshell-hack-showpass.dll";
                    else
                        fileName = "ehshell-original.dll";

                string dir2 = files[found_ehShell].Substring(0, files[found_ehShell].LastIndexOf(@"\"));
               
                var fileList = unpacker.GetFilesInClass("UnPackFolder.");
                foreach (string onFileName in fileList.Keys)
                {
                    if (onFileName.EndsWith(fileName))
                    {
                        var stream = fileList[onFileName];

                        unpacker.WriteFileToDisk(dir2, "ehshell.dll", stream);
                        break;
                    }
                }

//                System.Windows.Forms.MessageBox.Show("Done!!");
                progressBar1.Invoke((d)delegate
                {
                    progressBar1.Visible = false;
                });
            });
        }

        #endregion ---GUI---

        private void button1_Click(object sender, EventArgs e)
        {
            unpacker.CryptoKey = "EHSHELL";
            unpacker.EncryptFiles(@"C:\1\", "UnPackFolder");
        }

    }
}