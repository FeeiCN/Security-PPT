﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ehshell_installer
{
    public static class unpacker
    {
        #region Vars
        private static string _cryptoKey;

        public static string CryptoKey
        {
            get { return unpacker._cryptoKey; }
            set { unpacker._cryptoKey = value;
            System.Security.Cryptography.TripleDES tdes = System.Security.Cryptography.TripleDES.Create();

            tdes.KeySize = 192;
            tdes.Mode = System.Security.Cryptography.CipherMode.CFB;
            tdes.Padding = System.Security.Cryptography.PaddingMode.ISO10126;
            byte[] keyData = new byte[24];
            System.Security.Cryptography.MD5CryptoServiceProvider MD5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
            MD5.ComputeHash(UTF8Encoding.UTF8.GetBytes(_cryptoKey)).CopyTo(keyData, 0);
            MD5.ComputeHash(UTF8Encoding.UTF8.GetBytes(_cryptoKey)).CopyTo(keyData, 7);
            keyData[23] = keyData[3];

            tdes.Key = keyData;
            byte[] vector = new byte[8] { keyData[2], keyData[6], keyData[11], keyData[5], keyData[14], keyData[19], keyData[22], keyData[15] };
            System.Threading.Thread.Sleep(10);
            cryptor = tdes.CreateEncryptor(tdes.Key, vector);

            System.Threading.Thread.Sleep(10);
            decryptor = tdes.CreateDecryptor(tdes.Key, vector);
            System.Threading.Thread.Sleep(10);

            
            }
        }
        public static System.Security.SecureString cryptoKeyProtected = new System.Security.SecureString();
        public static bool encryptionON = false;
        #endregion ---Vars---
static        System.Security.Cryptography.ICryptoTransform cryptor;
      static  System.Security.Cryptography.ICryptoTransform decryptor;
        static unpacker()
        {
            Load();
        }
        static void Load()
        {
            CryptoKey = "FERFRE";

        }

        #region GetFilesInClass
        public static System.Collections.Generic.SortedList<string, System.IO.Stream> GetFilesInClass(string FolderClassName)
        {
            System.Collections.Generic.SortedList<string, System.IO.Stream> FileList = new SortedList<string, System.IO.Stream>();
            var thisAssembly = System.Reflection.Assembly.GetExecutingAssembly();
            foreach (string resource in thisAssembly.GetManifestResourceNames())
            {
                if (resource.Contains(FolderClassName))
                {
                    string[] cutter = new string[] { FolderClassName };
                    var name = resource.Split(cutter, StringSplitOptions.RemoveEmptyEntries)[1];
                    FileList.Add(name, thisAssembly.GetManifestResourceStream(resource));
                }
            }
            return FileList;
        }
        #endregion ---GetFilesInClass---

        #region GetFilesInClass
        private static byte[] DoEncrypt(byte[] bufferIN, System.Security.SecureString keyIN)
        {
            return bufferIN;
        }
        #endregion ---GetFilesInClass---

        
        #region Unpack & Save
        public static void UnpackFiles(string dirIN, string FolderClassName)
        {
            try
            {
                var onDIR = System.Environment.CurrentDirectory;

                var fileList = GetFilesInClass(FolderClassName);
                foreach (string fileName in fileList.Keys)
                {
                    var stream = fileList[fileName];
                    WriteFileToDisk(dirIN, fileName, stream);
                }
                System.IO.Directory.SetCurrentDirectory(onDIR);
            }
            catch { }
        }

        public static void WriteFileToDisk(string targetFolder, string FileNameIN, System.IO.Stream StreamIN)
        {
            System.IO.Directory.SetCurrentDirectory(targetFolder);
            if (FileNameIN.Contains("."))
            {
                string folder = FileNameIN.Substring(0, FileNameIN.LastIndexOf('.'));
                switch (FileNameIN.Substring(FileNameIN.LastIndexOf('.') + 1))
                {
                    case "config":
                    case "manifest":
                        folder = folder.Substring(0, folder.LastIndexOf('.'));
                        break;
                }

                if (folder.Contains("."))
                {
                    folder = folder.Substring(0, folder.LastIndexOf('.'));
                    string[] folders = folder.Split(".".ToCharArray());
                    foreach (string inFolder in folders)
                    {
                        if (inFolder != string.Empty)
                        {
                            if (!System.IO.Directory.Exists(inFolder))
                                System.IO.Directory.CreateDirectory(inFolder);

                            System.IO.Directory.SetCurrentDirectory(inFolder);
                            FileNameIN = FileNameIN.Remove(0, inFolder.Length + 1);
                        }
                    }
                }
            }

            System.IO.FileStream file = System.IO.File.Create(FileNameIN);
            System.IO.MemoryStream MS = new System.IO.MemoryStream((int)StreamIN.Length);

            byte[] buffer = new byte[StreamIN.Length];
            StreamIN.Read(buffer, 0, (int)StreamIN.Length);
            MS.Write(buffer, 0, (int)StreamIN.Length);

            MS.Position = 0;
            MS = decryptedBuffer(cryptoKeyProtected, MS);

            StreamIN.Flush();
            MS.Flush();
            StreamIN.Close();
            MS.WriteTo(file);
            file.Flush();
            MS.Close();
            file.Close();
        }
        #endregion ---Unpack & Save---
 
        #region EncryptFiles & Save
        public static void EncryptFiles(string dirIN, string FolderClassName)
        {
            var onDIR = System.Environment.CurrentDirectory;

            var fileList = GetFilesInClass(FolderClassName);
            foreach (string fileName in fileList.Keys)
            {
                var stream = fileList[fileName];
                WriteFileToDiskEncryptFiles(dirIN, fileName, stream);
            }
            System.IO.Directory.SetCurrentDirectory(onDIR);
        }

        private static void WriteFileToDiskEncryptFiles(string targetFolder, string FileNameIN, System.IO.Stream StreamIN)
        {
            System.IO.Directory.SetCurrentDirectory(targetFolder);
            if (FileNameIN.Contains("."))
            {
                string folder = FileNameIN.Substring(0, FileNameIN.LastIndexOf('.'));
                switch (FileNameIN.Substring(FileNameIN.LastIndexOf('.') + 1))
                {
                    case "config":
                    case "manifest":
                        folder = folder.Substring(0, folder.LastIndexOf('.'));
                        break;
                }
                
                if (folder.Contains("."))
                {
                    folder = folder.Substring(0, folder.LastIndexOf('.'));
                    string[] folders = folder.Split(".".ToCharArray());
                    foreach (string inFolder in folders)
                    {
                        if (inFolder != string.Empty)
                        {
                            if (!System.IO.Directory.Exists(inFolder))
                                System.IO.Directory.CreateDirectory(inFolder);

                            System.IO.Directory.SetCurrentDirectory(inFolder);
                            FileNameIN = FileNameIN.Remove(0, inFolder.Length + 1);
                        }
                    }
                }
            }

            System.IO.MemoryStream MS = new System.IO.MemoryStream((int)StreamIN.Length);

            byte[] buffer = new byte[StreamIN.Length];
            StreamIN.Read(buffer, 0, (int)StreamIN.Length);
            MS.Write(buffer, 0, (int)StreamIN.Length);

            MS.Position = 0;
            MS = encryptedBuffer(cryptoKeyProtected, MS);

            System.IO.FileStream file = System.IO.File.Create(FileNameIN);

            StreamIN.Flush();
            MS.Flush();
            StreamIN.Close();
            MS.WriteTo(file);
            file.Flush();
            MS.Close();
            file.Close();
        }
        #endregion ---Unpack & Save---

        #region RUN Target
        public static void RunListBoxSelection(string targetFileIN)
        {
            string targetFile = targetFileIN.Replace('\\', '.');
            var thisAssembly = System.Reflection.Assembly.GetExecutingAssembly();
            var ResourceNameList = thisAssembly.GetManifestResourceNames();
            string targetResource = string.Empty;

            foreach (string resource in ResourceNameList)
            {
                if (resource.Contains(targetFile))
                    targetResource = resource;
            }

            var ResourceStream = thisAssembly.GetManifestResourceStream(targetResource);
            byte[] buffer = new byte[ResourceStream.Length];
            ResourceStream.Read(buffer, 0, (int)ResourceStream.Length);
            System.IO.MemoryStream MS = new System.IO.MemoryStream(buffer);
            try
            {
                RunStream(MS);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("error: " + targetResource + "------" + ex.Message);
            }
        }
        private static void RunStream(System.IO.MemoryStream MS)
        {
            var t=decryptedBuffer(cryptoKeyProtected, MS);
            byte[] buffer = new byte[t.Length];
            t.Read(buffer, 0, buffer.Length);

            var asm = System.Reflection.Assembly.Load(buffer);
            System.Threading.Thread runner = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
            {
                if (asm.EntryPoint.GetParameters().Length == 0)
                    asm.EntryPoint.Invoke(null, null);
                if (asm.EntryPoint.GetParameters().Length == 1)
                    asm.EntryPoint.Invoke(null, new object[] { new string[] { } });
            }));
            runner.IsBackground = true;
            runner.Start();
        }
        #endregion ---RUN Target---

        #region De/encryptedBuffer
        private static System.IO.MemoryStream encryptedBuffer(System.Security.SecureString key, System.IO.MemoryStream buffer)
        {
            byte[] buffer1 = new byte[buffer.Length];
            byte[] buffer2 = new byte[buffer1.Length];
            buffer.Read(buffer1, 0, (int)buffer1.Length);

            if (encryptionON)
            {

                try
                {
                    buffer2 = cryptor.TransformFinalBlock(buffer1, 0, buffer1.Length);
                }
                catch(System.Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show("CryptoFail #r43grtg - > " + ex.Message);
                }
            }

            return new System.IO.MemoryStream(buffer2);
        }
        private static System.IO.MemoryStream decryptedBuffer(System.Security.SecureString key, System.IO.MemoryStream buffer)
        {
            byte[] buffer1 = new byte[buffer.Length];
            byte[] buffer2 = new byte[buffer.Length];
            buffer.Read(buffer1, 0, buffer1.Length);

            if (encryptionON)
            {
                try
                {
                    buffer2 = decryptor.TransformFinalBlock(buffer1, 0, buffer1.Length);
                }
                catch(System.Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show("DeCryptoFail #gerty56 - > " + ex.Message);
                }
            }

            return new System.IO.MemoryStream(buffer2);
        }
        #endregion ---De/ecryptedBuffer---
    }
}