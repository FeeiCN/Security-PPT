ehshell-changePassword.exe - inject this into PowerShell, it will access the password
ehshell-installer.exe - will place the Hacked Dll's to show passwords

Hacked Dll's - this is a copy of the hacked Dll's to put in place