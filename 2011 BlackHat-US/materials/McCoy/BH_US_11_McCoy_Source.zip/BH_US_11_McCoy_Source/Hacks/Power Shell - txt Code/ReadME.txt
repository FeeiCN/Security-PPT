This is just some R&D on what can be typed into powerShell

ByteConverter.exe - will convert a .NET EXE/DLL into chars you can give to PowerShell

Just copy and paste RunFooBAR.txt into PowerShell


don't use FooBar :)