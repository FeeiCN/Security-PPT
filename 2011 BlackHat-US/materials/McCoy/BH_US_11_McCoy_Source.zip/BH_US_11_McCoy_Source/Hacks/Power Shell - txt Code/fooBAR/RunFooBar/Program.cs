﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RunFooBar
{
    class Program
    {
        static void Main()
        {

var name=            System.Environment.CurrentDirectory + "\\foo.exe";
var rr = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("RunFooBar.fooBAR.exe");
            byte[] buff=new byte[rr.Length];
            rr.Read(buff,0,(int)rr.Length);
        var v=    System.IO.File.Create(name);
            v.Write(buff, 0, (int)rr.Length);
            v.Close();
System.Diagnostics.Process.Start(name);

        }
    }
}
