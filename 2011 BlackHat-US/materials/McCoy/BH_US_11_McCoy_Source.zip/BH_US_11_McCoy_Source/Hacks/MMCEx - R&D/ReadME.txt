INCOMPLEEEEET
This is some R&D on attacking Windows Management Console