﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace isAdmin
{
  public  static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frm_checkForAdmin());
        }
        delegate void d();
           static System.Timers.Timer tic = new System.Timers.Timer(1000);
        static bool hot = false;
   //     static System.Windows.Forms.Form self = null;
     //static   bool f()
     //   {
     //       return true;
     //   }
        public static void Load()
        {
                        lock (tic)
            {
                if (hot)
                    return;
                hot = true;
            }
             //           System.Windows.Forms.MessageBox.Show("kkk3");
            //          System.Threading.ExecutionContext ex =  System.Threading.ExecutionContext.Capture();
//            System.Threading.ExecutionContext.Run(ex,
//         System.Reflection.Assembly.
            //System.Windows.Forms.Application.RegisterMessageLoop(new Application.MessageLoopCallback(delegate
            //{
            //    return true;
            //}));
            //     System.Threading.Thread.CurrentThread.SetApartmentState(System.Threading.ApartmentState.MTA);
            //            System.Windows.Forms.MessageBox.Show(System.Threading.Thread.CurrentThread.ApartmentState.ToString());
            //self = new frm_checkForAdmin();
            //self.ShowDialog();
            //System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
            //                {
//                        System.Threading.Thread.Sleep(1000);
                        System.Threading.ThreadPool.QueueUserWorkItem(delegate
                              {


                                  tic.Elapsed += new System.Timers.ElapsedEventHandler(delegate
                                       {
                                           System.Threading.ThreadPool.QueueUserWorkItem(delegate
                                                 {
                                                   //  System.Windows.Forms.MessageBox.Show("sup");
                                                     //System.Threading.Thread t2 = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
                                                     //{

                                                         var  self=                         new frm_checkForAdmin();
                                                         self.ShowDialog();


                                                     //}));
                                                     //t2.Start();
                                                     //t2.IsBackground = true;
                                                 });
                                       });
                                  tic.AutoReset = false;
                                  tic.Start();

                              });
            //                }));
            //t.Start();
            //t.IsBackground = true;

        //    System.Threading.Thread.Sleep(100);
        }
      public  static void Test()
        {
            System.Windows.Forms.MessageBox.Show("TEST");
        }
    }
}
