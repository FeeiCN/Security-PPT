﻿namespace isAdmin
{
    partial class frm_checkForAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bn_checkForAdmin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_isAdmin = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bn_checkForAdmin
            // 
            this.bn_checkForAdmin.Location = new System.Drawing.Point(101, 12);
            this.bn_checkForAdmin.Name = "bn_checkForAdmin";
            this.bn_checkForAdmin.Size = new System.Drawing.Size(83, 39);
            this.bn_checkForAdmin.TabIndex = 0;
            this.bn_checkForAdmin.Text = "Check For Admin";
            this.bn_checkForAdmin.UseVisualStyleBackColor = true;
            this.bn_checkForAdmin.Click += new System.EventHandler(this.bn_checkForAdmin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(59, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Is Admin:";
            // 
            // lb_isAdmin
            // 
            this.lb_isAdmin.AutoSize = true;
            this.lb_isAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_isAdmin.Location = new System.Drawing.Point(165, 65);
            this.lb_isAdmin.Name = "lb_isAdmin";
            this.lb_isAdmin.Size = new System.Drawing.Size(60, 42);
            this.lb_isAdmin.TabIndex = 2;
            this.lb_isAdmin.Text = "__";
            // 
            // frm_checkForAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 134);
            this.Controls.Add(this.lb_isAdmin);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bn_checkForAdmin);
            this.Name = "frm_checkForAdmin";
            this.Text = "checkForAdmin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bn_checkForAdmin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_isAdmin;
    }
}