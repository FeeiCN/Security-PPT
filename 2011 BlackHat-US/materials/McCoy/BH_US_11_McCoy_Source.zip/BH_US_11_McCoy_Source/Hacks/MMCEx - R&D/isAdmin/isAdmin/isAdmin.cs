﻿using System;
using System.Collections.Generic;
using System.Text;

namespace isAdmin
{
    public class isAdmin
    {
        public static bool check()
        {
            AppDomain.CurrentDomain.SetPrincipalPolicy(System.Security.Principal.PrincipalPolicy.WindowsPrincipal);
            System.Security.Principal.WindowsPrincipal windowsPrincipal = (System.Security.Principal.WindowsPrincipal)System.Threading.Thread.CurrentPrincipal;
                if (windowsPrincipal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator))
                {
                    return true;
                }
                else
                {
                    return false;
                }
        }
    }
}
