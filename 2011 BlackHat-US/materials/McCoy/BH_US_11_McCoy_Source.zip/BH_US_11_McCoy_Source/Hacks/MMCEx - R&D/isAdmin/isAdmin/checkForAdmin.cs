﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace isAdmin
{
    public partial class frm_checkForAdmin : Form
    {
        public frm_checkForAdmin()
        {
            InitializeComponent();
        }

        private void bn_checkForAdmin_Click(object sender, EventArgs e)
        {
            if (isAdmin.check())
                lb_isAdmin.Text = "YES";
            else
                lb_isAdmin.Text = "NO";

        }
    }
}
