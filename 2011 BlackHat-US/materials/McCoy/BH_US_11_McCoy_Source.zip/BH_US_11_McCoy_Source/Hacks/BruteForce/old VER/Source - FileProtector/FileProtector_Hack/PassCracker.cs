﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Reflection;
using System.IO;

namespace PassCrack
{
    public partial class PassCracker : Form
    {
        public string[] resources;
     public   string targetPasswordHash = string.Empty;
        public List<string> info = new List<string>();
        public PassCracker()
        {
            if(GetPassword != null)
            this.Text+= " - FileProtector";

            InitializeComponent();
            tb_testChars.Text = testChars;
        }

        private string ByteArrayToString(byte[] arr)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            return encoding.GetString(arr);
        }

        object targetHost;

        private void PassCracker_Load(object sender, EventArgs e)
        {
            tb_codeInput.Text = targetPasswordHash;

            try
            {
                object onOBJ = null;

                foreach (System.Windows.Forms.Form f in System.Windows.Forms.Application.OpenForms)
                {
                    if (f.Name == "FrmPwd")
                    {
                        onOBJ = f;
                        break;
                    }
                }

                System.Windows.Forms.Control b = onOBJ as System.Windows.Forms.Control;

                System.Windows.Forms.Form targetForm = null;
                while (b.Parent != null)
                    b = b.Parent;
                
                targetForm = b as System.Windows.Forms.Form;

                try
                {
                    var hash = targetForm.GetType().GetField("xee3b41afe0742e9f", System.Reflection.BindingFlags.FlattenHierarchy | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                    string KeyHash = hash.GetValue(targetForm).ToString();
                    targetPasswordHash = KeyHash;
                    tb_codeInput.Text = KeyHash;

                }
                catch
                {
                }
                try
                {
                    var setKey = targetForm.GetType().GetField("xb69f425f7800bb55", System.Reflection.BindingFlags.FlattenHierarchy | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public);
                    setKey.SetValue(targetForm, "FAKE");
                }
                catch
                {

                }

                targetHost = targetForm;

                foreach (System.Windows.Forms.Control c in targetForm.Controls)
                {
                    foreach (System.Windows.Forms.Control c2 in c.Controls)
                    {
//                        c2.Enabled = true;
                        if (c2 is System.Windows.Forms.TextBox)
                            passwordboxInOtherProgram = c2 as System.Windows.Forms.TextBox;
                    }
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Fail to Load :(");
            }

        }
        System.Windows.Forms.TextBox passwordboxInOtherProgram;
        private string getHash(string PasswordIN)
        {
            System.Collections.Generic.List<byte> bb = new List<byte>();
            foreach (char c in PasswordIN)
            {
                bb.Add(System.Convert.ToByte(c));
            }
            var t2 = System.Security.Cryptography.SHA512.Create();
            t2.ComputeHash(bb.ToArray());

            string s = string.Empty;
            foreach (var ba in t2.Hash)
            {
                s += System.Convert.ToChar(ba);
            }

            return s;
        }
        System.Reflection.MethodInfo _getPassword;

        public System.Reflection.MethodInfo GetPassword
        {
            get {
                if (_getPassword == null)
                {
                    try
                    {
                        var tt1 = System.Reflection.Assembly.GetEntryAssembly().GetType("Enc.xcdd6eea5cf80c375");
                        _getPassword = tt1.GetMethod("xa0728089e38024b0", System.Reflection.BindingFlags.Static | BindingFlags.Public, null, new Type[] { typeof(string) }, null);
                    }
                    catch
                    {
                        _getPassword = null;
                    }
                }
                return _getPassword; }
        }
        private string getHashFromTarget(string PasswordIN)
        {
            var temp = GetPassword.Invoke(null, new object[] { PasswordIN });
            return  (string)temp;
        }


        delegate void d();
        char blank = ' ';
        string testChars =" 1234567890";
     //   string testChars = " 1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        private void bn_crack_Click(object sender, EventArgs e)
        {

            testChars = blank + tb_testChars.Text;
            tb_password.Text = "";
            System.Timers.Timer tic = new System.Timers.Timer(300);
            tic.AutoReset = true;
            tic.Elapsed += new System.Timers.ElapsedEventHandler(tic_Elapsed);
            System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(delegate
            {
                    string s;
                    s = CrackPassword();
                    this.Invoke((d)delegate
                    {
                        tb_password.Text = s;
                        progressBar1.Visible = false;
                        lb_testPass.Text = "WIN!!!!";
                    });
                    passwordboxInOtherProgram.Invoke((d)delegate
                    {
                        passwordboxInOtherProgram.Text = s;
                    });
                    tic.Stop();
            }));
            t.IsBackground = true;
            t.Start();

            tic.Start();
            progressBar1.Visible = true;
        }

        void tic_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            this.Invoke((d)delegate
            {
                hot = true;
                lb_testPass.Text = test;
            });
            
        }
        bool hot = false;
        string test="";
        public string CrackPassword()
        {
            System.Text.StringBuilder testPass = new StringBuilder();
            string basePass = string.Empty;
            foreach (char t in testChars)
            {
                if (t == blank && testPass.Length > 0)
                    continue;
                foreach (char t1 in testChars)
                {
                    if (t1 == blank && testPass.Length > 0)
                        continue;
                    foreach (char t2 in testChars)
                    {
                        if (t2 == blank && testPass.Length > 0)
                            continue;
                        foreach (char t3 in testChars)
                        {
                            if (t3 == blank && testPass.Length > 0)
                                continue;
                            foreach (char t4 in testChars)
                            {
                                if (t4 == blank && testPass.Length > 0)
                                    continue;
                                foreach (char t5 in testChars)
                                {
                                    if (t5 == blank && testPass.Length > 0)
                                        continue;
                                    foreach (char t6 in testChars)
                                    {
                                        if (t6 == blank && testPass.Length > 0)
                                            continue;
                                        testPass.Length = 0;
                                        if (t != ' ')
                                            testPass.Append(t);
                                        if (t1 != ' ')
                                            testPass.Append(t1);
                                        if (t2 != ' ')
                                            testPass.Append(t2);
                                        if (t3 != ' ')
                                            testPass.Append(t3);
                                        if (t4 != ' ')
                                            testPass.Append(t4);
                                        if (t5 != ' ')
                                            testPass.Append(t5);
                                        if (t6 != ' ')
                                            testPass.Append(t6);

                                        try
                                        {
                                            string hash = string.Empty;
                                           if(_getPassword!= null)
                                            hash = getHashFromTarget(testPass.ToString());
                                            else
                                               hash = getHash(testPass.ToString());

                                            if (targetPasswordHash == hash)
                                            {
                                                return testPass.ToString();
                                            }
                                        }
                                        catch { }
                                      
                                        if (hot)
                                        {
                                            hot = false;
                                            test = testPass.ToString();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return "FAILED!!!!!!!!!!!!";
        }
    }

    //        private void bn_testHash_Click(object sender, EventArgs e)
    //        {
    //            ///                "ÔU`.«oÖ¬vÚËú­Ñ603^	zóáv¶Û(Q/.";

    //            System.Collections.Generic.List<byte> bb = new List<byte>();
    //            foreach (char c in tb_password.Text)
    //            {
    //                bb.Add(System.Convert.ToByte(c));
    //            }
    ////e????T?<???~?A?7xe??
    //         //   var t2 = System.Security.Cryptography.SHA512.Create();
    //            var t2 = System.Security.Cryptography.SHA1.Create();
    //            t2.ComputeHash(bb.ToArray());

    //            string s = string.Empty;
    //            foreach (var ba in t2.Hash)
    //            {
    //                s += System.Convert.ToChar(ba);
    //            }
    //            s = this.ByteArrayToString(t2.Hash);

    //            tb_passwordHash.Text = s;
    //        }
    //           <XML_Method>
    //                  <Name>x1d8bb49cd98015c4</Name>
    //                  <LongName>extr, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null+extr.exe-xbaa9ac430bae31c0.x1d8bb49cd98015c4</LongName>
    //                  <IsPublic>false</IsPublic>
    //                  <IsInstance>true</IsInstance>
    //                  <Code>0000 : ldarg.1
    //0001 : call string Enc.xcdd6eea5cf80c375::xa0728089e38024b0()
    //0006 : stloc.0
    //0007 : ldc.i4255
    //0012 : brtrue 0165
    //0017 : ldarg.0
    //0018 : ldfld System.Windows.Forms.Button ExtractorSFX.xbaa9ac430bae31c0::x438ae8d7d28c23d1
    //0023 : ldc.i4.0
    //0024 : callvirt instance System.Void System.Windows.Forms.Control::set_Enabled()
    //0029 : ldarg.0
    //0030 : ldfld System.Windows.Forms.ErrorProvider ExtractorSFX.xbaa9ac430bae31c0::x831ff96ccf41d267
    //0035 : ldarg.0
    //0036 : ldfld System.Windows.Forms.TextBox ExtractorSFX.xbaa9ac430bae31c0::xce9f87dbf4938523
    //0041 : ldstr "Password inserted is wrong!"
    //0046 : callvirt instance System.Void System.Windows.Forms.ErrorProvider::SetError()
    //0051 : ret
    //0052 : ldarg.0
}