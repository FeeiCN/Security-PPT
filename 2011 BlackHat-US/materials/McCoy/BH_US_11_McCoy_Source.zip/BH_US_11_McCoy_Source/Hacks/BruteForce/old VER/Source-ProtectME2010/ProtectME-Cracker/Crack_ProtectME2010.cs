﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PassCrack
{
    public interface PasswordForcer
    {
        string TargetPasswordHash { get; }
        bool MatchPassword(string testPassword);
        bool FailToLoad { get; }
        void SetPasswordBoxInOtherProgram(string passWordIN);

    }
   public class Crack_ProtectME2010 : PasswordForcer
    {
       public bool MatchPassword(string testPassword)
       {
           return targetPasswordHash == getCode(testPassword);
       }
        public string[] resources;
        private string targetPasswordHash = string.Empty;

        public string TargetPasswordHash
        {
            get { return targetPasswordHash; }
        }
        public List<string> info = new List<string>();
        System.IO.MemoryStream mem;
        System.Security.Cryptography.Rijndael rijndael;

        private bool failToLoad = true;

        public bool FailToLoad
        {
            get { return failToLoad; }
        }
        private string ByteArrayToString(byte[] arr)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            return encoding.GetString(arr);
        }
        public Crack()
        {
            try
            {
                ListIncludedFiles("GG K THK 4 PLAYING");
                buildinput();
                failToLoad = false;
            }
            catch
            {
                targetPasswordHash = string.Empty;
            }
        }
        public string targetCode()
        {
            int index = 0;
            System.IO.Stream manifestResourceStream = System.Reflection.Assembly.GetEntryAssembly().GetManifestResourceStream(this.resources[index]);
            System.IO.BinaryReader reader = new System.IO.BinaryReader(manifestResourceStream);
            byte[] arr = reader.ReadBytes(20);
            string oldPass = this.ByteArrayToString(arr);
            targetPasswordHash = oldPass;
            return oldPass;
        }
        byte[] salt = null;
        private void buildinput()
        {
            int index = 0;
            System.IO.Stream manifestResourceStream = System.Reflection.Assembly.GetEntryAssembly().GetManifestResourceStream(this.resources[index]);
            System.IO.BinaryReader reader = new System.IO.BinaryReader(manifestResourceStream);
            byte[] arr = reader.ReadBytes(20);
            string oldPass = this.ByteArrayToString(arr);

            var IV = reader.ReadBytes(0x10);
            salt = reader.ReadBytes(0x20);

            byte[] arr2 = reader.ReadBytes(0x120 + 1);
            mem = new System.IO.MemoryStream(arr2);

            rijndael = System.Security.Cryptography.Rijndael.Create();
            rijndael.IV = IV;
        }
        private string getCode(string passwordIN)
        {
            System.Security.Cryptography.Rfc2898DeriveBytes bytes = new System.Security.Cryptography.Rfc2898DeriveBytes(passwordIN, 0x20);
            bytes.Salt = salt;
            rijndael.Key = bytes.GetBytes(rijndael.KeySize / 8);
            mem.Position = 0;
            System.Security.Cryptography.CryptoStream stream2 = new System.Security.Cryptography.CryptoStream(mem, rijndael.CreateDecryptor(), System.Security.Cryptography.CryptoStreamMode.Read);

            byte[] buffer = new byte[0x100];
            int newSize = stream2.Read(buffer, 0, buffer.Length);
            Array.Resize<byte>(ref buffer, newSize);

            System.Security.Cryptography.SHA1CryptoServiceProvider provider = new System.Security.Cryptography.SHA1CryptoServiceProvider();
            byte[] buffer3 = provider.ComputeHash(buffer);

            return this.ByteArrayToString(buffer3);
            //Rfc2898DeriveBytes bytes = new Rfc2898DeriveBytes(passwordIN, 0x20);
            //Stream manifestResourceStream = Assembly.GetEntryAssembly().GetManifestResourceStream(this.resources[0]);
            //BinaryReader reader = new BinaryReader(manifestResourceStream);
            //byte[] arr = reader.ReadBytes(20);
            //var IV2 = reader.ReadBytes(0x10);
            //salt = reader.ReadBytes(0x20);
            //bytes.Salt = salt;
            //Rijndael rijndael = Rijndael.Create();
            //rijndael.Key = bytes.GetBytes(rijndael.KeySize / 8);
            //rijndael.IV = IV2;
            //CryptoStream stream2 = new CryptoStream(manifestResourceStream, rijndael.CreateDecryptor(), CryptoStreamMode.Read);
            //SHA1CryptoServiceProvider provider = new SHA1CryptoServiceProvider();
            //byte[] buffer = new byte[0x100];
            //int newSize = stream2.Read(buffer, 0, buffer.Length);
            //Array.Resize<byte>(ref buffer, newSize);
            //byte[] buffer3 = provider.ComputeHash(buffer);
            //string str = this.ByteArrayToString(buffer3);

            //return str;
        }
        public void ListIncludedFiles(string password)
        {
            try
            {
                this.info.Clear();
                System.Reflection.Assembly.GetEntryAssembly().GetManifestResourceNames();
                using (System.IO.Stream stream = System.Reflection.Assembly.GetEntryAssembly().GetManifestResourceStream("info.txt"))
                {
                    using (System.IO.StreamReader reader = new System.IO.StreamReader(stream))
                    {
                        while (!reader.EndOfStream)
                        {
                            this.info.Add(reader.ReadLine());
                        }
                        this.resources = new string[this.info.Count];
                        for (int i = 0; i < this.info.Count; i++)
                        {
                            System.Windows.Forms.ListViewItem item = new System.Windows.Forms.ListViewItem();
                            string str = this.info[i].Split("*".ToCharArray())[0];
                            string text = this.info[i].Split("*".ToCharArray())[1];
                            string str3 = this.info[i].Split("*".ToCharArray())[2];
                            this.resources[i] = this.info[i].Split("*".ToCharArray())[3];
                            item.Text = str3 + str;
                            item.SubItems.Add(text);
                            //  this.lFiles.Items.Add(item);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
                System.Windows.Forms.MessageBox.Show("Fail to load: Information database not found!");
            }
        }
        public void SetPasswordBoxInOtherProgram(string passWordIN)
        {
            // not implemented SORRY:)
            //passwordboxInOtherProgram.Invoke((d)delegate
            //{
            //    passwordboxInOtherProgram.Text = passWordIN;
            //});
        }
    }
}
