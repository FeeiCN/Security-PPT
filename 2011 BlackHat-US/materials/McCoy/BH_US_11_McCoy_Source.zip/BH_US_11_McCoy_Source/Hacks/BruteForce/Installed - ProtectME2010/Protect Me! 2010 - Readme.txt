Application:		Protect Me! 2010 1.0.1.1
Author: 			DiSTANTX
Homepage:			www.wecode.biz	
Requirements:		.NET Framework 3.5


About(English):

Protect Me! 2010 creates secure executable (.exe) container files to which you can add any files and directories you want to! 
Your files will be stored securely inside the container file. 
To ensure a maximum of security, Protect Me! 2010 uses SHA1 for password validation and AES for encryption.
The container file can either run or extract your files once you typed in the right password. 

Key Features:

    * Easily password-protect any file you want!
    * You get one .exe file which contains the encrypted file(s) 
          o The result will be just a few KB bigger than the encrypted files themselves!
    * Your data is really secure! 
          o SHA1 for password validation
          o AES (Rijndael) for your data
    * The container file is compiled at runtime! 
    
    
�ber(Deutsch):
Protect Me! 2010 erstellt sichere ausf�hrbare (.exe) Containerdateien, zu welchen sie beliebig Dateien und Ordner hinzuf�gen k�nnen!
Ihre Dateien werden sicher verschl�sselt in dieser Containerdatei gespeichert.
Um maximale Sicherheit zu gew�hrleisten, benutzt Protect Me! 2010 SHA1 f�r die Passwortverifizierung und AES f�r die Verschl�sselung. 
Die Containerdatei kann Ihre Dateien entweder ausf�hren und anschlie�end l�schen, oder entpacken, nachdem Sie das Passwort eingegeben haben.

F�higkeiten:

    * Sch�tzen sie jede Datei, die Sie wollen
    * Sie erhalten eine .exe Datei, die die Dateien verschl�sselt beinhaltet 
          o Die Containerdatei ist nur wenige KB gr��er, als die verschl�sselten Dateien!
    * Ihre Daten sind extrem gut gesch�tzt! 
          o SHA1 f�r Passwortverifizierung
          o AES (Rijndael) f�r Datenverschl�sselung
    * Die Containerdatei wird sofort vom Programm erstellt! 


Changelog: 


-Version 1.0.1.1
	- Bugfix:	ShellExecute used to throw an exception if a process is run by Rundll32.exe, now it got a selfmade ShellExecute-replacement
	- Bugfix:	Executing multiple files threw an exception (reported by Anonymous)
	- Bugfix:	Buttons "Extract Everything" and "Save As" were mixed up
	- Bugfix:	Fixed some smaller issues
	
-Version 1.0.1
	- Update:	Container is multilingual now (can be overriden by parameters -en or -deu)
	- Update:	Container now asks if existing files should be overwritten
	- Bugfix:	"Execute file" didn't work properly (file naming issue)	
	- Bugfix:	Improved filesize calculation
	- GUI:		You can right-click the main application's files list and chose "Remove Selection" to remove one or more files
	- GUI:		New container GUI
	- GUI:		Improved language parameters detection (can use "-en","-deu" or "/en", "/deu" now)
	
-Version 1.0
	- GUI:		It's multilingual now (German & English)	
	- GUI:		Added Windows 7 Support (Taskbar progressbar)
	- GUI:		The main application now has an about form
	- GUI:		The whole GUI was re-designed
	- GUI:		Added a status strip
	- GUI:		Added "check for updates" 
	- Bugfix:	The application will not accept a blank password anymore
	- Bugfix:	A container was created after quitting the SaveFileDialog
	- Bugfix:	Icon options fixed
	- Bugfix:	You can create multiple container files with the same contents now
	- Bugfix:	An exception might be thrown when deleting the cached icon is not possible
	- Feature:	Automatic language detection (UI will be German if your system is German)
	- Feature:	You can override the language detection now by using the the commandline parameters "-deu" (for German) or "-en" (for English)

-Beta 2.0
	- New:		You can choose a custom icon file for your container now (suggested by Yaser Hani)
	- New:		Added the ability to clear the list of files to add	(suggested by Yaser Hani)
	- New:		The protected container asks for a password before listing its contents (suggested by Yaser Hani)
	- New:		Multithreading
	- New:		Directories can now be stored inside a container
	- New:		You can choose to extract everthing
	- New:		Better error handlung and ram usage
	- New:		Temporary (encrypted) files get cryptic filenames now
	- Bugfix:	Fixed a serious bug which prevented Protect Me! from adding files if the filepath contained a space character (reported by Yaser Hani) 
	- Bugfix:	Fixed a serious verification bug which only affected files < 256 Bytes
	- GUI:		Improved file list (shows filesize now)
	- GUI:		Fixed several smaller bugs
	- GUI:		Added full Drag&Drop support
	- GUI:		Main application's form has got an icon now
	- GUI:		Added progressbars to show the current progress
	- Fix:		Deletes temporary encrypted files
	
-Beta 1
	- initial release

-DiSTANTX


