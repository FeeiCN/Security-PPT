﻿namespace PassCrack
{
	partial class PassCracker
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PassCracker));
            this.tb_codeInput = new System.Windows.Forms.TextBox();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.bn_crack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.lb_testPass = new System.Windows.Forms.Label();
            this.tb_testChars = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tb_codeInput
            // 
            this.tb_codeInput.Location = new System.Drawing.Point(13, 30);
            this.tb_codeInput.Name = "tb_codeInput";
            this.tb_codeInput.Size = new System.Drawing.Size(192, 20);
            this.tb_codeInput.TabIndex = 0;
            // 
            // tb_password
            // 
            this.tb_password.Location = new System.Drawing.Point(13, 80);
            this.tb_password.Name = "tb_password";
            this.tb_password.Size = new System.Drawing.Size(100, 20);
            this.tb_password.TabIndex = 2;
            // 
            // bn_crack
            // 
            this.bn_crack.Location = new System.Drawing.Point(130, 80);
            this.bn_crack.Name = "bn_crack";
            this.bn_crack.Size = new System.Drawing.Size(75, 23);
            this.bn_crack.TabIndex = 3;
            this.bn_crack.Text = "Crack";
            this.bn_crack.UseVisualStyleBackColor = true;
            this.bn_crack.Click += new System.EventHandler(this.bn_crack_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Target Code:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Password:";
            // 
            // progressBar1
            // 
            this.progressBar1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.progressBar1.Enabled = false;
            this.progressBar1.Location = new System.Drawing.Point(0, 235);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(244, 23);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar1.TabIndex = 6;
            this.progressBar1.Visible = false;
            // 
            // lb_testPass
            // 
            this.lb_testPass.AutoSize = true;
            this.lb_testPass.Location = new System.Drawing.Point(13, 107);
            this.lb_testPass.Name = "lb_testPass";
            this.lb_testPass.Size = new System.Drawing.Size(54, 13);
            this.lb_testPass.TabIndex = 7;
            this.lb_testPass.Text = "Test Pass";
            // 
            // tb_testChars
            // 
            this.tb_testChars.Location = new System.Drawing.Point(13, 162);
            this.tb_testChars.Multiline = true;
            this.tb_testChars.Name = "tb_testChars";
            this.tb_testChars.Size = new System.Drawing.Size(217, 42);
            this.tb_testChars.TabIndex = 8;
            this.tb_testChars.Text = "1234567890";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Test Text:";
            // 
            // PassCracker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(244, 258);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_testChars);
            this.Controls.Add(this.lb_testPass);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bn_crack);
            this.Controls.Add(this.tb_password);
            this.Controls.Add(this.tb_codeInput);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PassCracker";
            this.Text = "PassCrack";
            this.Load += new System.EventHandler(this.PassCracker_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

        private System.Windows.Forms.TextBox tb_codeInput;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.Button bn_crack;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label lb_testPass;
        private System.Windows.Forms.TextBox tb_testChars;
        private System.Windows.Forms.Label label3;
	}
}