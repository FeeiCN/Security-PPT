﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PassCrack
{
    public interface PasswordForcer
    {
        string TargetPasswordHash { get; }
        bool MatchPassword(string testPassword);
        bool FailToLoad { get; }
        void SetPasswordBoxInOtherProgram(string passWordIN);
    }
}
