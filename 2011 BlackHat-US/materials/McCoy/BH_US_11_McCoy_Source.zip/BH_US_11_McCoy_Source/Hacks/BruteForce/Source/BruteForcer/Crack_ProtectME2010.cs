﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PassCrack
{

    public class Crack_ProtectME2010 : PasswordForcer
    {
        #region vars
        public bool MatchPassword(string testPassword)
        {
            return targetPasswordHash == getCode(testPassword);
        }
        public string[] resources;
        private string targetPasswordHash = string.Empty;
        delegate void d();

        public string TargetPasswordHash
        {
            get { return targetPasswordHash; }
        }
        public List<string> info = new List<string>();
        System.IO.MemoryStream mem;
        System.Security.Cryptography.Rijndael rijndael;

        private bool failToLoad = true;

        public bool FailToLoad
        {
            get { return failToLoad; }
        }
        private string ByteArrayToString(byte[] arr)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            return encoding.GetString(arr);
        }
        byte[] salt = null;
        #endregion ---vars---

        public Crack_ProtectME2010()
        {
            try
            {
                ListIncludedFiles("GG K THK 4 PLAYING");
                buildinput();
                targetPasswordHash = targetCode();
                failToLoad = false;
            }
            catch
            {
                failToLoad = true;
                targetPasswordHash = string.Empty;
            }
        }

        public string targetCode()
        {
            int index = 0;
            System.IO.Stream manifestResourceStream = System.Reflection.Assembly.GetEntryAssembly().GetManifestResourceStream(this.resources[index]);
            System.IO.BinaryReader reader = new System.IO.BinaryReader(manifestResourceStream);
            byte[] arr = reader.ReadBytes(20);
            string oldPass = this.ByteArrayToString(arr);
            targetPasswordHash = oldPass;
            return oldPass;
        }
        
        private void buildinput()
        {
            int index = 0;
            System.IO.Stream manifestResourceStream = System.Reflection.Assembly.GetEntryAssembly().GetManifestResourceStream(this.resources[index]);
            System.IO.BinaryReader reader = new System.IO.BinaryReader(manifestResourceStream);
            byte[] arr = reader.ReadBytes(20);
            string oldPass = this.ByteArrayToString(arr);

            var IV = reader.ReadBytes(0x10);
            salt = reader.ReadBytes(0x20);

            byte[] arr2 = reader.ReadBytes(0x120 + 1);
            mem = new System.IO.MemoryStream(arr2);

            rijndael = System.Security.Cryptography.Rijndael.Create();
            rijndael.IV = IV;
        }
        
        private string getCode(string passwordIN)
        {
            System.Security.Cryptography.Rfc2898DeriveBytes bytes = new System.Security.Cryptography.Rfc2898DeriveBytes(passwordIN, 0x20);
            bytes.Salt = salt;
            rijndael.Key = bytes.GetBytes(rijndael.KeySize / 8);
            mem.Position = 0;
            System.Security.Cryptography.CryptoStream stream2 = new System.Security.Cryptography.CryptoStream(mem, rijndael.CreateDecryptor(), System.Security.Cryptography.CryptoStreamMode.Read);

            byte[] buffer = new byte[0x100];
            int newSize = stream2.Read(buffer, 0, buffer.Length);
            Array.Resize<byte>(ref buffer, newSize);

            System.Security.Cryptography.SHA1CryptoServiceProvider provider = new System.Security.Cryptography.SHA1CryptoServiceProvider();
            byte[] buffer3 = provider.ComputeHash(buffer);

            return this.ByteArrayToString(buffer3);

            //This is the base code
            //Rfc2898DeriveBytes bytes = new Rfc2898DeriveBytes(passwordIN, 0x20);
            //Stream manifestResourceStream = Assembly.GetEntryAssembly().GetManifestResourceStream(this.resources[0]);
            //BinaryReader reader = new BinaryReader(manifestResourceStream);
            //byte[] arr = reader.ReadBytes(20);
            //var IV2 = reader.ReadBytes(0x10);
            //salt = reader.ReadBytes(0x20);
            //bytes.Salt = salt;
            //Rijndael rijndael = Rijndael.Create();
            //rijndael.Key = bytes.GetBytes(rijndael.KeySize / 8);
            //rijndael.IV = IV2;
            //CryptoStream stream2 = new CryptoStream(manifestResourceStream, rijndael.CreateDecryptor(), CryptoStreamMode.Read);
            //SHA1CryptoServiceProvider provider = new SHA1CryptoServiceProvider();
            //byte[] buffer = new byte[0x100];
            //int newSize = stream2.Read(buffer, 0, buffer.Length);
            //Array.Resize<byte>(ref buffer, newSize);
            //byte[] buffer3 = provider.ComputeHash(buffer);
            //string str = this.ByteArrayToString(buffer3);

            //return str;
        }

        public void ListIncludedFiles(string password)
        {
            this.info.Clear();
            System.Reflection.Assembly.GetEntryAssembly().GetManifestResourceNames();
            using (System.IO.Stream stream = System.Reflection.Assembly.GetEntryAssembly().GetManifestResourceStream("info.txt"))
            {
                using (System.IO.StreamReader reader = new System.IO.StreamReader(stream))
                {
                    while (!reader.EndOfStream)
                    {
                        this.info.Add(reader.ReadLine());
                    }
                    this.resources = new string[this.info.Count];
                    for (int i = 0; i < this.info.Count; i++)
                    {
                        System.Windows.Forms.ListViewItem item = new System.Windows.Forms.ListViewItem();
                        string str = this.info[i].Split("*".ToCharArray())[0];
                        string text = this.info[i].Split("*".ToCharArray())[1];
                        string str3 = this.info[i].Split("*".ToCharArray())[2];
                        this.resources[i] = this.info[i].Split("*".ToCharArray())[3];
                        item.Text = str3 + str;
                        item.SubItems.Add(text);
                        //  this.lFiles.Items.Add(item);
                    }
                }
            }
        }
        public void overRideButtion()
        {
            //foreach (System.Windows.Forms.Form f in System.Windows.Forms.Application.OpenForms)
            //{
            //    if (f.Name == "Validation")
            //    {
            //        onOBJ = f;
            //        break;
            //    }
            //}

            //Form1 form = new Form1(this.parameters);
            //if (!string.IsNullOrEmpty(this.txtPW.Text))
            //{
            //    form.password = this.txtPW.Text;
            //    Assembly.GetExecutingAssembly().GetManifestResourceNames();
            //    using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("info.txt"))
            //    {
            //        using (StreamReader reader = new StreamReader(stream))
            //        {
            //            while (!reader.EndOfStream)
            //            {
            //                form.info.Add(reader.ReadLine());
            //            }
            //            form.resources = new string[form.info.Count];
            //            string str = form.info[0].Split("*".ToCharArray())[3];
            //            form.resources[0] = str;
            //        }
            //    }
            //    byte[] iV = new byte[0];
            //    byte[] salt = new byte[0];
            //    if (form.IsValidPw(0, ref iV, ref salt))
            //    {
            //        form.ListIncludedFiles(this.txtPW.Text);
            //        base.Hide();
            //    }
            //    else
            //    {
            //        MessageBox.Show("You need to enter the valid password!", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            //        this.txtPW.Text = "";
            //        this.txtPW.Focus();

            //    }
            //}
        }
        public void SetPasswordBoxInOtherProgram(string passWordIN)
        {
            try
            {
                object onOBJ = null;

                foreach (System.Windows.Forms.Form f in System.Windows.Forms.Application.OpenForms)
                {
                    if (f.Name == "Validation")
                    {
                        onOBJ = f;
                        break;
                    }
                }

                if (onOBJ != null)
                {
                    foreach (System.Windows.Forms.Control p in ((System.Windows.Forms.Form)onOBJ).Controls)
                    {
                        if (p is System.Windows.Forms.GroupBox)
                        {
                            foreach (System.Windows.Forms.Control t in p.Controls)
                            {
                                if (t is System.Windows.Forms.TextBox)
                                {
                                    t.Invoke((d)delegate
                                    {
                                        t.Text = passWordIN;
                                    });
                                }
                            }
                        }
                    }
                }
            }
            catch
            {
            }
        }
    }
}