﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PassCrack
{
    public class Crack_FileProtector : PasswordForcer
    {
        #region vars
        private bool failToLoad = true;

        public bool FailToLoad
        {
            get { return failToLoad; }
        }
        object targetHost;
        System.Windows.Forms.TextBox passwordboxInOtherProgram;
        public string[] resources;
        private string targetPasswordHash = string.Empty;

        public string TargetPasswordHash
        {
            get { return targetPasswordHash; }
        }
        public List<string> info = new List<string>();


        private string ByteArrayToString(byte[] arr)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            return encoding.GetString(arr);
        }
        System.Reflection.MethodInfo _getPassword;
        delegate void d();

        public System.Reflection.MethodInfo GetPassword
        {
            get
            {
                if (_getPassword == null)
                {
                    try
                    {
                        var tt1 = System.Reflection.Assembly.GetEntryAssembly().GetType("Enc.xcdd6eea5cf80c375");
                        _getPassword = tt1.GetMethod("xa0728089e38024b0", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public, null, new Type[] { typeof(string) }, null);
                    }
                    catch
                    {
                        _getPassword = null;
                    }
                }
                return _getPassword;
            }
        }
        #endregion ---vars---

        public Crack_FileProtector()
        {
            Load();
        }
        public bool MatchPassword(string testPassword)
        {
            return targetPasswordHash == getHash(testPassword);
        }
        private void Load()
        {
            try
            {
                object onOBJ = null;

                foreach (System.Windows.Forms.Form f in System.Windows.Forms.Application.OpenForms)
                {
                    if (f.Name == "FrmPwd")
                    {
                        onOBJ = f;
                        break;
                    }
                }

                if (onOBJ == null)
                {
                    failToLoad = true;
                    return;
                }
                System.Windows.Forms.Control b = onOBJ as System.Windows.Forms.Control;

                System.Windows.Forms.Form targetForm = null;
                while (b.Parent != null)
                    b = b.Parent;

                targetForm = b as System.Windows.Forms.Form;

                try
                {
                    var hash = targetForm.GetType().GetField("xee3b41afe0742e9f", System.Reflection.BindingFlags.FlattenHierarchy | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                    string KeyHash = hash.GetValue(targetForm).ToString();
                    targetPasswordHash = KeyHash;
                }
                catch
                {
                }

                try
                {
                    var setKey = targetForm.GetType().GetField("xb69f425f7800bb55", System.Reflection.BindingFlags.FlattenHierarchy | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public);
                    setKey.SetValue(targetForm, "FAKE");
                }
                catch
                {

                }

                targetHost = targetForm;

                foreach (System.Windows.Forms.Control c in targetForm.Controls)
                {
                    foreach (System.Windows.Forms.Control c2 in c.Controls)
                    {
                        //                        c2.Enabled = true;
                        if (c2 is System.Windows.Forms.TextBox)
                            passwordboxInOtherProgram = c2 as System.Windows.Forms.TextBox;
                    }
                }

                failToLoad = false;
            }
            catch
            {
                failToLoad = true;
            }

        }
        private string getHash(string PasswordIN)
        {
            System.Collections.Generic.List<byte> bb = new List<byte>();
            foreach (char c in PasswordIN)
            {
                bb.Add(System.Convert.ToByte(c));
            }
            var t2 = System.Security.Cryptography.SHA512.Create();
            t2.ComputeHash(bb.ToArray());

            string s = string.Empty;
            foreach (var ba in t2.Hash)
            {
                s += System.Convert.ToChar(ba);
            }

            return s;
        }
        public void SetPasswordBoxInOtherProgram(string passWordIN)
        {
            passwordboxInOtherProgram.Invoke((d)delegate
            {
                passwordboxInOtherProgram.Text = passWordIN;
            });
        }
        private string getHashFromTarget(string PasswordIN)
        {
            var temp = GetPassword.Invoke(null, new object[] { PasswordIN });
            return (string)temp;
        }
    }
}