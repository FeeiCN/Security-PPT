Installed - FileProtector - backup software, to add a password.
Installed - ProtectME2010 - backup software, to add a password.

Source - The source code of the hack.

afp_sdx-???.exe - FileProtector - a encrypted backup of a file, protected by a non-.NET shell.
BlackHat2011.exe - ProtectME2010 - an encrypted packer

BruteForcer.exe - the hack to get the password for afp_sdx-???.exe


Inject BruteForcer.exe into BlackHat2011.exe or afp_sdx-???.exe