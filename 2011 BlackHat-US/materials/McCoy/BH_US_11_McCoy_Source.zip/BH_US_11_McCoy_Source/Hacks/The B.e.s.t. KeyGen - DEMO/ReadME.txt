BestAppEver.exe - a demo reg code

BestKeyGenEver.exe - a demo KeyGen

Don't know what B.e.s.t. is for but....