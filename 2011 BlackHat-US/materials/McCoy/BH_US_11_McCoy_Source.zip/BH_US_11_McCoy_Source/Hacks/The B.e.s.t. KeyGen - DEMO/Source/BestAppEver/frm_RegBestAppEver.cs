﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Best_App_Ever
{
    public partial class frm_RegBestAppEver : Form
    {
        public frm_RegBestAppEver()
        {
            InitializeComponent();
        }

        private void bn_unloack_Click(object sender, EventArgs e)
        {
            bool validKey = Best_App_Ever.TeskKey.KeyCheck(tb_name.Text, tb_key.Text);
            if (validKey)
            {
                Random ran = new Random();
                this.BackColor = Color.FromArgb(ran.Next(254), ran.Next(254), ran.Next(254));
                System.Windows.Forms.MessageBox.Show("ACCEPTED");
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("you must have typed it wrong!");
            }
        }
    }
}
