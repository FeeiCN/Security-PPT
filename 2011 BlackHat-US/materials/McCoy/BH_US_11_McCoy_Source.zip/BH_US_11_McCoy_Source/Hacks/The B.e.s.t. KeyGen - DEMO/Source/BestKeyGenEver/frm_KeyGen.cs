﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BestKeyGenEver
{
    public partial class frm_KeyGen : Form
    {
        public frm_KeyGen()
        {
            InitializeComponent();
        }

        private void tb_name_TextChanged(object sender, EventArgs e)
        {
string key=            BestKeyGenEver.TheCrack.KeyGen(tb_name.Text);
tb_key.Text = key;
tb_key.SelectAll();
            
        }

        private void frm_KeyGen_Load(object sender, EventArgs e)
        {

            string key = BestKeyGenEver.TheCrack.KeyGen(tb_name.Text);
            tb_key.Text = key;
            tb_key.SelectAll();
        }
    }
}
