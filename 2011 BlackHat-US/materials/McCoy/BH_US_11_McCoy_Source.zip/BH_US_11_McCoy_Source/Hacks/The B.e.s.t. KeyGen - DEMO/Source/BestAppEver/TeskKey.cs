﻿using System;
using System.Text;

namespace Best_App_Ever
{
    class TeskKey
    {
        public static bool KeyCheck(string Name, string key)
        {
            try
            {
                string str = "BAEv1";
                if (key.Length != 0x29)
                {
                    return false;
                }
                if (Name.Length < 1)
                {
                    return false;
                }

                for (int i = 0; i < 0x29; i++)
                {
                    if (((i + 1) % 7) == 0)
                    {
                        if (key[i] != '-')
                        {
                            return false;
                        }
                    }
                    else if ("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".IndexOf(key[i]) == -1)
                    {
                        return false;
                    }
                }

                key = key.Substring(0, 6) + key.Substring(7, 6) + key.Substring(14, 6) + key.Substring(0x15, 6) + key.Substring(0x1c, 6) + key.Substring(0x23, 6);
                key = jumpCode(key);
                string[] strArray = new string[7];
                for (int j = 0; j < 7; j++)
                {
                    strArray[j] = key.Substring(5 * j, 5);
                }
                uint[] numArray = new uint[7];
                for (int k = 0; k < 7; k++)
                {
                    numArray[k] = keyJumbel(strArray[k]);
                }
                string str2 = "";
                for (int m = 0; m < 6; m++)
                {
                    for (int num5 = 0; num5 < 5; num5++)
                    {
                        int num6 = ((int)((numArray[m] & ((uint)(Math.Pow(2.0, 25.0) - 1.0))) >> (5 * (4 - num5)))) & 0x1f;
                        str2 = str2 + chalangeEQU(num6, m, num5);
                    }
                }
                bool flag = true;
                StringBuilder builder = new StringBuilder(Name.ToLower());
                for (int n = 0; n < Name.Length; n++)
                {
                    if ((builder[n] < 'a') || ('z' < builder[n]))
                    {
                        builder[n] = (char)(0x61 + (builder[n] % '\x001a'));
                    }
                }

                StringBuilder builder2 = new StringBuilder(str.ToLower());
                for (int num8 = 0; num8 < str.Length; num8++)
                {
                    if ((builder2[num8] < 'a') || ('z' < builder2[num8]))
                    {
                        builder2[num8] = (char)(0x61 + (builder2[num8] % '\x001a'));
                    }
                }
                builder.Length = 0x19;
                for (int num9 = 0; num9 < 0x19; num9++)
                {
                    builder[num9] = builder[num9 % Name.Length];
                }
                builder.Append(builder2);
                if (str2 != builder.ToString())
                {
                    flag = false;
                }

                int num10 = ((int)(numArray[6] >> 5)) & 0x7ffff;
                int num11 = 0x1337;
                int num12 = 1;
                for (int num13 = 0; num13 < Name.Length; num13++)
                {
                    num11 += Name[num13] * num12;
                    num12 = (num12 % 9) + 1;
                }
                num11 = num11 % 0x31415;
                if (num11 != num10)
                {
                    flag = false;
                }
                return flag;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static string chalangeEQU(int num1, int num2, int num3)
        {
            num1 -= ((2 * num2) + (3 * num3)) + 6;
            while (num1 < 0)
            {
                num1 += 32;
            }
            num1 = num1 % 32;
            char ch = (char)((num1 + 92));
            return ch.ToString();
        }

        private static uint keyJumbel(string keyyIN)
        {
            StringBuilder builder = new StringBuilder();
            builder.Length = 0x3e;
            builder[0] = 'V';
            builder[1] = 'A';
            builder[2] = 'j';
            builder[3] = 'T';
            builder[4] = 'C';
            builder[5] = 'N';
            builder[6] = 'h';
            builder[7] = '8';
            builder[8] = 'S';
            builder[9] = 'e';
            builder[10] = 'G';
            builder[11] = 'R';
            builder[12] = 'u';
            builder[13] = 'i';
            builder[14] = 'x';
            builder[15] = '3';
            builder[0x10] = 'Z';
            builder[0x11] = 'v';
            builder[0x12] = 'a';
            builder[0x13] = 'l';
            builder[20] = 'F';
            builder[0x15] = 'D';
            builder[0x16] = 'Y';
            builder[0x17] = 'd';
            builder[0x18] = 'f';
            builder[0x19] = '6';
            builder[0x1a] = 'O';
            builder[0x1b] = 't';
            builder[0x1c] = 'M';
            builder[0x1d] = 'W';
            builder[30] = 'K';
            builder[0x1f] = 'y';
            builder[0x20] = 'H';
            builder[0x21] = '0';
            builder[0x22] = 'L';
            builder[0x23] = 'r';
            builder[0x24] = 'm';
            builder[0x25] = 'Q';
            builder[0x26] = '1';
            builder[0x27] = 'P';
            builder[40] = 'J';
            builder[0x29] = '4';
            builder[0x2a] = 'X';
            builder[0x2b] = 'b';
            builder[0x2c] = 'n';
            builder[0x2d] = '9';
            builder[0x2e] = '7';
            builder[0x2f] = '5';
            builder[0x30] = 'o';
            builder[0x31] = 'p';
            builder[50] = 'E';
            builder[0x33] = 'I';
            builder[0x34] = 'U';
            builder[0x35] = 'k';
            builder[0x36] = 'q';
            builder[0x37] = '2';
            builder[0x38] = 's';
            builder[0x39] = 'z';
            builder[0x3a] = 'c';
            builder[0x3b] = 'w';
            builder[60] = 'B';
            builder[0x3d] = 'g';
            uint num = 0;
            int num2 = keyyIN.Length - 1;
            for (int i = 0; i <= num2; i++)
            {
                num += (uint)(builder.ToString().IndexOf(keyyIN.Substring(i, 1)) * ((uint)Math.Pow(42.0, (double)(num2 - i))));
            }
            return num;
        }

        private static string jumpCode(string codeIN)
        {
            StringBuilder builder = new StringBuilder(codeIN);
            builder[0x19] = codeIN[0];
            builder[0x11] = codeIN[1];
            builder[0x20] = codeIN[2];
            builder[2] = codeIN[3];
            builder[0x18] = codeIN[4];
            builder[11] = codeIN[5];
            builder[0x21] = codeIN[6];
            builder[15] = codeIN[7];
            builder[0x10] = codeIN[8];
            builder[0x1b] = codeIN[9];
            builder[3] = codeIN[10];
            builder[8] = codeIN[11];
            builder[0x22] = codeIN[12];
            builder[1] = codeIN[13];
            builder[0x13] = codeIN[14];
            builder[0x16] = codeIN[15];
            builder[14] = codeIN[0x10];
            builder[12] = codeIN[0x11];
            builder[5] = codeIN[0x12];
            builder[9] = codeIN[0x13];
            builder[0x1d] = codeIN[20];
            builder[0x23] = codeIN[0x15];
            builder[0x1c] = codeIN[0x16];
            builder[7] = codeIN[0x17];
            builder[4] = codeIN[0x18];
            builder[30] = codeIN[0x19];
            builder[0x15] = codeIN[0x1a];
            builder[0x1f] = codeIN[0x1b];
            builder[6] = codeIN[0x1c];
            builder[0x1a] = codeIN[0x1d];
            builder[13] = codeIN[30];
            builder[0] = codeIN[0x1f];
            builder[20] = codeIN[0x20];
            builder[10] = codeIN[0x21];
            builder[0x12] = codeIN[0x22];
            builder[0x17] = codeIN[0x23];
            return builder.ToString();
        }

    }
}
