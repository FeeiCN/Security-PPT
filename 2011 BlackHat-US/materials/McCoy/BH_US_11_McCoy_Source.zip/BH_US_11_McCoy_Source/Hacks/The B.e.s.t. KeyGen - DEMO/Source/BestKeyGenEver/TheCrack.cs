﻿using System;
using System.Text;

namespace BestKeyGenEver
{
    class TheCrack
    {
        public static string KeyGen(string Name)
        {
            try
            {
                // get the key name for inside use))
                string keyInsideName = BuildKeynamePair(Name).ToString();
                uint[] numArray = new uint[7];
                numArray = BuildKey(Name, keyInsideName);

                string keyCode = string.Empty;
                for (int i2 = 0; i2 < 7; i2++)
                {
                    keyCode += jumbelKeyDocoder(numArray[i2]);
                }

                string s313 = keyCode.Length.ToString();
                keyCode += "1";
                keyCode = unjumpCode(keyCode);
                keyCode = keyCode.Insert(6, "-");
                keyCode = keyCode.Insert(13, "-");
                keyCode = keyCode.Insert(20, "-");
                keyCode = keyCode.Insert(27, "-");
                keyCode = keyCode.Insert(34, "-");

                if (Best_App_Ever.TeskKey.KeyCheck(Name, keyCode.ToString()))
                    return keyCode;
                else
                    return "BAAAAAAAAD";
            }
            catch
            {
                return "Hung";
            }
        }
        public static StringBuilder BuildKeynamePair(string NameIN)
        {
            string str = "BAEv1";
            StringBuilder builder = new StringBuilder(NameIN.ToLower());
            for (int n = 0; n < NameIN.Length; n++)
            {
                if ((builder[n] < 'a') || ('z' < builder[n]))
                {
                    builder[n] = (char)(97 + (builder[n] % '\x001a'));
                }
            }
            StringBuilder builder2 = new StringBuilder(str.ToLower());
            for (int num8 = 0; num8 < str.Length; num8++)
            {
                if ((builder2[num8] < 'a') || ('z' < builder2[num8]))
                {
                    builder2[num8] = (char)(97 + (builder2[num8] % '\x001a'));
                }
            }
            builder.Length = 25;
            for (int num9 = 0; num9 < 25; num9++)
            {
                builder[num9] = builder[num9 % NameIN.Length];
            }
            builder.Append(builder2);
            return builder;

        }
        public static uint[] BuildKey(string NameIN, string KeyIN)
        {
            uint[] numArrayGood = new uint[7];
            System.Collections.Generic.Queue<char> keyToGet = new System.Collections.Generic.Queue<char>(KeyIN.ToCharArray());

            for (int i3 = 0; i3 < 6; i3++)
            {
                for (int loop3 = 0; loop3 < 5; loop3++)
                {
                    int target = (keyToGet.Dequeue() - 92 + (6 + (i3 * 2) + (loop3 * 3))) % 32;
                    while (target < 0)
                    {
                        target += 32;
                    }
                    numArrayGood[i3] = ((uint)target << (5 * (4 - loop3))) | numArrayGood[i3];
                }
            }

            // the end length key
            uint t = (uint)(targetNumberFromLength(NameIN) << 5) & 0x7ffff;
            numArrayGood[6] = t;

            return numArrayGood;


        }
        public static int targetNumberFromLength(string NameIN)
        {
            int num11 = 4919;
            int num12 = 1;
            for (int num13 = 0; num13 < NameIN.Length; num13++)
            {
                num11 += NameIN[num13] * num12;
                num12 = (num12 % 9) + 1;
            }
            num11 = num11 % 201749;
            return num11;
        }
        private static string jumbelKeyDocoder(uint codeIN)
        {
            StringBuilder builder = new StringBuilder();
            builder.Length = 0x3e;
            builder[0] = 'V';
            builder[1] = 'A';
            builder[2] = 'j';
            builder[3] = 'T';
            builder[4] = 'C';
            builder[5] = 'N';
            builder[6] = 'h';
            builder[7] = '8';
            builder[8] = 'S';
            builder[9] = 'e';
            builder[10] = 'G';
            builder[11] = 'R';
            builder[12] = 'u';
            builder[13] = 'i';
            builder[14] = 'x';
            builder[15] = '3';
            builder[0x10] = 'Z';
            builder[0x11] = 'v';
            builder[0x12] = 'a';
            builder[0x13] = 'l';
            builder[20] = 'F';
            builder[0x15] = 'D';
            builder[0x16] = 'Y';
            builder[0x17] = 'd';
            builder[0x18] = 'f';
            builder[0x19] = '6';
            builder[0x1a] = 'O';
            builder[0x1b] = 't';
            builder[0x1c] = 'M';
            builder[0x1d] = 'W';
            builder[30] = 'K';
            builder[0x1f] = 'y';
            builder[0x20] = 'H';
            builder[0x21] = '0';
            builder[0x22] = 'L';
            builder[0x23] = 'r';
            builder[0x24] = 'm';
            builder[0x25] = 'Q';
            builder[0x26] = '1';
            builder[0x27] = 'P';
            builder[40] = 'J';
            builder[0x29] = '4';
            builder[0x2a] = 'X';
            builder[0x2b] = 'b';
            builder[0x2c] = 'n';
            builder[0x2d] = '9';
            builder[0x2e] = '7';
            builder[0x2f] = '5';
            builder[0x30] = 'o';
            builder[0x31] = 'p';
            builder[50] = 'E';
            builder[0x33] = 'I';
            builder[0x34] = 'U';
            builder[0x35] = 'k';
            builder[0x36] = 'q';
            builder[0x37] = '2';
            builder[0x38] = 's';
            builder[0x39] = 'z';
            builder[0x3a] = 'c';
            builder[0x3b] = 'w';
            builder[60] = 'B';
            builder[0x3d] = 'g';

            int max = builder.Length - 1;
            uint b;
            uint num = 0;
            int num2 = 5 - 1;

            int num01, num02, num03, num04, num05;
            for (num01 = max; 0 <= num01; num01--)
            {
                b = ((uint)Math.Pow(42.0, (double)(num2 - 0)));
                num = (uint)num01 * b;
                if (codeIN >= num)
                    break;
            }

            uint lastRoundNum = num;
            for (num02 = max; 0 <= num02; num02--)
            {
                num = lastRoundNum;
                b = ((uint)Math.Pow(42.0, (double)(num2 - 1)));
                num += (uint)num02 * b;
                if (codeIN >= num)
                    break;
            }

            lastRoundNum = num;

            for (num03 = max; 0 <= num03; num03--)
            {
                num = lastRoundNum;
                b = ((uint)Math.Pow(42.0, (double)(num2 - 2)));
                num += (uint)num03 * b;
                if (codeIN >= num)
                    break;
            }

            lastRoundNum = num;

            for (num04 = max; 0 <= num04; num04--)
            {
                num = lastRoundNum;
                b = ((uint)Math.Pow(42.0, (double)(num2 - 3)));
                num += (uint)num04 * b;
                if (codeIN >= num)
                    break;
            }

            lastRoundNum = num;

            for (num05 = max; 0 <= num05; num05--)
            {
                num = lastRoundNum;
                b = ((uint)Math.Pow(42.0, (double)(num2 - 4)));
                num += (uint)num05 * b;
                if (codeIN >= num)
                    break;
            }

            return builder[num01].ToString() + builder[num02].ToString() + builder[num03].ToString() + builder[num04].ToString() + builder[num05].ToString();
        }
        private static string unjumpCode(string builder)
        {
            StringBuilder codeIN = new StringBuilder(builder);
            codeIN[0] = builder[0x19];
            codeIN[1] = builder[0x11];
            codeIN[2] = builder[0x20];
            codeIN[3] = builder[2];
            codeIN[4] = builder[0x18];
            codeIN[5] = builder[11];
            codeIN[6] = builder[0x21];
            codeIN[7] = builder[15];
            codeIN[8] = builder[0x10];
            codeIN[9] = builder[0x1b];
            codeIN[10] = builder[3];
            codeIN[11] = builder[8];
            codeIN[12] = builder[0x22];
            codeIN[13] = builder[1];
            codeIN[14] = builder[0x13];
            codeIN[15] = builder[0x16];
            codeIN[0x10] = builder[14];
            codeIN[0x11] = builder[12];
            codeIN[0x12] = builder[5];
            codeIN[0x13] = builder[9];
            codeIN[20] = builder[0x1d];
            codeIN[0x15] = builder[0x23];
            codeIN[0x16] = builder[0x1c];
            codeIN[0x17] = builder[7];
            codeIN[0x18] = builder[4];
            codeIN[0x19] = builder[30];
            codeIN[0x1a] = builder[0x15];
            codeIN[0x1b] = builder[0x1f];
            codeIN[0x1c] = builder[6];
            codeIN[0x1d] = builder[0x1a];
            codeIN[30] = builder[13];
            codeIN[0x1f] = builder[0];
            codeIN[0x20] = builder[20];
            codeIN[0x21] = builder[10];
            codeIN[0x22] = builder[0x12];
            codeIN[0x23] = builder[0x17];
            return codeIN.ToString();
        }

    }
}
