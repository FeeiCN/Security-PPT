using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;

namespace SNSample
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class form_check4Hack : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Button button1;
        private ListBox listB_Checks;
        private Label lb_PassFail;
        private Label label3;
        private TextBox tb_output;
        private Button bn_testLib;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public form_check4Hack()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_check4Hack));
            this.button1 = new System.Windows.Forms.Button();
            this.listB_Checks = new System.Windows.Forms.ListBox();
            this.lb_PassFail = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_output = new System.Windows.Forms.TextBox();
            this.bn_testLib = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(58, 67);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "TEST";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listB_Checks
            // 
            this.listB_Checks.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listB_Checks.FormattingEnabled = true;
            this.listB_Checks.ItemHeight = 19;
            this.listB_Checks.Location = new System.Drawing.Point(224, 16);
            this.listB_Checks.Name = "listB_Checks";
            this.listB_Checks.Size = new System.Drawing.Size(252, 137);
            this.listB_Checks.TabIndex = 4;
            // 
            // lb_PassFail
            // 
            this.lb_PassFail.AutoSize = true;
            this.lb_PassFail.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_PassFail.Location = new System.Drawing.Point(47, 25);
            this.lb_PassFail.Name = "lb_PassFail";
            this.lb_PassFail.Size = new System.Drawing.Size(160, 31);
            this.lb_PassFail.TabIndex = 7;
            this.lb_PassFail.Text = "Good/Bad?";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(291, 1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Check List 4 Hacks:";
            // 
            // tb_output
            // 
            this.tb_output.Location = new System.Drawing.Point(12, 159);
            this.tb_output.Multiline = true;
            this.tb_output.Name = "tb_output";
            this.tb_output.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_output.Size = new System.Drawing.Size(464, 309);
            this.tb_output.TabIndex = 11;
            // 
            // bn_testLib
            // 
            this.bn_testLib.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bn_testLib.Location = new System.Drawing.Point(58, 105);
            this.bn_testLib.Name = "bn_testLib";
            this.bn_testLib.Size = new System.Drawing.Size(112, 32);
            this.bn_testLib.TabIndex = 12;
            this.bn_testLib.Text = "TEST LIB";
            this.bn_testLib.Click += new System.EventHandler(this.bn_testLib_Click);
            // 
            // form_check4Hack
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(489, 480);
            this.Controls.Add(this.bn_testLib);
            this.Controls.Add(this.tb_output);
            this.Controls.Add(this.lb_PassFail);
            this.Controls.Add(this.listB_Checks);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "form_check4Hack";
            this.Text = "Check 4 Hack";
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
        static void Main()
        {
			Application.Run(new form_check4Hack());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
            string exePath = System.Windows.Forms.Application.ExecutablePath;

            // this is the public token
            //var testToken= System.Reflection.Assembly.GetExecutingAssembly().GetName().GetPublicKeyToken();
            
            byte[] token = new byte[]{42,121,183,158,60,65,31,56};            
            
            StrongNameTesting.SecurityTest st = new StrongNameTesting.SecurityTest(token);
            
            try
            {
                listB_Checks.Items.Clear();
                listB_Checks.Items.Add("IsAllSecurityOkay\t-- " + st.IsAllSecurityOkay);
                listB_Checks.Items.Add("IsNoDebugger\t-- " + st.IsNoDebuggerAttached);
                listB_Checks.Items.Add("IsPublicTokenOkay\t-- " + st.IsPublicTokenOkay);
                listB_Checks.Items.Add("IsSecurityEnabled\t-- " + st.IsSecurityEnabled);
                listB_Checks.Items.Add("HasStrongSignature\t-- " + st.IsStrongSignatureValid);

                try
                {
                    listB_Checks.Items.Add("ValidStrongName\t-- " + st.IsStrongNameValid);
                }
                catch(System.Exception ex)
                {
                    listB_Checks.Items.Add("ValidStrongName\t-- " + "******");
                    listB_Checks.Items.Add("Error: " + ex.Message);
                }

                tb_output.Text = string.Empty;
                tb_output.Text += "---FriendlyName: " + AppDomain.CurrentDomain.FriendlyName;

                tb_output.Text += System.Environment.NewLine;
                tb_output.Text += System.Environment.NewLine;
                tb_output.Text += "---StrongName: " + System.Reflection.Assembly.GetEntryAssembly().GetName().FullName;

                tb_output.Text += System.Environment.NewLine;
                tb_output.Text += System.Environment.NewLine;
                tb_output.Text += "---PublicToken: ";
                foreach (byte c in System.Reflection.Assembly.GetEntryAssembly().GetName().GetPublicKeyToken())
                {
                    tb_output.Text += c.ToString("x");
                }

                tb_output.Text += System.Environment.NewLine;
                tb_output.Text += System.Environment.NewLine;
                tb_output.Text += "---PublicKey: ";
                foreach (byte c in System.Reflection.Assembly.GetEntryAssembly().GetName().GetPublicKey())
                {
                    tb_output.Text += c.ToString("x");
                }

                tb_output.Text += System.Environment.NewLine;
                tb_output.Text += System.Environment.NewLine;
                tb_output.Text += "---ExecutablePath: " + System.Windows.Forms.Application.ExecutablePath;
                tb_output.Text += System.Environment.NewLine;
                tb_output.Text += System.Environment.NewLine;
                tb_output.Text += "---CurrentDirectory: " + System.IO.Directory.GetCurrentDirectory();
                tb_output.Text += System.Environment.NewLine;
                tb_output.Text += System.Environment.NewLine;
                tb_output.Text += "---AppDomainBaseDirectory: " + AppDomain.CurrentDomain.BaseDirectory;

            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("ERROR");
            } 

            if (st.IsAllSecurityOkay)
            {
                this.BackColor = System.Drawing.Color.Blue;
                lb_PassFail.Text = "PASS";
            }
            else
            {
                this.BackColor = System.Drawing.Color.Red;
                lb_PassFail.Text = "FAIL";
            }
        }

        private void bn_testLib_Click(object sender, EventArgs e)
        {
            SaveData.Core.Run();
        }
	}
}