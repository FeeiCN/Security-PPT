﻿namespace SaveData
{
    using System;
    using System.Windows.Forms;

    public static class Core
    {
        private static void Main()
        {
        }

        public static void Run()
        {
            string text = "Data Saved";
            MessageBox.Show(text);
        }
    }
}

