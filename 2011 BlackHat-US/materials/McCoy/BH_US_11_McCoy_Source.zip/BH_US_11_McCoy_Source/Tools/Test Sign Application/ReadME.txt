Config Check OFF - Show the code check bypass Enabled
Config Check ON  - Show the code check Enabled
REG BypassCheckKeys - bypass the key check(Win 7 default)
REG CheckKeys - Check application Keys

disable the strong-name bypass.txt - Info about the Signed Keys from M$